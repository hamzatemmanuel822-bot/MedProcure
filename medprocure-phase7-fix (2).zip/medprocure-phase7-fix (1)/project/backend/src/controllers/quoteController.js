// quoteController.js
const pool = require("../config/db");
const stripe = require("../config/stripe");

const QUOTE_FEE = 25.0;

async function createQuoteRequest(req, res) {
  try {
    const { productId } = req.body;
    if (!productId) return res.status(400).json({ error: "productId is required." });

    const productResult = await pool.query("SELECT * FROM products WHERE id = $1", [productId]);
    if (productResult.rows.length === 0) return res.status(404).json({ error: "Product not found." });
    const product = productResult.rows[0];

    if (product.listing_type !== "quote_request") {
      return res.status(400).json({ error: "This product is available for direct purchase, not quote requests." });
    }

    const existing = await pool.query(
      "SELECT * FROM quote_requests WHERE product_id=$1 AND healthcare_consumer_id=$2",
      [productId, req.user.id]
    );
    if (existing.rows.length > 0) {
      return res.status(200).json({ message: "You already requested a quote for this product.", quoteRequest: existing.rows[0] });
    }

    const result = await pool.query(
      `INSERT INTO quote_requests (product_id, healthcare_consumer_id, distributor_id, fee_amount)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [productId, req.user.id, product.vendor_id, QUOTE_FEE]
    );
    return res.status(201).json({ message: "Quote request submitted.", quoteRequest: result.rows[0] });
  } catch (err) {
    console.error("createQuoteRequest error:", err.message);
    return res.status(500).json({ error: "Could not submit quote request." });
  }
}

async function payQuoteFee(req, res) {
  try {
    const { id } = req.params;
    const result = await pool.query("SELECT * FROM quote_requests WHERE id=$1 AND healthcare_consumer_id=$2", [id, req.user.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Quote request not found." });
    const quoteRequest = result.rows[0];
    if (quoteRequest.status === "contact_unlocked") {
      return res.status(400).json({ error: "Contact info is already unlocked for this request." });
    }

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items: [{
        price_data: { currency: "usd", product_data: { name: "Distributor Contact Unlock Fee (Demo)" }, unit_amount: Math.round(Number(quoteRequest.fee_amount) * 100) },
        quantity: 1,
      }],
      metadata: { type: "quote_fee", quote_request_id: String(quoteRequest.id) },
      success_url: `${process.env.CLIENT_URL}/quote-success.html?quote_id=${quoteRequest.id}`,
      cancel_url: `${process.env.CLIENT_URL}/my-quotes.html`,
    });

    await pool.query("UPDATE quote_requests SET stripe_session_id = $1 WHERE id = $2", [session.id, quoteRequest.id]);
    return res.status(200).json({ checkoutUrl: session.url });
  } catch (err) {
    console.error("payQuoteFee error:", err.message);
    return res.status(500).json({ error: "Could not start payment." });
  }
}

async function getMyQuoteRequests(req, res) {
  try {
    const result = await pool.query(
      `SELECT quote_requests.*, products.name AS product_name,
              CASE WHEN quote_requests.status='contact_unlocked' THEN users.full_name ELSE NULL END AS distributor_name,
              CASE WHEN quote_requests.status='contact_unlocked' THEN users.email ELSE NULL END AS distributor_email,
              CASE WHEN quote_requests.status='contact_unlocked' THEN users.phone ELSE NULL END AS distributor_phone,
              CASE WHEN quote_requests.status='contact_unlocked' THEN users.business_name ELSE NULL END AS distributor_business
       FROM quote_requests
       JOIN products ON quote_requests.product_id = products.id
       JOIN users ON quote_requests.distributor_id = users.id
       WHERE quote_requests.healthcare_consumer_id = $1
       ORDER BY quote_requests.created_at DESC`,
      [req.user.id]
    );
    return res.status(200).json({ quoteRequests: result.rows });
  } catch (err) {
    console.error("getMyQuoteRequests error:", err.message);
    return res.status(500).json({ error: "Could not load your quote requests." });
  }
}

async function getQuoteRequestById(req, res) {
  try {
    const { id } = req.params;
    const result = await pool.query("SELECT * FROM quote_requests WHERE id=$1 AND healthcare_consumer_id=$2", [id, req.user.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Quote request not found." });
    return res.status(200).json({ quoteRequest: result.rows[0] });
  } catch (err) {
    console.error("getQuoteRequestById error:", err.message);
    return res.status(500).json({ error: "Could not load quote request." });
  }
}

async function getReceivedQuoteRequests(req, res) {
  try {
    const result = await pool.query(
      `SELECT quote_requests.*, products.name AS product_name, users.full_name AS consumer_name, users.email AS consumer_email
       FROM quote_requests
       JOIN products ON quote_requests.product_id = products.id
       JOIN users ON quote_requests.healthcare_consumer_id = users.id
       WHERE quote_requests.distributor_id = $1
       ORDER BY quote_requests.created_at DESC`,
      [req.user.id]
    );
    return res.status(200).json({ quoteRequests: result.rows });
  } catch (err) {
    console.error("getReceivedQuoteRequests error:", err.message);
    return res.status(500).json({ error: "Could not load received quote requests." });
  }
}

module.exports = { createQuoteRequest, payQuoteFee, getMyQuoteRequests, getQuoteRequestById, getReceivedQuoteRequests };
