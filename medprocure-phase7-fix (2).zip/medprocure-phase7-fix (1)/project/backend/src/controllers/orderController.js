// orderController.js
const pool = require("../config/db");
const stripe = require("../config/stripe");

async function createCheckoutSession(req, res) {
  const client = await pool.connect();
  try {
    const cartResult = await client.query(
      `SELECT cart_items.quantity, products.id AS product_id, products.name, products.price,
              products.stock, products.vendor_id
       FROM cart_items JOIN products ON cart_items.product_id = products.id
       WHERE cart_items.user_id = $1`,
      [req.user.id]
    );
    const cartItems = cartResult.rows;
    if (cartItems.length === 0) return res.status(400).json({ error: "Your cart is empty." });

    for (const item of cartItems) {
      if (item.quantity > item.stock) {
        return res.status(400).json({ error: `Only ${item.stock} left for "${item.name}".` });
      }
    }

    const totalAmount = cartItems.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);

    await client.query("BEGIN");
    const orderResult = await client.query(
      `INSERT INTO orders (customer_id, total_amount, status) VALUES ($1,$2,'pending') RETURNING id`,
      [req.user.id, totalAmount]
    );
    const orderId = orderResult.rows[0].id;

    for (const item of cartItems) {
      await client.query(
        `INSERT INTO order_items (order_id, product_id, vendor_id, quantity, price_at_purchase)
         VALUES ($1,$2,$3,$4,$5)`,
        [orderId, item.product_id, item.vendor_id, item.quantity, item.price]
      );
    }
    await client.query("COMMIT");

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items: cartItems.map((item) => ({
        price_data: { currency: "usd", product_data: { name: item.name }, unit_amount: Math.round(Number(item.price) * 100) },
        quantity: item.quantity,
      })),
      metadata: { type: "order", order_id: String(orderId) },
      success_url: `${process.env.CLIENT_URL}/checkout-success.html?order_id=${orderId}`,
      cancel_url: `${process.env.CLIENT_URL}/cart.html`,
    });

    await pool.query("UPDATE orders SET stripe_session_id = $1 WHERE id = $2", [session.id, orderId]);
    return res.status(200).json({ checkoutUrl: session.url, orderId });
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    console.error("createCheckoutSession error:", err.message);
    return res.status(500).json({ error: "Could not start checkout. Please try again." });
  } finally {
    client.release();
  }
}

async function handleStripeWebhook(req, res) {
  const signature = req.headers["stripe-signature"];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("⚠️ Webhook signature verification failed:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    const paymentType = session.metadata.type;
    try {
      if (paymentType === "quote_fee") {
        const quoteRequestId = session.metadata.quote_request_id;
        await pool.query("UPDATE quote_requests SET status='contact_unlocked', updated_at=NOW() WHERE id=$1", [quoteRequestId]);
        console.log(`✅ Quote request ${quoteRequestId} contact unlocked.`);
      } else {
        const orderId = session.metadata.order_id;
        await pool.query("UPDATE orders SET status='paid', updated_at=NOW() WHERE id=$1", [orderId]);
        const orderItems = await pool.query("SELECT product_id, quantity FROM order_items WHERE order_id=$1", [orderId]);
        const orderRow = await pool.query("SELECT customer_id FROM orders WHERE id=$1", [orderId]);
        for (const item of orderItems.rows) {
          await pool.query("UPDATE products SET stock = stock - $1 WHERE id = $2", [item.quantity, item.product_id]);
        }
        if (orderRow.rows[0]) {
          await pool.query("DELETE FROM cart_items WHERE user_id = $1", [orderRow.rows[0].customer_id]);
        }
        console.log(`✅ Order ${orderId} marked as paid.`);
      }
    } catch (err) {
      console.error("Webhook processing error:", err.message);
    }
  }
  res.status(200).json({ received: true });
}

async function getMyOrders(req, res) {
  try {
    const result = await pool.query("SELECT * FROM orders WHERE customer_id = $1 ORDER BY created_at DESC", [req.user.id]);
    return res.status(200).json({ orders: result.rows });
  } catch (err) {
    console.error("getMyOrders error:", err.message);
    return res.status(500).json({ error: "Could not load your orders." });
  }
}

async function getOrderById(req, res) {
  try {
    const { id } = req.params;
    const orderResult = await pool.query("SELECT * FROM orders WHERE id=$1 AND customer_id=$2", [id, req.user.id]);
    if (orderResult.rows.length === 0) return res.status(404).json({ error: "Order not found." });
    const itemsResult = await pool.query(
      `SELECT order_items.*, products.name FROM order_items JOIN products ON order_items.product_id=products.id WHERE order_id=$1`,
      [id]
    );
    return res.status(200).json({ order: orderResult.rows[0], items: itemsResult.rows });
  } catch (err) {
    console.error("getOrderById error:", err.message);
    return res.status(500).json({ error: "Could not load this order." });
  }
}

module.exports = { createCheckoutSession, handleStripeWebhook, getMyOrders, getOrderById };
