// authController.js - Authentication & user identity controller
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const pool = require("../config/db");
const { encryptField, hashField } = require("../config/encryption");
const {
  sendConsumerVerificationEmail,
  sendDistributorVerificationEmail,
} = require("../config/emailService");

const NIN_REGEX = /^\d{11}$/; // Nigerian NIN: 11 digits
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function generateToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
  );
}

function formatUserResponse(u) {
  if (!u) return null;
  return {
    id: u.id,
    fullName: u.full_name || u.fullName || "",
    email: u.email,
    role: u.role,
    phone: u.phone || null,
    isVerified: u.is_verified !== undefined ? u.is_verified : !!u.isVerified,
    verificationStatus: u.verification_status || u.verificationStatus || "not_applicable",
    accountStatus: u.account_status || u.accountStatus || "active",
    businessName: u.business_name || u.businessName || null,
    createdAt: u.created_at || u.createdAt,
  };
}

// POST /api/auth/register
async function register(req, res) {
  try {
    const {
      fullName,
      email,
      password,
      role,
      phone,
      businessName,
      licenseNumber,
      nin,
      dateOfBirth,
      residentialAddress,
      termsAccepted,
    } = req.body;

    if (!fullName || !email || !password) {
      return res.status(400).json({ error: "Full name, email, and password are required." });
    }
    if (!EMAIL_REGEX.test(email)) {
      return res.status(400).json({ error: "Please enter a valid email address." });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: "Password must be at least 8 characters." });
    }
    if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
      return res.status(400).json({ error: "Password must contain both letters and numbers." });
    }

    const allowedRoles = ["healthcare_consumer", "distributor"];
    const finalRole = allowedRoles.includes(role) ? role : "healthcare_consumer";

    // --- Distributor KYC requirements: NIN, ID photo, license doc, proof of address are ALL mandatory ---
    let ninEncrypted = null;
    let ninHash = null;
    let idPhotoPath = null;
    let licenseDocumentPath = null;
    let proofOfAddressPath = null;

    if (finalRole === "distributor") {
      if (!businessName || !licenseNumber) {
        return res.status(400).json({
          error: "Business name and license number are required for Distributor accounts.",
        });
      }
      if (!nin || !NIN_REGEX.test(nin)) {
        return res.status(400).json({
          error: "A valid 11-digit National Identification Number (NIN) is required for Distributor accounts.",
        });
      }
      if (termsAccepted !== "true" && termsAccepted !== true) {
        return res.status(400).json({
          error: "You must read and agree to the Distributor Terms & Policy of Operation to register.",
        });
      }

      const idPhotoFile = req.files?.idPhoto?.[0];
      const licenseFile = req.files?.licenseDocument?.[0];
      const addressFile = req.files?.proofOfAddress?.[0];

      if (!idPhotoFile) {
        return res.status(400).json({ error: "An ID verification photo is required for Distributor accounts." });
      }
      if (!licenseFile) {
        return res.status(400).json({
          error: "A business license or certificate document is required for Distributor accounts.",
        });
      }
      if (!addressFile) {
        return res.status(400).json({ error: "A proof of address document is required for Distributor accounts." });
      }

      ninHash = hashField(nin);
      const duplicateNin = await pool.query("SELECT id FROM users WHERE nin_hash = $1", [ninHash]);
      if (duplicateNin.rows.length > 0) {
        return res.status(409).json({ error: "An account already exists for this National Identification Number." });
      }

      ninEncrypted = encryptField(nin);
      idPhotoPath = `/uploads/verification-docs/${idPhotoFile.filename}`;
      licenseDocumentPath = `/uploads/verification-docs/${licenseFile.filename}`;
      proofOfAddressPath = `/uploads/verification-docs/${addressFile.filename}`;
    }

    const existing = await pool.query("SELECT id FROM users WHERE email = $1", [email.toLowerCase().trim()]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: "An account with this email already exists." });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    // Cryptographic email verification token generated for BOTH roles
    const emailVerificationToken = crypto.randomBytes(32).toString("hex");
    const emailVerificationExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours expiry
    const isVerified = false;
    let verificationStatus = "not_applicable";
    const termsAcceptedAt = finalRole === "distributor" ? new Date() : null;
    const termsVersion = finalRole === "distributor" ? "v1.0" : null;

    if (finalRole === "distributor") {
      verificationStatus = "pending";
    }

    const result = await pool.query(
      `INSERT INTO users
        (full_name, email, password_hash, role, is_verified, business_name, license_number, phone,
         verification_status, email_verification_token, email_verification_expires_at, license_document_path,
         nin_encrypted, nin_hash, id_photo_path, date_of_birth, residential_address,
         proof_of_address_path, terms_accepted_at, terms_version)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20)
       RETURNING id, full_name, email, role, phone, is_verified, verification_status, account_status, business_name, created_at`,
      [
        fullName,
        email.toLowerCase().trim(),
        passwordHash,
        finalRole,
        isVerified,
        businessName || null,
        licenseNumber || null,
        phone || null,
        verificationStatus,
        emailVerificationToken,
        emailVerificationExpiresAt,
        licenseDocumentPath,
        ninEncrypted,
        ninHash,
        idPhotoPath,
        dateOfBirth || null,
        residentialAddress || null,
        proofOfAddressPath,
        termsAcceptedAt,
        termsVersion,
      ]
    );

    const newUser = result.rows[0];
    const token = generateToken(newUser);

    // Send verification email based on role
    if (finalRole === "healthcare_consumer") {
      sendConsumerVerificationEmail(newUser.email, newUser.full_name, emailVerificationToken).catch((err) =>
        console.error("Failed to send consumer verification email:", err.message)
      );
    } else if (finalRole === "distributor") {
      sendDistributorVerificationEmail(newUser.email, newUser.full_name, emailVerificationToken).catch((err) =>
        console.error("Failed to send distributor verification email:", err.message)
      );
    }

    // Explicit security invariant: Never leak email verification token or links in registration response!
    return res.status(201).json({
      message: "Account created successfully.",
      token,
      user: formatUserResponse(newUser),
    });
  } catch (err) {
    console.error("Register error:", err.message);
    return res.status(500).json({ error: "Something went wrong while creating your account." });
  }
}

// GET /api/auth/verify-email?token=...
async function verifyEmail(req, res) {
  try {
    const { token } = req.query;
    if (!token) return res.status(400).json({ error: "Missing verification token." });

    // 1. Check if token exists but has expired
    const expiredCheck = await pool.query(
      `SELECT id FROM users 
       WHERE email_verification_token = $1 
         AND email_verification_expires_at IS NOT NULL 
         AND email_verification_expires_at <= NOW()`,
      [token]
    );

    if (expiredCheck.rows.length > 0) {
      return res.status(400).json({
        error: "Verification link has expired. Please request a new verification email.",
      });
    }

    // 2. Validate token and update user to verified
    const result = await pool.query(
      `UPDATE users 
       SET is_verified = TRUE, 
           email_verification_token = NULL, 
           email_verification_expires_at = NULL,
           updated_at = NOW()
       WHERE email_verification_token = $1
       RETURNING id, full_name, email, role, phone, is_verified, verification_status, account_status, business_name, created_at`,
      [token]
    );

    if (result.rows.length === 0) {
      return res.status(400).json({ error: "This verification link is invalid or has already been used." });
    }

    return res.status(200).json({
      message: "Email verified successfully.",
      user: formatUserResponse(result.rows[0]),
    });
  } catch (err) {
    console.error("verifyEmail error:", err.message);
    return res.status(500).json({ error: "Could not verify email." });
  }
}

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

// POST /api/auth/login
async function login(req, res) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required." });
    }

    const result = await pool.query("SELECT * FROM users WHERE email = $1", [email.toLowerCase().trim()]);
    const user = result.rows[0];

    const genericError = { error: "Invalid email or password." };
    if (!user) return res.status(401).json(genericError);

    if (user.account_status === "terminated") {
      return res.status(403).json({
        error: "Your account has been terminated for violating MedProcure Operating Terms.",
        reason: user.terminated_reason || "Policy violation.",
      });
    }

    // Account temporarily locked from too many recent failed attempts
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      const minutesLeft = Math.ceil((new Date(user.locked_until) - new Date()) / 60000);
      return res.status(423).json({ error: `Too many failed attempts. Try again in ${minutesLeft} minute(s).` });
    }

    const passwordMatches = await bcrypt.compare(password, user.password_hash);

    if (!passwordMatches) {
      const attempts = (user.failed_login_attempts || 0) + 1;
      const lockUntil = attempts >= MAX_FAILED_ATTEMPTS
        ? new Date(Date.now() + LOCKOUT_MINUTES * 60000)
        : null;

      await pool.query(
        "UPDATE users SET failed_login_attempts = $1, locked_until = $2 WHERE id = $3",
        [attempts, lockUntil, user.id]
      );

      if (lockUntil) {
        return res.status(423).json({ error: `Too many failed attempts. Account locked for ${LOCKOUT_MINUTES} minutes.` });
      }
      return res.status(401).json(genericError);
    }

    // Successful login — reset failed login attempts
    if (user.failed_login_attempts > 0 || user.locked_until) {
      await pool.query("UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = $1", [user.id]);
    }

    const token = generateToken(user);

    return res.status(200).json({
      message: "Login successful.",
      token,
      user: formatUserResponse(user),
    });
  } catch (err) {
    console.error("Login error:", err.message);
    return res.status(500).json({ error: "Something went wrong while logging in." });
  }
}

// GET /api/auth/me
async function getMe(req, res) {
  try {
    const result = await pool.query(
      `SELECT id, full_name, email, role, phone, is_verified, verification_status, account_status, business_name, created_at 
       FROM users WHERE id = $1`,
      [req.user.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "User not found." });
    return res.status(200).json({ user: formatUserResponse(result.rows[0]) });
  } catch (err) {
    console.error("GetMe error:", err.message);
    return res.status(500).json({ error: "Something went wrong." });
  }
}

module.exports = { register, login, getMe, verifyEmail, formatUserResponse };
