// adminController.js
const path = require("path");
const pool = require("../config/db");
const { decryptField } = require("../config/encryption");
const storageService = require("../config/storageService");
const {
  sendDistributorApprovedEmail,
  sendDistributorRejectedEmail,
  sendDistributorTerminatedEmail,
} = require("../config/emailService");

function decryptedNin(row) {
  if (!row.nin_encrypted) return null;
  try {
    return decryptField(row.nin_encrypted);
  } catch {
    return "(unreadable — encryption key mismatch)";
  }
}

function toDistributorSummary(row) {
  return {
    id: row.id,
    fullName: row.full_name,
    full_name: row.full_name,
    email: row.email,
    phone: row.phone,
    businessName: row.business_name,
    business_name: row.business_name,
    licenseNumber: row.license_number,
    license_number: row.license_number,
    nin: decryptedNin(row),
    dateOfBirth: row.date_of_birth,
    date_of_birth: row.date_of_birth,
    residentialAddress: row.residential_address,
    residential_address: row.residential_address,
    hasLicenseDocument: !!row.license_document_path,
    has_license_document: !!row.license_document_path,
    hasIdPhoto: !!row.id_photo_path,
    has_id_photo: !!row.id_photo_path,
    hasProofOfAddress: !!row.proof_of_address_path,
    has_proof_of_address: !!row.proof_of_address_path,
    isVerified: row.is_verified,
    is_verified: row.is_verified,
    verificationStatus: row.verification_status,
    verification_status: row.verification_status,
    verificationNotes: row.verification_notes,
    verification_notes: row.verification_notes,
    accountStatus: row.account_status,
    account_status: row.account_status,
    terminatedReason: row.terminated_reason,
    terminated_reason: row.terminated_reason,
    createdAt: row.created_at,
    created_at: row.created_at,
  };
}

const DISTRIBUTOR_COLUMNS = `id, full_name, email, phone, business_name, license_number, nin_encrypted,
  date_of_birth, residential_address, license_document_path, id_photo_path, proof_of_address_path,
  is_verified, verification_status, verification_notes, account_status, terminated_reason, created_at`;

async function getPendingDistributors(req, res) {
  try {
    const result = await pool.query(
      `SELECT ${DISTRIBUTOR_COLUMNS} FROM users
       WHERE role='distributor' AND verification_status='pending' ORDER BY created_at ASC`
    );
    return res.status(200).json({ distributors: result.rows.map(toDistributorSummary) });
  } catch (err) {
    console.error("getPendingDistributors error:", err.message);
    return res.status(500).json({ error: "Could not load pending distributors." });
  }
}

async function getAllDistributors(req, res) {
  try {
    const result = await pool.query(
      `SELECT ${DISTRIBUTOR_COLUMNS} FROM users WHERE role='distributor' ORDER BY created_at DESC`
    );
    return res.status(200).json({ distributors: result.rows.map(toDistributorSummary) });
  } catch (err) {
    console.error("getAllDistributors error:", err.message);
    return res.status(500).json({ error: "Could not load distributors." });
  }
}

// GET /api/admin/distributors/:id/document?type=license|id|address
async function getDistributorDocument(req, res) {
  try {
    const { id } = req.params;
    const { type } = req.query;

    const columnMap = {
      license: "license_document_path",
      id: "id_photo_path",
      address: "proof_of_address_path",
      licenseDocument: "license_document_path",
      idPhoto: "id_photo_path",
      proofOfAddress: "proof_of_address_path",
    };

    if (!columnMap[type]) {
      return res.status(400).json({ error: "type must be 'license', 'id', or 'address'." });
    }

    const result = await pool.query(
      `SELECT ${columnMap[type]} AS doc_path FROM users WHERE id = $1 AND role = 'distributor'`,
      [id]
    );

    if (result.rows.length === 0 || !result.rows[0].doc_path) {
      return res.status(404).json({ error: "Document not found." });
    }

    const fileData = await storageService.getFileStream(result.rows[0].doc_path);
    if (!fileData) {
      return res.status(404).json({ error: "Document file is missing on the server." });
    }

    res.setHeader("Content-Type", fileData.mimeType);
    res.setHeader("Content-Length", fileData.size);
    res.setHeader("Content-Disposition", `inline; filename="${fileData.filename}"`);
    return fileData.stream.pipe(res);
  } catch (err) {
    console.error("getDistributorDocument error:", err.message);
    return res.status(500).json({ error: "Could not load document." });
  }
}

async function approveDistributor(req, res) {
  try {
    const { id } = req.params;

    // 1. Mandatory invariant: Distributor MUST verify email before administrative approval
    const userCheck = await pool.query(
      "SELECT id, full_name, email, is_verified, verification_status FROM users WHERE id = $1 AND role = 'distributor'",
      [id]
    );

    if (userCheck.rows.length === 0) {
      return res.status(404).json({ error: "Distributor not found." });
    }

    const currentDistributor = userCheck.rows[0];

    if (!currentDistributor.is_verified) {
      return res.status(400).json({
        error: "Distributor must verify email address before administrative approval.",
      });
    }

    // 2. Update status to approved and active
    const result = await pool.query(
      `UPDATE users 
       SET verification_status='approved', account_status='active', verification_notes=NULL, updated_at=NOW()
       WHERE id=$1 AND role='distributor' 
       RETURNING id, full_name, email, verification_status, account_status`,
      [id]
    );

    const distributor = result.rows[0];

    // 3. Record administrative approval event in audit_logs
    await pool.query(
      `INSERT INTO audit_logs (actor_id, action, entity_type, entity_id, details)
       VALUES ($1, 'DISTRIBUTOR_APPROVED', 'user', $2, $3)`,
      [
        req.user.id,
        id,
        JSON.stringify({
          previousStatus: currentDistributor.verification_status,
          newStatus: "approved",
          approvedBy: req.user.email,
        }),
      ]
    );

    sendDistributorApprovedEmail(distributor.email, distributor.full_name).catch((err) =>
      console.error("Failed to send approval email:", err.message)
    );

    return res.status(200).json({
      message: "Distributor approved.",
      distributor: {
        id: distributor.id,
        fullName: distributor.full_name,
        email: distributor.email,
        verificationStatus: distributor.verification_status,
        accountStatus: distributor.account_status,
      },
    });
  } catch (err) {
    console.error("approveDistributor error:", err.message);
    return res.status(500).json({ error: "Could not approve distributor." });
  }
}

async function rejectDistributor(req, res) {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    const result = await pool.query(
      `UPDATE users 
       SET verification_status='rejected', verification_notes=$1, updated_at=NOW()
       WHERE id=$2 AND role='distributor' 
       RETURNING id, full_name, email, verification_status`,
      [reason || "No reason provided.", id]
    );

    if (result.rows.length === 0) return res.status(404).json({ error: "Distributor not found." });

    const distributor = result.rows[0];

    // Record rejection event in audit_logs
    await pool.query(
      `INSERT INTO audit_logs (actor_id, action, entity_type, entity_id, details)
       VALUES ($1, 'DISTRIBUTOR_REJECTED', 'user', $2, $3)`,
      [
        req.user.id,
        id,
        JSON.stringify({
          reason: reason || "No reason provided.",
          rejectedBy: req.user.email,
        }),
      ]
    );

    sendDistributorRejectedEmail(distributor.email, distributor.full_name, reason).catch((err) =>
      console.error("Failed to send rejection email:", err.message)
    );

    return res.status(200).json({ message: "Distributor rejected.", distributor });
  } catch (err) {
    console.error("rejectDistributor error:", err.message);
    return res.status(500).json({ error: "Could not reject distributor." });
  }
}

async function terminateDistributor(req, res) {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    if (!reason || !reason.trim()) {
      return res.status(400).json({ error: "A reason is required to terminate a distributor account." });
    }

    const result = await pool.query(
      `UPDATE users 
       SET account_status='terminated', terminated_reason=$1, terminated_at=NOW(), updated_at=NOW()
       WHERE id=$2 AND role='distributor' 
       RETURNING id, full_name, email, account_status`,
      [reason, id]
    );

    if (result.rows.length === 0) return res.status(404).json({ error: "Distributor not found." });

    const distributor = result.rows[0];

    // Record termination in audit_logs
    await pool.query(
      `INSERT INTO audit_logs (actor_id, action, entity_type, entity_id, details)
       VALUES ($1, 'DISTRIBUTOR_TERMINATED', 'user', $2, $3)`,
      [
        req.user.id,
        id,
        JSON.stringify({
          reason,
          terminatedBy: req.user.email,
        }),
      ]
    );

    sendDistributorTerminatedEmail(distributor.email, distributor.full_name, reason).catch((err) =>
      console.error("Failed to send termination email:", err.message)
    );

    return res.status(200).json({ message: "Distributor account terminated.", distributor });
  } catch (err) {
    console.error("terminateDistributor error:", err.message);
    return res.status(500).json({ error: "Could not terminate distributor." });
  }
}

module.exports = {
  getPendingDistributors,
  getAllDistributors,
  approveDistributor,
  rejectDistributor,
  terminateDistributor,
  getDistributorDocument,
};
