// cartController.js
const pool = require("../config/db");

async function getCart(req, res) {
  try {
    const result = await pool.query(
      `SELECT cart_items.id, cart_items.quantity, cart_items.product_id,
              products.name, products.price, products.image_url, products.stock, products.category
       FROM cart_items JOIN products ON cart_items.product_id = products.id
       WHERE cart_items.user_id = $1 ORDER BY cart_items.created_at DESC`,
      [req.user.id]
    );
    const items = result.rows;
    const total = items.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);
    return res.status(200).json({ items, total: Number(total.toFixed(2)) });
  } catch (err) {
    console.error("getCart error:", err.message);
    return res.status(500).json({ error: "Could not load your cart." });
  }
}

async function addToCart(req, res) {
  try {
    const { productId, quantity } = req.body;
    const qty = quantity && quantity > 0 ? quantity : 1;
    if (!productId) return res.status(400).json({ error: "productId is required." });

    const product = await pool.query("SELECT * FROM products WHERE id = $1", [productId]);
    if (product.rows.length === 0) return res.status(404).json({ error: "Product not found." });
    if (product.rows[0].stock < qty) {
      return res.status(400).json({ error: `Only ${product.rows[0].stock} left in stock.` });
    }

    const result = await pool.query(
      `INSERT INTO cart_items (user_id, product_id, quantity) VALUES ($1,$2,$3)
       ON CONFLICT (user_id, product_id) DO UPDATE SET quantity = cart_items.quantity + $3, updated_at = NOW()
       RETURNING *`,
      [req.user.id, productId, qty]
    );
    return res.status(200).json({ message: "Added to cart.", item: result.rows[0] });
  } catch (err) {
    console.error("addToCart error:", err.message);
    return res.status(500).json({ error: "Could not add to cart." });
  }
}

async function updateCartItem(req, res) {
  try {
    const { itemId } = req.params;
    const { quantity } = req.body;
    if (!quantity || quantity < 1) return res.status(400).json({ error: "Quantity must be at least 1." });

    const result = await pool.query(
      `UPDATE cart_items SET quantity=$1, updated_at=NOW() WHERE id=$2 AND user_id=$3 RETURNING *`,
      [quantity, itemId, req.user.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Cart item not found." });
    return res.status(200).json({ message: "Cart updated.", item: result.rows[0] });
  } catch (err) {
    console.error("updateCartItem error:", err.message);
    return res.status(500).json({ error: "Could not update cart." });
  }
}

async function removeCartItem(req, res) {
  try {
    const { itemId } = req.params;
    const result = await pool.query(
      "DELETE FROM cart_items WHERE id = $1 AND user_id = $2 RETURNING *",
      [itemId, req.user.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Cart item not found." });
    return res.status(200).json({ message: "Removed from cart." });
  } catch (err) {
    console.error("removeCartItem error:", err.message);
    return res.status(500).json({ error: "Could not remove item." });
  }
}

module.exports = { getCart, addToCart, updateCartItem, removeCartItem };
