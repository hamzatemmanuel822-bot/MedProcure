// distributorController.js
const pool = require("../config/db");

async function submitVerification(req, res) {
  try {
    if (!req.file) return res.status(400).json({ error: "Please upload a license or certificate document." });
    const relativePath = `/uploads/verification-docs/${req.file.filename}`;
    const result = await pool.query(
      `UPDATE users 
       SET license_document_path=$1, verification_status='pending', verification_notes=NULL, updated_at=NOW()
       WHERE id=$2 AND role='distributor' 
       RETURNING id, verification_status, license_document_path`,
      [relativePath, req.user.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Distributor account not found." });
    return res.status(200).json({
      message: "Document submitted. Your account is now pending admin review.",
      status: result.rows[0].verification_status,
      verificationStatus: result.rows[0].verification_status,
      licenseDocumentPath: result.rows[0].license_document_path,
    });
  } catch (err) {
    console.error("submitVerification error:", err.message);
    return res.status(500).json({ error: "Could not submit verification document." });
  }
}

async function getVerificationStatus(req, res) {
  try {
    const result = await pool.query(
      `SELECT verification_status, verification_notes, license_document_path, is_verified, account_status 
       FROM users WHERE id = $1`,
      [req.user.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Distributor not found." });
    const row = result.rows[0];
    return res.status(200).json({
      verificationStatus: row.verification_status,
      verification_status: row.verification_status, // Backward compatibility
      verificationNotes: row.verification_notes,
      verification_notes: row.verification_notes,
      isVerified: row.is_verified,
      is_verified: row.is_verified,
      accountStatus: row.account_status,
      account_status: row.account_status,
      licenseDocumentPath: row.license_document_path,
      license_document_path: row.license_document_path,
    });
  } catch (err) {
    console.error("getVerificationStatus error:", err.message);
    return res.status(500).json({ error: "Could not check verification status." });
  }
}

module.exports = { submitVerification, getVerificationStatus };
