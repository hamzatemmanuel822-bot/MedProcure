// statsController.js
const pool = require("../config/db");

async function getPublicStats(req, res) {
  try {
    const [products, distributors, consumers, orders] = await Promise.all([
      pool.query("SELECT COUNT(*) FROM products"),
      pool.query("SELECT COUNT(*) FROM users WHERE role='distributor' AND verification_status='approved'"),
      pool.query("SELECT COUNT(*) FROM users WHERE role='healthcare_consumer'"),
      pool.query("SELECT COUNT(*) FROM orders WHERE status='paid'"),
    ]);
    return res.status(200).json({
      totalProducts: Number(products.rows[0].count),
      verifiedDistributors: Number(distributors.rows[0].count),
      healthcareConsumers: Number(consumers.rows[0].count),
      completedOrders: Number(orders.rows[0].count),
    });
  } catch (err) {
    console.error("getPublicStats error:", err.message);
    return res.status(500).json({ error: "Could not load platform stats." });
  }
}

async function getCategoryInsights(req, res) {
  try {
    const result = await pool.query(
      `SELECT category, COUNT(*) AS listing_count, ROUND(AVG(price),2) AS avg_price,
              MIN(price) AS min_price, MAX(price) AS max_price, SUM(stock) AS total_stock
       FROM products GROUP BY category ORDER BY listing_count DESC`
    );
    return res.status(200).json({ categories: result.rows });
  } catch (err) {
    console.error("getCategoryInsights error:", err.message);
    return res.status(500).json({ error: "Could not load category insights." });
  }
}

async function getDashboardSummary(req, res) {
  try {
    const { id, role } = req.user;

    if (role === "healthcare_consumer") {
      const [cart, activeQuotes, unlockedQuotes, orders, spent] = await Promise.all([
        pool.query("SELECT COALESCE(SUM(quantity),0) AS count FROM cart_items WHERE user_id=$1", [id]),
        pool.query("SELECT COUNT(*) FROM quote_requests WHERE healthcare_consumer_id=$1 AND status='pending_payment'", [id]),
        pool.query("SELECT COUNT(*) FROM quote_requests WHERE healthcare_consumer_id=$1 AND status='contact_unlocked'", [id]),
        pool.query("SELECT COUNT(*) FROM orders WHERE customer_id=$1 AND status='paid'", [id]),
        pool.query("SELECT COALESCE(SUM(total_amount),0) AS total FROM orders WHERE customer_id=$1 AND status='paid'", [id]),
      ]);
      return res.status(200).json({
        role,
        cartItemCount: Number(cart.rows[0].count),
        activeQuoteRequests: Number(activeQuotes.rows[0].count),
        unlockedQuoteRequests: Number(unlockedQuotes.rows[0].count),
        completedOrders: Number(orders.rows[0].count),
        totalSpent: Number(spent.rows[0].total),
      });
    }

    if (role === "distributor") {
      const [listings, stockUnits, pendingQuotes, unlockedQuotes] = await Promise.all([
        pool.query("SELECT COUNT(*) FROM products WHERE vendor_id=$1", [id]),
        pool.query("SELECT COALESCE(SUM(stock),0) AS total FROM products WHERE vendor_id=$1", [id]),
        pool.query("SELECT COUNT(*) FROM quote_requests WHERE distributor_id=$1 AND status='pending_payment'", [id]),
        pool.query("SELECT COUNT(*) FROM quote_requests WHERE distributor_id=$1 AND status='contact_unlocked'", [id]),
      ]);
      return res.status(200).json({
        role,
        activeListings: Number(listings.rows[0].count),
        totalStockUnits: Number(stockUnits.rows[0].total),
        pendingQuoteRequests: Number(pendingQuotes.rows[0].count),
        unlockedQuoteRequests: Number(unlockedQuotes.rows[0].count),
      });
    }

    if (role === "admin") {
      const [pending, distributors, consumers, products, orders] = await Promise.all([
        pool.query("SELECT COUNT(*) FROM users WHERE role='distributor' AND verification_status='pending'"),
        pool.query("SELECT COUNT(*) FROM users WHERE role='distributor'"),
        pool.query("SELECT COUNT(*) FROM users WHERE role='healthcare_consumer'"),
        pool.query("SELECT COUNT(*) FROM products"),
        pool.query("SELECT COUNT(*) FROM orders WHERE status='paid'"),
      ]);
      return res.status(200).json({
        role,
        pendingDistributors: Number(pending.rows[0].count),
        totalDistributors: Number(distributors.rows[0].count),
        totalConsumers: Number(consumers.rows[0].count),
        totalProducts: Number(products.rows[0].count),
        completedOrders: Number(orders.rows[0].count),
      });
    }

    return res.status(400).json({ error: "Unknown role." });
  } catch (err) {
    console.error("getDashboardSummary error:", err.message);
    return res.status(500).json({ error: "Could not load dashboard summary." });
  }
}

module.exports = { getPublicStats, getCategoryInsights, getDashboardSummary };
