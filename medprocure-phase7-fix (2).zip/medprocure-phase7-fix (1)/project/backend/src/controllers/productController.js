// productController.js
const pool = require("../config/db");

function isSafeImageUrl(url) {
  if (!url) return true; // optional field
  return /^https:\/\//i.test(url) || /^http:\/\//i.test(url);
}

async function getAllProducts(req, res) {
  try {
    const { search, category } = req.query;
    let query = `
      SELECT products.*, users.full_name AS vendor_name
      FROM products JOIN users ON products.vendor_id = users.id
      WHERE 1 = 1`;
    const params = [];

    if (search) {
      params.push(`%${search}%`);
      query += ` AND (products.name ILIKE $${params.length} OR products.description ILIKE $${params.length})`;
    }
    if (category) {
      params.push(category);
      query += ` AND products.category = $${params.length}`;
    }
    query += " ORDER BY products.created_at DESC";

    const result = await pool.query(query, params);
    return res.status(200).json({ products: result.rows });
  } catch (err) {
    console.error("getAllProducts error:", err.message);
    return res.status(500).json({ error: "Could not load products." });
  }
}

async function getProductById(req, res) {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT products.*, users.full_name AS vendor_name
       FROM products JOIN users ON products.vendor_id = users.id
       WHERE products.id = $1`,
      [id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Product not found." });
    return res.status(200).json({ product: result.rows[0] });
  } catch (err) {
    console.error("getProductById error:", err.message);
    return res.status(500).json({ error: "Could not load this product." });
  }
}

async function getMyProducts(req, res) {
  try {
    const result = await pool.query(
      "SELECT * FROM products WHERE vendor_id = $1 ORDER BY created_at DESC",
      [req.user.id]
    );
    return res.status(200).json({ products: result.rows });
  } catch (err) {
    console.error("getMyProducts error:", err.message);
    return res.status(500).json({ error: "Could not load your products." });
  }
}

async function createProduct(req, res) {
  try {
    const { name, description, price, stock, imageUrl, category, listingType } = req.body;

    const distributor = await pool.query("SELECT verification_status FROM users WHERE id = $1", [req.user.id]);
    if (distributor.rows[0]?.verification_status !== "approved") {
      return res.status(403).json({ error: "Your distributor account must be verified by an admin before you can list products." });
    }

    if (!name || price === undefined || !category) {
      return res.status(400).json({ error: "Name, price, and category are required." });
    }
    if (Number(price) < 0) return res.status(400).json({ error: "Price cannot be negative." });
    if (stock !== undefined && Number(stock) < 0) return res.status(400).json({ error: "Stock cannot be negative." });
    if (!isSafeImageUrl(imageUrl)) return res.status(400).json({ error: "Image URL must start with http:// or https://" });

    const finalListingType = listingType === "quote_request" ? "quote_request" : "buy_now";

    const result = await pool.query(
      `INSERT INTO products (vendor_id, name, description, price, stock, image_url, category, listing_type)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.user.id, name, description || null, price, stock || 0, imageUrl || null, category, finalListingType]
    );
    return res.status(201).json({ message: "Product created.", product: result.rows[0] });
  } catch (err) {
    console.error("createProduct error:", err.message);
    return res.status(500).json({ error: "Could not create product." });
  }
}

async function updateProduct(req, res) {
  try {
    const { id } = req.params;
    const { name, description, price, stock, imageUrl, category, listingType } = req.body;

    if (imageUrl && !isSafeImageUrl(imageUrl)) {
      return res.status(400).json({ error: "Image URL must start with http:// or https://" });
    }

    const existing = await pool.query("SELECT * FROM products WHERE id = $1", [id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: "Product not found." });
    if (existing.rows[0].vendor_id !== req.user.id) {
      return res.status(403).json({ error: "You can only edit your own products." });
    }

    const result = await pool.query(
      `UPDATE products SET name=$1, description=$2, price=$3, stock=$4, image_url=$5, category=$6,
       listing_type=$7, updated_at=NOW() WHERE id=$8 RETURNING *`,
      [
        name ?? existing.rows[0].name,
        description ?? existing.rows[0].description,
        price ?? existing.rows[0].price,
        stock ?? existing.rows[0].stock,
        imageUrl ?? existing.rows[0].image_url,
        category ?? existing.rows[0].category,
        listingType ?? existing.rows[0].listing_type,
        id,
      ]
    );
    return res.status(200).json({ message: "Product updated.", product: result.rows[0] });
  } catch (err) {
    console.error("updateProduct error:", err.message);
    return res.status(500).json({ error: "Could not update product." });
  }
}

async function deleteProduct(req, res) {
  try {
    const { id } = req.params;
    const existing = await pool.query("SELECT * FROM products WHERE id = $1", [id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: "Product not found." });
    if (existing.rows[0].vendor_id !== req.user.id) {
      return res.status(403).json({ error: "You can only delete your own products." });
    }
    await pool.query("DELETE FROM products WHERE id = $1", [id]);
    return res.status(200).json({ message: "Product deleted." });
  } catch (err) {
    console.error("deleteProduct error:", err.message);
    return res.status(500).json({ error: "Could not delete product." });
  }
}

module.exports = { getAllProducts, getProductById, getMyProducts, createProduct, updateProduct, deleteProduct };
