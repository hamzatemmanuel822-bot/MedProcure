-- 010_add_migration_tracking_and_indexes.sql
-- MedProcure Phase 8 Schema Hardening & Performance Indexes

-- 1. Correct role column default for new user accounts
ALTER TABLE users ALTER COLUMN role SET DEFAULT 'healthcare_consumer';

-- 2. Add email verification expiry column for token lifespan enforcement
ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verification_expires_at TIMESTAMP WITH TIME ZONE;

-- 3. Justified Query-Pattern Indexes:
-- Index for filtering approved and active distributors in marketplace catalog queries
CREATE INDEX IF NOT EXISTS idx_users_active_distributor 
    ON users(verification_status, account_status) 
    WHERE role = 'distributor';

-- Foreign key indexes on order_items for vendor sales analytics & product queries
CREATE INDEX IF NOT EXISTS idx_order_items_product ON order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_order_items_vendor ON order_items(vendor_id);

-- Composite index for distributor quote dashboard queries
CREATE INDEX IF NOT EXISTS idx_quote_requests_distributor_status 
    ON quote_requests(distributor_id, status);

-- 4. Administrative Audit Logging Table for tracking governance and stock incident events
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    actor_id INT REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT NOT NULL,
    details JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
