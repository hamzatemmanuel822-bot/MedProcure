-- 009_add_terms_address_and_termination.sql

ALTER TABLE users ADD COLUMN IF NOT EXISTS proof_of_address_path TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_accepted_at TIMESTAMP;
ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_version VARCHAR(20);

-- account_status is separate from verification_status: verification_status tracks the
-- initial KYC review outcome; account_status tracks ongoing standing (an already-approved
-- distributor can later be terminated for violating platform policy).
ALTER TABLE users ADD COLUMN IF NOT EXISTS account_status VARCHAR(20) NOT NULL DEFAULT 'active'; -- active | terminated
ALTER TABLE users ADD COLUMN IF NOT EXISTS terminated_reason TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS terminated_at TIMESTAMP;
