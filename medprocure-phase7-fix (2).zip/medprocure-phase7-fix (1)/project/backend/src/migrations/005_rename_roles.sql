UPDATE users SET role = 'distributor' WHERE role = 'vendor';
UPDATE users SET role = 'healthcare_consumer' WHERE role = 'customer';
