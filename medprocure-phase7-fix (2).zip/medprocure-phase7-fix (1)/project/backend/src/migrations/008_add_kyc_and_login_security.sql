-- 008_add_kyc_and_login_security.sql

-- --- Seller (Distributor) KYC / anti-scam fields ---
ALTER TABLE users ADD COLUMN IF NOT EXISTS nin_encrypted TEXT;      -- National ID Number, encrypted at rest (never stored in plain text)
ALTER TABLE users ADD COLUMN IF NOT EXISTS nin_hash TEXT;           -- one-way hash of the NIN, used only to detect duplicate accounts
ALTER TABLE users ADD COLUMN IF NOT EXISTS id_photo_path TEXT;      -- selfie / ID card photo, admin-only access
ALTER TABLE users ADD COLUMN IF NOT EXISTS date_of_birth DATE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS residential_address TEXT;

-- Prevents the same NIN being used to create multiple seller accounts (a common scam pattern)
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_nin_hash ON users(nin_hash) WHERE nin_hash IS NOT NULL;

-- --- Login security / brute-force protection ---
ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_login_attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until TIMESTAMP;
