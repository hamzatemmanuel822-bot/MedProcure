ALTER TABLE products ADD COLUMN IF NOT EXISTS listing_type VARCHAR(20) NOT NULL DEFAULT 'buy_now';
CREATE TABLE IF NOT EXISTS quote_requests (
    id SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    healthcare_consumer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    distributor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'pending_payment',
    fee_amount NUMERIC(10, 2) NOT NULL DEFAULT 25.00,
    stripe_session_id TEXT UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_quote_requests_consumer ON quote_requests(healthcare_consumer_id);
CREATE INDEX IF NOT EXISTS idx_quote_requests_distributor ON quote_requests(distributor_id);
