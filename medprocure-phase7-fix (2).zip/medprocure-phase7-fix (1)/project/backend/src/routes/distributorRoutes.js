// distributorRoutes.js
const express = require("express");
const router = express.Router();
const { submitVerification, getVerificationStatus } = require("../controllers/distributorController");
const { requireAuth, requireRole, blockIfTerminated } = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");

// Enforce authentication, role checking, and termination blocking across all distributor routes
router.use(requireAuth, requireRole(["distributor"]), blockIfTerminated);

router.get("/verification-status", getVerificationStatus);
router.post("/verification", upload.single("licenseDocument"), submitVerification);

module.exports = router;
