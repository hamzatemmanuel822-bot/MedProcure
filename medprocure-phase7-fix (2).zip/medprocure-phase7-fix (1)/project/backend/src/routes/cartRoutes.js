// cartRoutes.js
const express = require("express");
const router = express.Router();
const { getCart, addToCart, updateCartItem, removeCartItem } = require("../controllers/cartController");
const { requireAuth } = require("../middleware/authMiddleware");

router.use(requireAuth);
router.get("/", getCart);
router.post("/", addToCart);
router.put("/:itemId", updateCartItem);
router.delete("/:itemId", removeCartItem);

module.exports = router;
