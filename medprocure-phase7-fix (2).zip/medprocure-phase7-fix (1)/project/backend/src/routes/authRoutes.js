// authRoutes.js
const express = require("express");
const router = express.Router();
const { register, login, getMe, verifyEmail } = require("../controllers/authController");
const { requireAuth } = require("../middleware/authMiddleware");
const { distributorSignupFiles } = require("../middleware/registrationUploadMiddleware");

// distributorSignupFiles only activates for multipart/form-data requests (Distributor signups).
// Plain JSON requests (Healthcare Consumer signups) pass through untouched.
router.post("/register", distributorSignupFiles, register);
router.post("/login", login);
router.get("/verify-email", verifyEmail);
router.get("/me", requireAuth, getMe);

module.exports = router;
