// adminRoutes.js
const express = require("express");
const router = express.Router();
const {
  getPendingDistributors, getAllDistributors, approveDistributor, rejectDistributor,
  terminateDistributor, getDistributorDocument,
} = require("../controllers/adminController");
const { requireAuth, requireRole } = require("../middleware/authMiddleware");

router.use(requireAuth, requireRole(["admin"]));
router.get("/distributors/pending", getPendingDistributors);
router.get("/distributors", getAllDistributors);
router.get("/distributors/:id/document", getDistributorDocument);
router.post("/distributors/:id/approve", approveDistributor);
router.post("/distributors/:id/reject", rejectDistributor);
router.post("/distributors/:id/terminate", terminateDistributor);

module.exports = router;
