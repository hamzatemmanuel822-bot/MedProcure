// statsRoutes.js
const express = require("express");
const router = express.Router();
const { getPublicStats, getCategoryInsights, getDashboardSummary } = require("../controllers/statsController");
const { requireAuth } = require("../middleware/authMiddleware");

router.get("/public", getPublicStats);
router.get("/categories", getCategoryInsights);
router.get("/dashboard-summary", requireAuth, getDashboardSummary);

module.exports = router;
