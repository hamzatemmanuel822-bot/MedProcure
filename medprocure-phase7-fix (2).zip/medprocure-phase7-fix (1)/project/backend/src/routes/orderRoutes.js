// orderRoutes.js
const express = require("express");
const router = express.Router();
const { createCheckoutSession, getMyOrders, getOrderById } = require("../controllers/orderController");
const { requireAuth } = require("../middleware/authMiddleware");

router.use(requireAuth);
router.post("/checkout", createCheckoutSession);
router.get("/mine", getMyOrders);
router.get("/:id", getOrderById);

module.exports = router;
