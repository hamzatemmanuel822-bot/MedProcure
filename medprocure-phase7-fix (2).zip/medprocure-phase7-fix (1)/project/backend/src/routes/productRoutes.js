// productRoutes.js
const express = require("express");
const router = express.Router();
const {
  getAllProducts, getProductById, getMyProducts, createProduct, updateProduct, deleteProduct,
} = require("../controllers/productController");
const { requireAuth, requireRole, blockIfTerminated } = require("../middleware/authMiddleware");

router.get("/", getAllProducts);
router.get("/mine", requireAuth, requireRole(["distributor"]), blockIfTerminated, getMyProducts);
router.get("/:id", getProductById);
router.post("/", requireAuth, requireRole(["distributor"]), blockIfTerminated, createProduct);
router.put("/:id", requireAuth, requireRole(["distributor"]), blockIfTerminated, updateProduct);
router.delete("/:id", requireAuth, requireRole(["distributor"]), blockIfTerminated, deleteProduct);

module.exports = router;
