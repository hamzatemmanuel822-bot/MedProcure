// quoteRoutes.js
const express = require("express");
const router = express.Router();
const {
  createQuoteRequest, payQuoteFee, getMyQuoteRequests, getQuoteRequestById, getReceivedQuoteRequests,
} = require("../controllers/quoteController");
const { requireAuth, requireRole, blockIfTerminated } = require("../middleware/authMiddleware");

router.use(requireAuth);
router.post("/", requireRole(["healthcare_consumer"]), createQuoteRequest);
router.post("/:id/pay", requireRole(["healthcare_consumer"]), payQuoteFee);
router.get("/mine", requireRole(["healthcare_consumer"]), getMyQuoteRequests);
router.get("/received", requireRole(["distributor"]), blockIfTerminated, getReceivedQuoteRequests);
router.get("/:id", requireRole(["healthcare_consumer"]), getQuoteRequestById);

module.exports = router;
