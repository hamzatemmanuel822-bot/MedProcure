// emailService.js
// Sends real emails via SMTP if you've configured credentials in .env.
// If you HAVEN'T configured SMTP yet, emails are printed to your backend console instead
// of failing silently — so you can still see exactly what would have been sent while
// you're developing, without needing a real mail provider set up.

const nodemailer = require("nodemailer");

function isSmtpConfigured() {
  return !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
}

let transporter = null;
if (isSmtpConfigured()) {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 587,
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    connectionTimeout: 10000,
    greetingTimeout: 5000,
  });
}

async function sendEmail({ to, subject, html }) {
  if (!transporter) {
    console.log("📧 [SIMULATED EMAIL — SMTP not configured in .env]");
    console.log(`   To: ${to}`);
    console.log(`   Subject: ${subject}`);
    console.log(`   (Set SMTP_HOST, SMTP_USER, SMTP_PASS in .env to send real emails.)`);
    return { simulated: true };
  }

  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || `"MedProcure" <no-reply@medprocure.com>`,
      to,
      subject,
      html,
    });
    return { simulated: false, sent: true };
  } catch (err) {
    console.error("❌ Failed to send email:", err.message);
    return { simulated: false, sent: false, error: err.message };
  }
}

function baseTemplate(bodyHtml) {
  return `
  <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 520px; margin: 0 auto; background: #f4f7f9; padding: 32px 0;">
    <div style="background: #0b2540; padding: 24px 32px; border-radius: 12px 12px 0 0;">
      <span style="color:#fff; font-weight:800; font-size:18px;">🛡️ MedProcure</span>
    </div>
    <div style="background: #ffffff; padding: 32px; border-radius: 0 0 12px 12px;">
      ${bodyHtml}
    </div>
    <p style="text-align:center; color:#94a3b8; font-size:12px; margin-top:16px;">
      © ${new Date().getFullYear()} MedProcure. This is an automated message.
    </p>
  </div>`;
}

async function sendDistributorVerificationEmail(to, fullName, verificationToken) {
  const verifyUrl = `${process.env.CLIENT_URL || "http://127.0.0.1:5500"}/verify-email.html?token=${verificationToken}`;
  const html = baseTemplate(`
    <h2 style="color:#0b2540;">Verify your Distributor account email</h2>
    <p style="color:#334155; line-height:1.6;">
      Hi ${fullName ? fullName.split(" ")[0] : "there"}, thank you for registering your medical equipment distribution business on MedProcure.
    </p>
    <p style="color:#334155; line-height:1.6;">
      Before our administrative compliance team can review your business license, NIN, and identity documents, you must verify your email address.
    </p>
    <p style="margin-top:24px;">
      <a href="${verifyUrl}" style="background:#0d6e6e; color:#fff; padding:12px 24px; border-radius:8px; text-decoration:none; font-weight:600;">Verify Distributor Email</a>
    </p>
    <p style="color:#64748b; font-size:13px; line-height:1.5; margin-top:16px;">
      Note: This verification link expires in 24 hours. After verifying, our compliance team reviews documents within 24–48 hours.
    </p>
    <p style="color:#94a3b8; font-size:12px; margin-top:16px;">If the button doesn't work, copy and paste this link: ${verifyUrl}</p>
  `);
  return sendEmail({ to, subject: "Verify your MedProcure Distributor email address", html });
}

async function sendDistributorApprovedEmail(to, fullName) {
  const html = baseTemplate(`
    <h2 style="color:#0b2540;">You're verified, ${fullName ? fullName.split(" ")[0] : "Partner"}! ✅</h2>
    <p style="color:#334155; line-height:1.6;">
      Great news — your Distributor account on MedProcure has been reviewed and <strong>approved</strong>.
      You can now log in and start listing medical equipment on the marketplace.
    </p>
    <p style="color:#334155; line-height:1.6;">
      Please remember: all listings and conduct on MedProcure are governed by our
      <strong>Distributor Terms & Policy of Operation</strong>. Violating these terms
      (including fraudulent listings, fake documents, or scam behavior) can result in
      immediate account termination.
    </p>
    <p style="margin-top:24px;"><a href="${process.env.CLIENT_URL || "http://127.0.0.1:5500"}/login.html" style="background:#0d6e6e; color:#fff; padding:12px 24px; border-radius:8px; text-decoration:none; font-weight:600;">Log In to Your Dashboard</a></p>
  `);
  return sendEmail({ to, subject: "✅ Your MedProcure Distributor account is approved", html });
}

async function sendDistributorRejectedEmail(to, fullName, reason) {
  const html = baseTemplate(`
    <h2 style="color:#0b2540;">Update on your MedProcure application</h2>
    <p style="color:#334155; line-height:1.6;">Hi ${fullName ? fullName.split(" ")[0] : "Partner"}, after reviewing your submitted documents, we were unable to approve your Distributor account at this time.</p>
    ${reason ? `<p style="background:#fef2f2; border:1px solid #fecaca; padding:12px 16px; border-radius:8px; color:#991b1b;"><strong>Reason:</strong> ${reason}</p>` : ""}
    <p style="color:#334155; line-height:1.6;">If you believe this was a mistake or would like to resubmit corrected documents, please log in to your dashboard to re-upload your verification documents.</p>
  `);
  return sendEmail({ to, subject: "MedProcure Distributor application — update", html });
}

async function sendDistributorTerminatedEmail(to, fullName, reason) {
  const html = baseTemplate(`
    <h2 style="color:#0b2540;">Your MedProcure account has been terminated</h2>
    <p style="color:#334155; line-height:1.6;">Hi ${fullName ? fullName.split(" ")[0] : "Partner"}, your Distributor account has been terminated for violating MedProcure's Terms & Policy of Operation.</p>
    ${reason ? `<p style="background:#fef2f2; border:1px solid #fecaca; padding:12px 16px; border-radius:8px; color:#991b1b;"><strong>Reason:</strong> ${reason}</p>` : ""}
    <p style="color:#334155; line-height:1.6;">You will no longer be able to log in or list products on the platform. If you believe this is an error, please contact support.</p>
  `);
  return sendEmail({ to, subject: "⚠️ Your MedProcure account has been terminated", html });
}

async function sendConsumerVerificationEmail(to, fullName, verificationToken) {
  const verifyUrl = `${process.env.CLIENT_URL || "http://127.0.0.1:5500"}/verify-email.html?token=${verificationToken}`;
  const html = baseTemplate(`
    <h2 style="color:#0b2540;">Welcome to MedProcure, ${fullName ? fullName.split(" ")[0] : "there"}!</h2>
    <p style="color:#334155; line-height:1.6;">
      Please confirm your email address to finish setting up your Healthcare Consumer account.
    </p>
    <p style="margin-top:24px;"><a href="${verifyUrl}" style="background:#0d6e6e; color:#fff; padding:12px 24px; border-radius:8px; text-decoration:none; font-weight:600;">Verify My Email</a></p>
    <p style="color:#64748b; font-size:13px; line-height:1.5; margin-top:16px;">This link will expire in 24 hours.</p>
    <p style="color:#94a3b8; font-size:12px; margin-top:16px;">If the button doesn't work, copy and paste this link: ${verifyUrl}</p>
  `);
  return sendEmail({ to, subject: "Verify your MedProcure email address", html });
}

module.exports = {
  sendEmail,
  sendDistributorVerificationEmail,
  sendDistributorApprovedEmail,
  sendDistributorRejectedEmail,
  sendDistributorTerminatedEmail,
  sendConsumerVerificationEmail,
};
