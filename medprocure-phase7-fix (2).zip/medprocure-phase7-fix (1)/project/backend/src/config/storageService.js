// storageService.js - Storage abstraction for identity and verification documents
const fs = require("fs");
const path = require("path");

class LocalStorageProvider {
  constructor(baseDir) {
    this.baseDir = baseDir || path.resolve(__dirname, "..", "..", "uploads", "verification-docs");
    if (!fs.existsSync(this.baseDir)) {
      fs.mkdirSync(this.baseDir, { recursive: true });
    }
  }

  /**
   * Safely opens a read stream for a verification document with path traversal protection.
   * @param {string} filePath - Stored relative or filename reference.
   * @returns {Promise<{ stream: fs.ReadStream, size: number, mimeType: string } | null>}
   */
  async getFileStream(filePath) {
    if (!filePath) return null;

    const filename = path.basename(filePath);
    const absolutePath = path.resolve(this.baseDir, filename);

    // Defense-in-depth: guarantee target file strictly resides within baseDir
    if (!absolutePath.startsWith(path.resolve(this.baseDir))) {
      throw new Error("Security Alert: Path traversal attempt detected.");
    }

    if (!fs.existsSync(absolutePath)) {
      return null;
    }

    const stat = fs.statSync(absolutePath);
    const ext = path.extname(filename).toLowerCase();
    let mimeType = "application/octet-stream";

    if (ext === ".pdf") mimeType = "application/pdf";
    else if (ext === ".jpg" || ext === ".jpeg") mimeType = "image/jpeg";
    else if (ext === ".png") mimeType = "image/png";

    return {
      stream: fs.createReadStream(absolutePath),
      size: stat.size,
      mimeType,
      filename,
    };
  }

  /**
   * Safely deletes a file if it exists.
   * @param {string} filePath - Stored relative or filename reference.
   */
  async deleteFile(filePath) {
    if (!filePath) return;
    const filename = path.basename(filePath);
    const absolutePath = path.resolve(this.baseDir, filename);

    if (!absolutePath.startsWith(path.resolve(this.baseDir))) {
      throw new Error("Security Alert: Path traversal attempt detected.");
    }

    if (fs.existsSync(absolutePath)) {
      fs.unlinkSync(absolutePath);
    }
  }

  /**
   * Checks if a file exists.
   * @param {string} filePath 
   */
  async fileExists(filePath) {
    if (!filePath) return false;
    const filename = path.basename(filePath);
    const absolutePath = path.resolve(this.baseDir, filename);
    return absolutePath.startsWith(path.resolve(this.baseDir)) && fs.existsSync(absolutePath);
  }
}

module.exports = new LocalStorageProvider();
module.exports.LocalStorageProvider = LocalStorageProvider;
