// seedAdmin.js
require("dotenv").config();
const bcrypt = require("bcryptjs");
const pool = require("./db");

async function seedAdmin() {
  const email = (process.env.ADMIN_EMAIL || "").toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  const fullName = process.env.ADMIN_FULL_NAME || "Platform Administrator";

  if (!email || !password) {
    console.error("❌ Set ADMIN_EMAIL and ADMIN_PASSWORD in your .env file first.");
    process.exit(1);
  }

  const existing = await pool.query("SELECT id FROM users WHERE email = $1", [email]);
  if (existing.rows.length > 0) {
    console.log("ℹ️  An account with this email already exists. Updating it to role=admin...");
    await pool.query("UPDATE users SET role = 'admin' WHERE email = $1", [email]);
    console.log("✅ Done.");
    process.exit(0);
  }

  const passwordHash = await bcrypt.hash(password, 10);
  await pool.query(
    `INSERT INTO users (full_name, email, password_hash, role, is_verified, verification_status)
     VALUES ($1, $2, $3, 'admin', TRUE, 'not_applicable')`,
    [fullName, email, passwordHash]
  );

  console.log(`✅ Admin account created: ${email}`);
  process.exit(0);
}

seedAdmin().catch((err) => {
  console.error("❌ Failed to seed admin:", err.message);
  process.exit(1);
});
