// db.js
const { Pool } = require("pg");

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

pool.connect((err, client, release) => {
  if (err) {
    console.error("❌ Could not connect to the database:", err.message);
    console.error("   Make sure Docker is running: docker-compose up -d");
    return;
  }
  console.log("✅ Connected to PostgreSQL");
  release();
});

module.exports = pool;
