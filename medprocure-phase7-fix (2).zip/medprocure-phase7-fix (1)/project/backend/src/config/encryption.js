// encryption.js
// Handles encrypting sensitive data (like a National ID Number) before it's stored,
// and decrypting it only when an authorized admin needs to view it.
//
// Think of it like a locked safe: the DATABASE stores the locked box, not the ID number itself.
// Only someone with the key (ENCRYPTION_KEY in your .env) can open it — so even if someone
// got a raw copy of your database, the NIN inside would be unreadable gibberish to them.

const crypto = require("crypto");

const ALGORITHM = "aes-256-gcm";

function getKey() {
  const keyHex = process.env.ENCRYPTION_KEY;
  if (!keyHex || keyHex.length !== 64) {
    throw new Error(
      "ENCRYPTION_KEY is missing or invalid in .env — it must be a 64-character hex string (32 bytes). " +
      "Generate one with: node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\""
    );
  }
  return Buffer.from(keyHex, "hex");
}

// Encrypts a string. Returns one combined string safe to store in a single TEXT column.
function encryptField(plainText) {
  const key = getKey();
  const iv = crypto.randomBytes(12); // GCM standard IV size
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);

  const encrypted = Buffer.concat([cipher.update(plainText, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();

  // Store iv + authTag + ciphertext together, base64-encoded, separated by colons
  return `${iv.toString("base64")}:${authTag.toString("base64")}:${encrypted.toString("base64")}`;
}

// Decrypts a string produced by encryptField(). Throws if the data was tampered with.
function decryptField(storedValue) {
  const key = getKey();
  const [ivB64, authTagB64, dataB64] = storedValue.split(":");
  const iv = Buffer.from(ivB64, "base64");
  const authTag = Buffer.from(authTagB64, "base64");
  const encrypted = Buffer.from(dataB64, "base64");

  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);

  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return decrypted.toString("utf8");
}

// One-way hash, used ONLY to check "has this exact NIN been used before?" without ever
// storing or exposing the NIN itself in reversible form for that check.
function hashField(plainText) {
  return crypto.createHash("sha256").update(plainText).digest("hex");
}

// Shows only the last 4 characters — used when displaying a NIN to an admin reviewer,
// so even authorized staff don't see the full number unless they specifically decrypt it.
function maskLast4(value) {
  if (!value || value.length <= 4) return "****";
  return `${"*".repeat(value.length - 4)}${value.slice(-4)}`;
}

module.exports = { encryptField, decryptField, hashField, maskLast4 };
