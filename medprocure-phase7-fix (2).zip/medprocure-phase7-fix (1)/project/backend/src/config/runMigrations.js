// runMigrations.js - Versioned, baseline-aware SQL migration runner
const fs = require("fs");
const path = require("path");

// 1. Explicitly resolve backend/.env regardless of terminal working directory
require("dotenv").config({ path: path.resolve(__dirname, "..", "..", ".env") });

// 2. Fail immediately if required database connection settings are missing
const requiredEnvVars = ["DB_HOST", "DB_NAME", "DB_USER", "DB_PASSWORD"];
const missingEnvVars = requiredEnvVars.filter((k) => !process.env[k]);
if (missingEnvVars.length > 0) {
  console.error("❌ Migration runner error: Missing required database connection settings:");
  console.error(`   ${missingEnvVars.join(", ")}`);
  console.error("   Ensure backend/.env exists and defines these variables.");
  process.exit(1);
}

const pool = require("./db");

const REQUIRED_HISTORICAL_MIGRATIONS = [
  "001_create_users_table.sql",
  "002_create_products_table.sql",
  "003_create_cart_items_table.sql",
  "004_create_orders_tables.sql",
  "005_rename_roles.sql",
  "006_add_verification_and_contact_fields.sql",
  "007_add_quote_requests_and_listing_type.sql",
  "008_add_kyc_and_login_security.sql",
  "009_add_terms_address_and_termination.sql",
];

async function runMigrations() {
  const migrationsDir = path.join(__dirname, "..", "migrations");
  const files = fs
    .readdirSync(migrationsDir)
    .filter((f) => f.endsWith(".sql"))
    .sort();

  console.log(`Found ${files.length} migration file(s) in repository.`);

  // 1. STRICT MIGRATION-FILE VALIDATION (Before any DB query or DDL)
  const invalidFiles = files.filter((f) => !/^\d{3}_[a-z0-9_]+\.sql$/.test(f));
  if (invalidFiles.length > 0) {
    console.error("❌ Migration runner error: Invalid migration filename(s) detected:");
    console.error(`   ${invalidFiles.join(", ")}`);
    console.error("   Migration filenames must match pattern: ^\\d{3}_[a-z0-9_]+\\.sql$");
    process.exit(1);
  }

  const missingHistorical = REQUIRED_HISTORICAL_MIGRATIONS.filter((f) => !files.includes(f));
  if (missingHistorical.length > 0) {
    console.error("❌ Migration runner error: Missing required historical migration file(s):");
    console.error(`   ${missingHistorical.join(", ")}`);
    console.error("   Historical migrations 001 through 009 must be present in the repository.");
    process.exit(1);
  }

  const versionPrefixes = files.map((f) => f.split("_")[0]);
  const duplicatePrefixes = versionPrefixes.filter((v, i, arr) => arr.indexOf(v) !== i);
  if (duplicatePrefixes.length > 0) {
    console.error(
      `❌ Migration runner error: Duplicate migration version prefixes detected: ${duplicatePrefixes.join(", ")}`
    );
    process.exit(1);
  }

  // 2. READ-ONLY PREFLIGHT INSPECTION:
  // Check whether public.schema_migrations and public.users exist before executing any DDL or migration SQL.
  const tablesRes = await pool.query(`
    SELECT table_name FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name IN ('schema_migrations', 'users')
  `);
  const existingTables = new Set(tablesRes.rows.map((r) => r.table_name));
  const hasSchemaMigrations = existingTables.has("schema_migrations");
  const hasUsers = existingTables.has("users");

  // 3. TRACKING-TABLE INCONSISTENCY GUARD:
  // If schema_migrations exists but users does not, inspect tracking table records safely.
  // If it contains migration records while users is absent, abort before any mutation.
  if (!hasUsers && hasSchemaMigrations) {
    const trackingCountRes = await pool.query("SELECT COUNT(*) AS count FROM schema_migrations");
    const trackingCount = parseInt(trackingCountRes.rows[0].count, 10);
    if (trackingCount > 0) {
      console.error("❌ CRITICAL MIGRATION SAFETY ERROR: Inconsistent database detected.");
      console.error("   Table 'schema_migrations' exists and contains records, but table 'users' is missing.");
      console.error("   Refusing to treat database as fresh or execute migrations against an unknown state.");
      process.exit(1);
    }
  }

  // 4. EXISTING DATABASE & PHASE 7 BASELINE VALIDATION:
  if (hasUsers) {
    console.log("Existing database detected with 'users' table present.");

    // A. Approved Phase 7 baseline criteria: users.nin_encrypted and users.account_status must both exist.
    const phase7Check = await pool.query(`
      SELECT column_name FROM information_schema.columns 
      WHERE table_schema = 'public' AND table_name = 'users' 
        AND column_name IN ('nin_encrypted', 'account_status')
    `);
    const phase7Columns = new Set(phase7Check.rows.map((r) => r.column_name));
    const isPhase7 = phase7Columns.has("nin_encrypted") && phase7Columns.has("account_status");

    if (!isPhase7) {
      console.error("❌ CRITICAL MIGRATION SAFETY ERROR: Unrecognized existing database schema detected.");
      console.error("   Table 'users' exists, but required Phase 7 baseline columns ('nin_encrypted', 'account_status') are missing.");
      console.error("   Aborting before executing any DDL or migration SQL to prevent data corruption or schema drift.");
      console.error("   Manual database inspection is required before running migrations.");
      process.exit(1);
    }

    // B. Safe baseline handling: verify read-only that required tables and columns used by migration 010 are present
    // before recording migrations 001–009 as applied.
    const m010TablesRes = await pool.query(`
      SELECT table_name FROM information_schema.tables 
      WHERE table_schema = 'public' AND table_name IN ('order_items', 'quote_requests')
    `);
    const m010Tables = new Set(m010TablesRes.rows.map((r) => r.table_name));
    const missingTables = ["order_items", "quote_requests"].filter((t) => !m010Tables.has(t));
    if (missingTables.length > 0) {
      console.error("❌ CRITICAL MIGRATION SAFETY ERROR: Incomplete existing schema detected.");
      console.error(`   Required table(s) for migration 010 are missing: ${missingTables.join(", ")}`);
      console.error("   Aborting before inserting baseline records or executing migration SQL.");
      process.exit(1);
    }

    const m010ColumnsRes = await pool.query(`
      SELECT table_name, column_name FROM information_schema.columns 
      WHERE table_schema = 'public' AND (
        (table_name = 'users' AND column_name IN ('role', 'verification_status')) OR
        (table_name = 'order_items' AND column_name IN ('product_id', 'vendor_id')) OR
        (table_name = 'quote_requests' AND column_name IN ('distributor_id', 'status'))
      )
    `);
    const existingCols = new Set(m010ColumnsRes.rows.map((r) => `${r.table_name}.${r.column_name}`));
    const requiredCols = [
      "users.role",
      "users.verification_status",
      "order_items.product_id",
      "order_items.vendor_id",
      "quote_requests.distributor_id",
      "quote_requests.status",
    ];
    const missingCols = requiredCols.filter((c) => !existingCols.has(c));
    if (missingCols.length > 0) {
      console.error("❌ CRITICAL MIGRATION SAFETY ERROR: Incomplete existing schema detected.");
      console.error(`   Required column(s) for migration 010 are missing: ${missingCols.join(", ")}`);
      console.error("   Aborting before inserting baseline records or executing migration SQL.");
      process.exit(1);
    }

    console.log("Confirmed Phase 7 database schema features and migration 010 dependencies are present.");
  } else {
    console.log("Fresh/empty database detected (no 'users' table). Running full migration sequence from 001...");
  }

  // 5. ENSURE TRACKING TABLE EXISTS (Executed only after schema safety validation passes)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      id SERIAL PRIMARY KEY,
      version VARCHAR(255) UNIQUE NOT NULL,
      applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `);

  // 6. ESTABLISH BASELINE FOR PHASE 7 DATABASE:
  // If users table exists and all validations passed, record historical migrations 001..009
  // as applied so their SQL bodies are NEVER re-executed.
  if (hasUsers) {
    const baselineFiles = files.filter((f) => {
      const num = parseInt(f.split("_")[0], 10);
      return num >= 1 && num <= 9;
    });

    for (const file of baselineFiles) {
      await pool.query(
        "INSERT INTO schema_migrations (version) VALUES ($1) ON CONFLICT (version) DO NOTHING",
        [file]
      );
    }
    console.log("📌 Baseline recorded for migrations 001 through 009.");
  }

  // 7. QUERY ALL APPLIED MIGRATION VERSIONS
  const appliedRes = await pool.query("SELECT version FROM schema_migrations");
  const appliedVersions = new Set(appliedRes.rows.map((r) => r.version));

  // 8. EXECUTE ONLY GENUINELY PENDING MIGRATIONS IN TRANSACTIONS
  for (const file of files) {
    if (appliedVersions.has(file)) {
      console.log(`⏩ Already applied: ${file}`);
      continue;
    }

    const filePath = path.join(migrationsDir, file);
    const sql = fs.readFileSync(filePath, "utf8");
    console.log(`Running migration: ${file}...`);

    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      await client.query(sql);
      await client.query("INSERT INTO schema_migrations (version) VALUES ($1)", [file]);
      await client.query("COMMIT");
      console.log(`✅ Done: ${file}`);
      appliedVersions.add(file);
    } catch (err) {
      await client.query("ROLLBACK");
      console.error(`❌ Migration failed in ${file}. Transaction rolled back.`);
      throw err;
    } finally {
      client.release();
    }
  }

  console.log("All migrations verified and up to date.");
  process.exit(0);
}

runMigrations().catch((err) => {
  console.error("❌ Migration runner error:", err.message);
  process.exit(1);
});
