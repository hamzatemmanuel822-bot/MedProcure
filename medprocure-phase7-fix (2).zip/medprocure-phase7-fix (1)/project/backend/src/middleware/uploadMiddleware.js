// uploadMiddleware.js
// Used for logged-in distributors uploading (or replacing) their license document
// AFTER signup, from the dashboard.

const multer = require("multer");
const path = require("path");
const fs = require("fs");

const uploadDir = path.join(__dirname, "..", "..", "uploads", "verification-docs");
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `user${req.user.id}_${Date.now()}_${crypto_randomHex()}${ext}`);
  },
});

// small local helper so we don't need a top-level crypto import collision
function crypto_randomHex() {
  return require("crypto").randomBytes(6).toString("hex");
}

const allowedExt = [".pdf", ".jpg", ".jpeg", ".png"];
const allowedMime = ["application/pdf", "image/jpeg", "image/png", "image/jpg"];

function fileFilter(req, file, cb) {
  const ext = path.extname(file.originalname).toLowerCase();
  if (!allowedExt.includes(ext) || !allowedMime.includes(file.mimetype)) {
    return cb(new Error("Only PDF, JPG, or PNG files are allowed."));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
});

module.exports = upload;
