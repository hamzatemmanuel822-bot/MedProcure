// authMiddleware.js
const jwt = require("jsonwebtoken");
const pool = require("../config/db");

function requireAuth(req, res, next) {
  const authHeader = req.headers["authorization"];
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "No access token provided. Please log in." });
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired token. Please log in again." });
  }
}

function requireRole(allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: "You do not have permission to do this." });
    }
    next();
  };
}

// Blocks a terminated distributor from taking seller actions (listing, editing, viewing
// incoming quotes) even if they still hold a valid, unexpired JWT from before termination.
// A JWT alone can't reflect a status change that happened after it was issued, so this
// checks the current database state on the specific actions that matter.
async function blockIfTerminated(req, res, next) {
  try {
    const result = await pool.query("SELECT account_status FROM users WHERE id = $1", [req.user.id]);
    if (result.rows[0]?.account_status === "terminated") {
      return res.status(403).json({ error: "Your account has been terminated for violating platform policy." });
    }
    next();
  } catch (err) {
    console.error("blockIfTerminated error:", err.message);
    return res.status(500).json({ error: "Could not verify account status." });
  }
}

module.exports = { requireAuth, requireRole, blockIfTerminated };
