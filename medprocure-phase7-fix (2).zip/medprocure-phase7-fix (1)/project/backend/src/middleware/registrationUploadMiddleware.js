// registrationUploadMiddleware.js
// Used only on the public registration route (no logged-in user yet).
// Handles TWO files at once for Distributor signup: the business license/certificate
// AND the ID verification photo (selfie or photo of a government ID) required for KYC.

const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

// Stored in a folder that is NEVER served publicly (see server.js) — only accessible
// through an authenticated, admin-only endpoint. This matters because these are
// sensitive identity documents, not public product photos.
const uploadDir = path.join(__dirname, "..", "..", "uploads", "verification-docs");
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const randomId = crypto.randomBytes(10).toString("hex"); // unguessable filename
    const prefix = file.fieldname === "idPhoto" ? "idphoto" : file.fieldname === "proofOfAddress" ? "address" : "license";
    cb(null, `${prefix}_${randomId}${ext}`);
  },
});

const allowedExt = [".pdf", ".jpg", ".jpeg", ".png"];
const allowedMime = ["application/pdf", "image/jpeg", "image/png", "image/jpg"];

function fileFilter(req, file, cb) {
  const ext = path.extname(file.originalname).toLowerCase();
  if (!allowedExt.includes(ext) || !allowedMime.includes(file.mimetype)) {
    return cb(new Error("Only PDF, JPG, or PNG files are allowed."));
  }
  cb(null, true);
}

const registrationUpload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024, files: 3 },
});

// Accepts up to one file per named field — used with .fields() so a Distributor
// signup can submit both documents in a single multipart request.
const distributorSignupFiles = registrationUpload.fields([
  { name: "licenseDocument", maxCount: 1 },
  { name: "idPhoto", maxCount: 1 },
  { name: "proofOfAddress", maxCount: 1 },
]);

module.exports = { distributorSignupFiles };
