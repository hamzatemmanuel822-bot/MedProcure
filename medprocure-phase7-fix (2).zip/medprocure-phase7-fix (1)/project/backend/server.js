// server.js
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");

const authRoutes = require("./src/routes/authRoutes");
const productRoutes = require("./src/routes/productRoutes");
const cartRoutes = require("./src/routes/cartRoutes");
const orderRoutes = require("./src/routes/orderRoutes");
const distributorRoutes = require("./src/routes/distributorRoutes");
const adminRoutes = require("./src/routes/adminRoutes");
const statsRoutes = require("./src/routes/statsRoutes");
const quoteRoutes = require("./src/routes/quoteRoutes");
const { handleStripeWebhook } = require("./src/controllers/orderController");
const { authLimiter, generalLimiter } = require("./src/middleware/rateLimiter");

const app = express();

// --- Security & general middleware ---
app.use(helmet()); // sets a batch of protective HTTP headers

// CORS is locked to your actual frontend origin (set in .env) rather than left wide open —
// this stops random websites from making authenticated requests to your API on a victim's behalf.
// CORS: in local development, the frontend can be served from several different addresses
// depending on your tool (Live Server default port, VS Code extension variants, etc.) — locking
// to one exact URL breaks the app the moment it doesn't match perfectly. Instead, we accept any
// localhost/127.0.0.1 origin (safe for local dev, since only your own machine can reach it) plus
// whatever you've explicitly set as CLIENT_URL for a real deployment.
const explicitOrigin = process.env.CLIENT_URL;
const localOriginPattern = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/;

app.use(
  cors({
    origin: (origin, callback) => {
      // Requests with no Origin header (e.g. curl, some server-to-server calls) are allowed.
      if (!origin) return callback(null, true);
      if (localOriginPattern.test(origin)) return callback(null, true);
      if (explicitOrigin && origin === explicitOrigin) return callback(null, true);
      return callback(new Error("Not allowed by CORS"));
    },
    credentials: true,
  })
);

app.use(generalLimiter);

// IMPORTANT: the Stripe webhook route MUST be registered before express.json() below —
// Stripe needs the raw, untouched request body to verify the request really came from them.
app.post("/api/orders/webhook", express.raw({ type: "application/json" }), handleStripeWebhook);

app.use(express.json({ limit: "1mb" })); // cap JSON body size — a basic defense against payload-flood abuse

// NOTE: verification documents (license, NIN photo) are intentionally NOT served as public
// static files. They're only accessible through the authenticated, admin-only route in
// adminRoutes.js (GET /api/admin/distributors/:id/document) — see adminController.js.

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "MedProcure API is running." });
});

app.use("/api/auth", authLimiter, authRoutes); // extra-strict rate limit on login/register
app.use("/api/products", productRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/distributors", distributorRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/stats", statsRoutes);
app.use("/api/quotes", quoteRoutes);

app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.originalUrl} not found.` });
});

// Generic error handler — never leak stack traces or internals to the client
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err.message);
  res.status(err.status || 500).json({ error: "Something went wrong on our end." });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
