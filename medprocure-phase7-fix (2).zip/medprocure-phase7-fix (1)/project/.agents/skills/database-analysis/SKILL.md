# Database Analysis Skill

## Purpose

Analyze the existing MedProcure database and determine whether its schema, migrations, relationships, constraints, indexes, and data-access patterns support the approved architecture and technical specification.

This is an existing-project analysis task.

Do NOT create a replacement database architecture simply because another design may be preferable.

## Inputs

Read and use, where available:

- .agents/agents.md
- production_artifacts/project_audit.md
- production_artifacts/architecture_analysis.md
- production_artifacts/Technical_Specification.md
- production_artifacts/implementation_plan.md
- existing database configuration
- schema files
- migrations
- seed files
- backend database models
- API/database access code
- existing phase documentation

## Analysis Areas

Inspect:

1. Database technology and configuration
2. Database connection configuration
3. Schema structure
4. Tables
5. Columns and data types
6. Primary keys
7. Foreign keys
8. Relationships
9. Unique constraints
10. Check constraints
11. Indexes
12. Migration history
13. Seed data
14. ORM models or database access layer
15. Transactions
16. Data validation
17. Referential integrity
18. Sensitive data storage
19. Authentication-related data
20. KYC-related data
21. NIN-related data
22. Identity-document metadata
23. User and admin data
24. Audit/history records
25. Potential duplicate or obsolete structures
26. Performance concerns
27. Security concerns
28. Migration risks
29. Compatibility with the approved architecture
30. Compatibility with the approved technical specification

## Safety Rules

Do not:

- drop databases
- delete tables
- delete migrations
- destroy production data
- modify production data
- rewrite the schema during analysis
- invent missing database structures
- expose real secrets
- expose real NIN data
- expose real identity-document data

If a database change appears necessary, document it as a recommendation unless the approved implementation plan explicitly authorizes the change.

## Migration Safety

For proposed database changes, identify:

- affected tables
- affected relationships
- existing data that could be affected
- migration order
- backward-compatibility concerns
- rollback considerations
- risks of data loss
- whether a backup or approval is required

Never assume a destructive migration is safe.

## Output

Create:

production_artifacts/database_analysis.md

The report must contain:

# Database Analysis

## Executive Summary

## Current Database Technology

## Database Configuration

## Schema Overview

## Tables

## Relationships

## Constraints

## Indexes

## Migrations

## Seed Data

## Backend Database Integration

## Authentication Data

## KYC and NIN Data

## Identity Documents

## User and Admin Data

## Data Integrity

## Security Review

## Performance Considerations

## Problems Found

## Risks

## Recommended Changes

## Migration Plan Considerations

## Compatibility With Approved Architecture

## Compatibility With Technical Specification

## Compatibility With Implementation Plan

## Final Assessment

Each important finding should include evidence from the existing project.

If something cannot be verified, mark it as:

NOT VERIFIED

Do not present assumptions as facts.

## Completion Rule

The database analysis is complete only when the report has been written to:

production_artifacts/database_analysis.md

and the report accurately reflects the actual existing MedProcure database implementation.
