﻿# MedProcure QA and Testing Skill

## Objective

Verify that the MedProcure implementation works correctly through actual testing.

QA must provide evidence for test results and must never claim that something passed without running the relevant test.

## Required Inputs

Before testing, inspect:

- `production_artifacts/Technical_Specification.md`
- `production_artifacts/implementation_plan.md`
- Relevant existing project documentation
- Existing tests
- The actual implementation being tested

## Testing Responsibilities

Test:

- Backend functionality
- Frontend functionality
- API endpoints
- Authentication
- Authorization and role permissions
- KYC workflows
- Identity-document upload behavior
- NIN-related functionality where applicable
- Database operations
- Validation and error handling
- File-upload security controls
- Critical user workflows
- Regression risks from changes

## Testing Rules

1. Run the appropriate automated tests when they exist.
2. Run relevant manual verification when automated tests are insufficient.
3. Record the exact commands used where practical.
4. Record actual results.
5. Reproduce reported failures before attempting to fix them.
6. After a fix, run the relevant test again.
7. Check for regressions in related functionality.
8. Never mark a test as passed because code "looks correct."
9. Never claim a test was run if it was not run.
10. Never hide a failing test.

## Failure Handling

When a test fails:

1. Record the failure.
2. Identify the affected component.
3. Determine the likely cause.
4. Fix the issue only when implementation work has been authorized.
5. Re-run the failing test.
6. Run related regression tests.
7. Record the final result.

If a failure cannot be fixed safely, report it clearly rather than masking it.

## Security-Sensitive Testing

Pay particular attention to:

- Unauthorized access
- Privilege escalation
- Authentication bypass
- Broken role permissions
- Weak input validation
- SQL injection risks
- Cross-site scripting risks
- CSRF risks where applicable
- Sensitive information exposure
- Insecure file uploads
- Unsafe file types
- Path traversal
- Session and token handling
- Password handling
- KYC and identity-document exposure

Do not use real sensitive personal information for testing when test data can be used instead.

## Output

Save the test results to:

`production_artifacts/test_report.md`

The report must include:

1. Test scope
2. Environment
3. Tests executed
4. Commands used where relevant
5. Passed tests
6. Failed tests
7. Blocked tests
8. Defects discovered
9. Fixes performed
10. Regression testing
11. Security-related findings
12. Final QA status

## Truthfulness Requirement

A test may only be marked:

- PASS  if it was actually executed and passed.
- FAIL  if it was executed and failed.
- BLOCKED  if it could not be executed because of a documented blocker.
- NOT RUN  if it has not been executed.

Never substitute assumptions for test evidence.
