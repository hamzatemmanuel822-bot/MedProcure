﻿# MedProcure DevOps Skill

## Objective

Bring the approved MedProcure implementation into a verified local development environment and validate its build, startup, configuration, and deployment readiness.

DevOps works with the existing MedProcure project. It does not create a duplicate application.

## Required Inputs

Before making infrastructure or environment changes, inspect:

- `production_artifacts/Technical_Specification.md`
- `production_artifacts/implementation_plan.md`
- Existing Docker configuration
- Existing environment configuration
- Backend package/dependency configuration
- Frontend package/dependency configuration
- Database configuration and migrations
- Existing deployment documentation
- Existing phase documentation

## Existing-Project Rule

Work with the existing MedProcure repository.

Do not create an `app_build/` application.

Do not replace the application's architecture merely to simplify deployment.

Do not overwrite `.env` files containing user configuration or secrets.

## Responsibilities

Manage and verify:

- Docker configuration
- PostgreSQL configuration
- Database migrations
- Backend dependencies
- Frontend dependencies
- Environment variables
- Local application startup
- Health checks
- Build verification
- Service connectivity
- Application logs
- Deployment configuration

## Environment and Secrets

Never expose:

- Passwords
- API keys
- Access tokens
- Private keys
- Database credentials
- Other secrets

Never commit secrets to source control.

If an environment variable is missing, identify the variable without printing its secret value.

Do not overwrite an existing `.env` file without explicit approval.

Prefer `.env.example` or documented placeholder configuration when appropriate.

## Database Safety

Before running migrations:

1. Inspect the migration files.
2. Understand the expected schema changes.
3. Confirm the target environment.
4. Check whether the migration is destructive.
5. Back up important data when appropriate.

Never:

- Drop a production database
- Reset a production database
- Delete production data
- Run destructive database commands without explicit approval

For local development, database resets are allowed only when explicitly required and safe for the development environment.

## Docker

Before changing Docker configuration:

1. Inspect existing `Dockerfile` files.
2. Inspect `docker-compose.yml` or equivalent configuration.
3. Understand service dependencies.
4. Preserve working configuration unless a change is justified.

After changes, verify:

- Images build successfully
- Containers start successfully
- Services can communicate
- Database connectivity works
- Health checks pass where configured
- Application logs show no blocking errors

## Startup Verification

A successful DevOps validation should establish, where applicable:

1. Dependencies can be installed.
2. Database services start.
3. Migrations execute successfully.
4. Backend starts successfully.
5. Frontend builds successfully.
6. Frontend starts successfully.
7. Backend and frontend can communicate.
8. Health endpoints respond correctly.
9. Critical application functionality can be reached.

Do not claim successful startup without actually starting and checking the relevant services.

## Troubleshooting

When something fails:

1. Capture the error.
2. Identify the affected service.
3. Inspect relevant logs.
4. Determine the likely cause.
5. Apply the smallest safe correction.
6. Re-run the failed check.
7. Check for regressions.

Do not hide or suppress errors merely to make a build appear successful.

## Output

Save the DevOps report to:

`production_artifacts/deployment_report.md`

The report must include:

1. Environment
2. Configuration reviewed
3. Dependencies
4. Database status
5. Migration status
6. Docker status
7. Build status
8. Startup status
9. Health-check status
10. Errors encountered
11. Fixes performed
12. Remaining blockers
13. Deployment readiness

## Truthfulness

Use these statuses where appropriate:

- PASS  actually verified
- FAIL  actually tested and failed
- BLOCKED  could not be verified because of a documented blocker
- NOT VERIFIED  not checked

Never claim a build, service, migration, health check, or deployment is successful unless it was actually verified.
