﻿# MedProcure Implementation Plan Skill

## Objective

Create a safe, ordered implementation plan for the existing MedProcure project based on the approved Technical Specification.

This skill plans the work. It does not implement the work.

## Required Inputs

Before creating the plan, inspect:

- `production_artifacts/Technical_Specification.md`
- `production_artifacts/project_audit.md`
- `production_artifacts/architecture_analysis.md`
- Relevant existing project documentation
- Existing phase documentation

The Technical Specification must have received explicit human approval before implementation planning is finalized for execution.

## Existing-Project Rule

Modify the existing MedProcure project in place when implementation eventually begins.

Do not create a duplicate application.

Do not use or create an `app_build/` application directory.

Do not discard existing working functionality without documenting the reason.

## Planning Requirements

The implementation plan must identify:

1. Implementation phases
2. Tasks in each phase
3. Dependencies between tasks
4. Files or components likely to be affected
5. Database changes
6. API changes
7. Frontend changes
8. Backend changes
9. Authentication and authorization changes
10. KYC and identity-document changes
11. Security considerations
12. Testing requirements
13. Migration requirements
14. Environment/configuration requirements
15. Deployment considerations
16. Risks
17. Rollback or recovery considerations
18. Human approval checkpoints

## Database Safety

Database changes must be explicitly identified.

Never:

- Drop the production database
- Delete production data
- Run destructive migrations without explicit approval
- Reset a database containing important data
- Assume a migration is safe without reviewing its impact

Prefer additive and reversible changes where practical.

## Implementation Discipline

For major changes:

1. Inspect the existing implementation.
2. Check dependencies.
3. Check the current Git status.
4. Identify affected components.
5. Document the proposed change.
6. Identify risks.
7. Implement incrementally.
8. Test the change.
9. Review the result before proceeding.

Do not make broad destructive changes simply to make the project easier to modify.

## Output

Save the plan to:

`production_artifacts/implementation_plan.md`

The plan must be specific enough that an engineer can execute it step by step.

## Approval Boundary

Do not begin implementation while creating this plan.

If the Technical Specification has not been explicitly approved, stop and request approval.

Never claim that an implementation task is complete unless it has actually been performed and verified.
