# Final Validation Skill

## Purpose

Perform the final verification of the existing MedProcure project after implementation, QA, security review, database analysis, and deployment verification.

The final validation must confirm that the completed work matches the approved requirements, Technical Specification, and implementation plan.

This is an existing-project validation task.

Do NOT create a replacement application.

## Inputs

Read and use:

- .agents/agents.md
- production_artifacts/project_audit.md
- production_artifacts/architecture_analysis.md
- production_artifacts/Technical_Specification.md
- production_artifacts/implementation_plan.md
- production_artifacts/database_analysis.md
- production_artifacts/test_report.md
- production_artifacts/security_audit.md
- production_artifacts/deployment_report.md
- existing phase documentation
- the actual implemented backend
- the actual implemented frontend
- the actual database/migrations
- relevant configuration and deployment files

## Validation Areas

Verify:

1. Requirements were addressed.
2. The implementation matches the approved Technical Specification.
3. The implementation matches the approved implementation plan.
4. Backend functionality is present and consistent with the specification.
5. Frontend functionality is present and consistent with the specification.
6. API functionality is present and consistent with the specification.
7. Authentication works as intended.
8. Authorization and role permissions work as intended.
9. KYC functionality works as intended.
10. NIN-related functionality follows the approved requirements.
11. Identity-document handling follows the approved requirements.
12. Database changes match the approved design.
13. Database migrations are accounted for.
14. QA tests were actually executed.
15. Security review was completed.
16. Deployment checks were completed.
17. Known limitations are documented.
18. Required production artifacts exist.
19. No unauthorized destructive changes were made.
20. The existing MedProcure application remains the actual application.

## Evidence Rules

Do not assume something works simply because code exists.

Use available evidence from:

- executed tests
- build results
- application startup
- API verification
- database verification
- security testing
- deployment checks
- implementation artifacts
- source code inspection

If something cannot be verified, mark it:

NOT VERIFIED

If a required test was not executed, do not mark it PASS.

## Statuses

Use only these statuses:

- PASS
- FAIL
- BLOCKED
- NOT VERIFIED

## Safety Rules

Never:

- expose secrets
- expose real NIN data
- expose real identity-document data
- modify production data
- drop production databases
- delete project files
- reset or discard user work
- claim success without evidence

## Output

Create:

production_artifacts/final_validation.md

The report must contain:

# Final Validation

## Executive Summary

## Approved Requirements

## Technical Specification Validation

## Implementation Plan Validation

## Backend Validation

## Frontend Validation

## API Validation

## Authentication Validation

## Authorization Validation

## KYC Validation

## NIN Validation

## Identity-Document Validation

## Database Validation

## QA Validation

## Security Validation

## Deployment Validation

## Production Artifacts Validation

## Known Limitations

## Risks

## Unauthorized Changes Check

## Final Status

The final status must clearly state:

PASS, FAIL, BLOCKED, or NOT VERIFIED

Do not use PASS unless the available evidence supports it.

## Completion Rule

The final validation is complete only when the report has been written to:

production_artifacts/final_validation.md

and every major validation area has a documented status and supporting evidence.
