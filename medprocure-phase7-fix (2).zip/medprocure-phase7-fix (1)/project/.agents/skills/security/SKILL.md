﻿# MedProcure Security Skill

## Objective

Review the MedProcure system for security weaknesses and verify that security controls are appropriately implemented.

Security review must be based on the actual existing implementation, not assumptions.

## Required Inputs

Before performing the security review, inspect:

- `production_artifacts/project_audit.md`
- `production_artifacts/architecture_analysis.md`
- `production_artifacts/Technical_Specification.md`
- Relevant backend code
- Relevant frontend code
- Database configuration and migrations
- Authentication and authorization implementation
- File-upload implementation
- KYC-related implementation
- Existing security documentation

## Security Scope

Review:

### Authentication

- Login
- Registration
- Password handling
- Password reset
- Session management
- Access tokens
- Refresh tokens
- Authentication expiration
- Logout behavior

### Authorization

- Role-based access control
- Admin permissions
- User permissions
- Resource ownership
- Privilege escalation
- Unauthorized API access
- Backend authorization enforcement

### Input and API Security

- Input validation
- Output encoding
- SQL injection
- Cross-site scripting
- CSRF where applicable
- API abuse
- Rate limiting where appropriate
- Error-message information leakage

### KYC and Sensitive Data

Pay particular attention to:

- NIN-related data
- Identity documents
- Uploaded files
- Personal information
- Sensitive API responses
- Storage permissions
- Access controls
- Logging of sensitive information

Do not expose real sensitive information in reports.

### File Upload Security

Review:

- Allowed file types
- MIME validation
- File extension validation
- File size limits
- Filename handling
- Storage location
- Path traversal protection
- Malicious file handling
- Access control for uploaded documents

### Database Security

Review:

- Database credentials
- Connection configuration
- ORM/query safety
- Migration safety
- Access controls
- Sensitive fields
- Secret handling

### Configuration and Secrets

Check for:

- Hard-coded credentials
- API keys
- Tokens
- Private keys
- Secrets committed to source control
- Unsafe environment-variable handling
- Insecure default configuration

Never print or expose the actual secret values.

## Security Testing

Where appropriate, perform safe security tests against the local/development environment.

Do not attack production systems.

Do not destroy data.

Do not perform destructive security testing without explicit approval.

## Findings

Classify findings using:

- Critical
- High
- Medium
- Low
- Informational

Each finding should include:

1. Title
2. Severity
3. Affected component
4. Description
5. Evidence
6. Risk
7. Recommended remediation
8. Verification method

Do not claim a vulnerability exists without evidence.

Do not claim a vulnerability is fixed unless the fix was actually implemented and verified.

## Output

Save the security review to:

`production_artifacts/security_audit.md`

The report must include:

1. Executive Summary
2. Scope
3. Authentication Review
4. Authorization Review
5. API Security Review
6. KYC and Sensitive Data Review
7. File Upload Review
8. Database Security Review
9. Configuration and Secrets Review
10. Findings
11. Risk Summary
12. Recommended Remediation
13. Verification Status

## Safety

Never expose:

- Passwords
- API keys
- Tokens
- Private keys
- Database credentials
- Real NIN values
- Real identity-document contents
- Other sensitive personal information

Use redaction when evidence must be documented.

## Truthfulness

Only report what was actually inspected or tested.

If an area could not be reviewed, mark it as:

`NOT VERIFIED`

and explain why.
