﻿# MedProcure Write Specs Skill

## Objective

Turn the user's approved requirements, the project audit, and the architecture analysis into a rigorous technical specification for the existing MedProcure project.

This skill must produce a specification and then stop for human approval before implementation proceeds.

## Inputs

Before writing the specification, inspect and use:

- `production_artifacts/project_audit.md`
- `production_artifacts/architecture_analysis.md`
- Existing MedProcure documentation
- Existing phase documentation
- Relevant requirements provided by the user

Do not invent information that has not been established.

## Existing-Project Rule

MedProcure is an existing application.

The specification must be based on the current project unless there is a documented technical reason to change something.

Do not assume that a new application should be created.

Do not create or recommend an `app_build/` duplicate application.

Do not replace the existing backend, frontend, database, framework, or architecture merely because another technology is preferred.

Any proposed technology change must include:

1. The current technology
2. The proposed technology
3. The technical reason for the change
4. Benefits
5. Risks
6. Migration impact

## Required Specification

The specification must include:

1. Executive Summary
2. Project Context
3. Existing-System Findings
4. Functional Requirements
5. Non-Functional Requirements
6. User Roles and Permissions
7. Application Architecture
8. Frontend Architecture
9. Backend Architecture
10. Database Architecture
11. API Structure
12. Authentication and Authorization
13. KYC and Identity-Document Handling
14. Security Requirements
15. Data Flow
16. Error Handling
17. Testing Requirements
18. Deployment Requirements
19. Dependencies
20. Risks
21. Implementation Boundaries
22. Items Requiring Human Approval

## Architecture & Technology

Do not choose technologies in isolation.

First analyze the existing MedProcure stack.

Retain existing technologies when they are suitable.

Recommend changes only when supported by the project audit and architecture analysis.

The specification must explain why each major architectural decision was made.

## Approval Gate

After creating the specification:

1. Save it to:

`production_artifacts/Technical_Specification.md`

2. Do not begin implementation.
3. Do not modify application code.
4. Do not modify the database.
5. Explicitly ask the user:

"Do you approve of this technical specification and architecture?"

The workflow must pause until the user provides approval or feedback.

## Iterative Rework

If the user provides feedback:

1. Read the existing `Technical_Specification.md`.
2. Apply the requested changes.
3. Save the updated specification.
4. Clearly identify what changed.
5. Ask for approval again.
6. Do not continue to implementation until approval is explicitly given.

## Safety

Do not expose secrets, credentials, tokens, private keys, or sensitive personal information.

Do not claim that requirements, architecture, tests, or technologies were verified unless they were actually inspected.

Do not silently resolve major contradictions. Record them and identify them for human decision where necessary.
