﻿# MedProcure Architecture Analysis Skill

## Purpose

Analyze the architecture of the existing MedProcure project after the project audit.

The goal is to understand how the current system is structured and determine what should be retained, improved, restructured, or replaced.

## Scope

Analyze:

- Backend architecture
- Frontend architecture
- Database architecture
- API architecture
- Authentication and authorization
- KYC and identity-document workflows
- NIN-related handling
- Admin and role-based access
- File-upload architecture
- External integrations
- Environment configuration
- Testing architecture
- Docker and deployment architecture
- Dependencies between system components

## Existing-Project Rule

The existing MedProcure project is the application being analyzed.

Do not assume that a new application should be created.

Do not create or recommend an `app_build/` duplicate application.

Prefer improving the existing architecture when it is technically sound.

Recommend replacing an existing technology or architectural component only when there is a clear technical reason supported by the audit.

## Required Analysis

Identify:

1. Current architecture
2. Current technology stack
3. Component responsibilities
4. Data flow
5. API and service boundaries
6. Database relationships and dependencies
7. Authentication and authorization flow
8. KYC and sensitive-data flow
9. Frontend/backend integration
10. Deployment architecture
11. Architectural strengths
12. Architectural weaknesses
13. Technical debt
14. Security-sensitive architectural risks
15. Scalability and reliability risks
16. Recommended architectural improvements

## Safety

This skill is analysis-only.

Do not modify application code.

Do not modify the database.

Do not delete files.

Do not overwrite configuration.

Do not expose secrets, credentials, tokens, private keys, or sensitive user information.

Do not claim that something was verified unless it was actually inspected.

## Output

Save the analysis to:

`production_artifacts/architecture_analysis.md`

The report should clearly distinguish:

- Existing architecture
- Observed problems
- Recommended changes
- Reason for each recommendation
- Risks and dependencies
- Items requiring human approval

## Approval Boundary

Architecture analysis may make recommendations, but it must not implement major architectural changes.

Major restructuring must wait for the approved technical specification and implementation plan.
