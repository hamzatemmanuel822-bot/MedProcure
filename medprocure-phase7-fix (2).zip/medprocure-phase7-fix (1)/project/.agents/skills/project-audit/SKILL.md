﻿# MedProcure Project Audit Skill

## Purpose

Audit the existing MedProcure project before any major implementation or restructuring.

The audit must understand the current system before recommending changes.

## Scope

Inspect:

- Existing backend structure
- Existing frontend structure
- Database and migrations
- API routes and services
- Authentication and authorization
- KYC and NIN-related workflows
- Identity-document uploads
- Admin functionality
- Existing tests
- Docker and deployment configuration
- Environment-variable usage
- Existing documentation
- Existing phase implementation
- Dependencies and package configuration
- Existing security-sensitive areas

## Required Behavior

1. Inspect the existing project before proposing changes.
2. Do not create a duplicate application.
3. Do not create or use an `app_build/` directory for the application.
4. Do not delete or overwrite existing application code during the audit.
5. Do not modify production data.
6. Do not expose secrets, credentials, tokens, or private keys.
7. Preserve existing phase documentation.
8. Identify obsolete, duplicated, incomplete, or conflicting implementation areas.
9. Identify dependencies between frontend, backend, database, authentication, KYC, and deployment.
10. Record findings clearly enough for another agent to act on them.

## Output

Create the audit report at:

`production_artifacts/project_audit.md`

The report should contain:

1. Executive Summary
2. Current Project Structure
3. Backend Findings
4. Frontend Findings
5. Database Findings
6. Authentication and Authorization Findings
7. KYC and Identity-Document Findings
8. API Findings
9. Testing Findings
10. Security Findings
11. Deployment and DevOps Findings
12. Documentation Findings
13. Existing Strengths
14. Existing Problems
15. Risks
16. Recommended Next Steps

## Important Rule

The project audit is an inspection activity.

Do not implement fixes while performing the audit unless a separate approved workflow explicitly authorizes implementation.

Never claim that something was inspected, tested, verified, or completed unless it was actually performed.
