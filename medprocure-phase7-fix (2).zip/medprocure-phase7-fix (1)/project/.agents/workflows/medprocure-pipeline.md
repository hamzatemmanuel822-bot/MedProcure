# MedProcure Autonomous Development Pipeline

## Purpose

This workflow controls the safe end-to-end development of the existing MedProcure project.

The workflow must improve and re-engineer the existing MedProcure repository. It must NOT create a duplicate application in app_build/.

## Phase 1  Preflight

Before doing any implementation:

1. Read .agents/agents.md.
2. Read all relevant skills under .agents/skills/.
3. Inspect the existing repository structure.
4. Inspect Git status. If the project is not a Git repository, record Git as NOT AVAILABLE / NOT VERIFIED and do not initialize Git unless explicitly approved.
5. Read existing phase documentation, including:
   - PHASE6_KYC_SECURITY_SETUP.md
   - PHASE7_APPROVAL_FLOW_SETUP.md
6. Inspect the existing backend, frontend, database, migrations, tests, configuration, Docker files, and documentation.

Do not modify application code during preflight.

## Phase 2  Existing Project Audit

Run the project-audit skill.

Produce:

production_artifacts/project_audit.md

The audit must identify:

- existing architecture
- backend
- frontend
- database
- APIs
- authentication
- authorization
- KYC
- NIN-related functionality
- identity-document handling
- admin functionality
- testing
- security
- deployment
- duplicated code
- obsolete code
- incomplete functionality
- conflicting implementations
- technical risks

Do not implement changes during the audit.

## Phase 3  Architecture Analysis

After the audit, run the rchitecture-analysis skill.

Produce:

production_artifacts/architecture_analysis.md

The analysis must determine how the existing MedProcure system should be improved while preserving useful existing functionality.

Do not replace the technology stack without technical justification.

Do not implement code during this phase.

## Phase 4  Technical Specification

Run the write-specs skill using:

- project audit
- architecture analysis
- existing project documentation
- approved user requirements

Produce:

production_artifacts/Technical_Specification.md

The specification must describe the proposed implementation clearly enough for an engineer to execute.

### HUMAN APPROVAL GATE

STOP after producing the Technical Specification.

Ask the human:

"Do you approve of this technical specification and architecture?"

Do not continue to implementation planning until explicit approval is received.

If the human requests changes, update the specification and ask for approval again.

## Phase 5  Implementation Planning

After Technical Specification approval, run the implementation-plan skill.

Produce:

production_artifacts/implementation_plan.md

The plan must include:

- implementation phases
- ordered tasks
- dependencies
- affected files
- database changes
- API changes
- frontend changes
- backend changes
- authentication changes
- KYC changes
- security changes
- testing
- migrations
- environment configuration
- deployment
- risks
- rollback considerations
- human approval checkpoints

Do not implement code while creating the plan.

## Phase 6  Implementation

Only after the Technical Specification and implementation plan are approved may @engineer begin implementation.

The engineer must:

1. Work directly inside the existing MedProcure project.
2. Never create app_build/ as a replacement application.
3. Inspect dependencies before changing architecture.
4. Check Git status before major changes.
5. Implement incrementally.
6. Preserve working functionality unless the approved specification requires changes.
7. Create database migrations where required.
8. Never destroy production data.
9. Never overwrite .env files containing user configuration or secrets.
10. Keep changes traceable to the approved implementation plan.

After each major implementation phase, verify the affected functionality before continuing.

## Phase 7  Database Analysis

Before final testing, run the database-analysis skill.

Produce:

production_artifacts/database_analysis.md

Review:

- schema
- tables
- relationships
- indexes
- constraints
- migrations
- seed data
- data integrity
- security
- migration safety
- compatibility with the application

Do not drop or destroy databases unless explicitly approved.

## Phase 8  Quality Assurance

Run the qa skill.

Produce:

production_artifacts/test_report.md

Tests must actually be executed.

Never claim PASS unless the test was actually run successfully.

Test:

- frontend
- backend
- APIs
- authentication
- authorization
- KYC
- identity-document upload
- NIN-related functionality
- validation
- database operations
- critical workflows
- regression
- file-upload security

Failures must be reproduced, fixed when authorized, and retested.

## Phase 9  Security Review

Run the security skill.

Produce:

production_artifacts/security_audit.md

Review:

- authentication
- authorization
- session/token handling
- password security
- API security
- KYC
- NIN-related sensitive data
- identity documents
- file uploads
- database security
- input validation
- SQL injection
- XSS
- CSRF where applicable
- sensitive-data exposure
- secrets/configuration
- admin permissions

Never expose real secrets or sensitive personal information in reports.

## Phase 10  Deployment Verification

Run the devops skill.

Produce:

production_artifacts/deployment_report.md

Verify where applicable:

- Docker
- PostgreSQL
- environment configuration
- dependencies
- migrations
- application startup
- frontend build
- backend startup
- health checks
- database connectivity
- logs
- production configuration

Do not overwrite .env files or expose secrets.

## Phase 11  Final Validation

Run final validation after QA, security, and deployment verification.

Produce:

production_artifacts/final_validation.md

Confirm:

- requirements were addressed
- implementation matches the approved specification
- implementation matches the approved plan
- tests were executed
- security review was completed
- database changes were reviewed
- deployment checks were completed
- known limitations remain documented
- no unauthorized destructive changes were made
- required production artifacts exist

## Global Safety Rules

Never:

- create a duplicate application in app_build/
- reset or discard user work
- force-push
- drop production databases
- delete broad project trees without approval
- overwrite .env files
- expose secrets
- expose real NIN or identity-document data
- modify production data without explicit approval
- claim tests passed without running them
- claim deployment succeeded without verification

For major or destructive changes:

1. inspect dependencies
2. inspect Git status. If Git is unavailable, record it as NOT AVAILABLE / NOT VERIFIED and do not initialize Git.
3. explain the change
4. identify risks
5. create or update the implementation plan
6. obtain required human approval
7. implement incrementally
8. verify the result

The existing MedProcure repository is the application.

.agents/ is the AI control and instruction layer.

production_artifacts/ contains audit, specification, planning, testing, security, deployment, and validation records.
