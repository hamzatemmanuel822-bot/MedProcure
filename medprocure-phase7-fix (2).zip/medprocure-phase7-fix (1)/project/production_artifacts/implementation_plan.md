# MedProcure Engineering Implementation Plan

**Document Version:** 2.1 (Migration Baseline Safety, Audit Scope & Test Isolation Clarified)  
**Phase:** Phase 5 – Implementation Planning  
**Status:** Awaiting Human Approval Before Phase 6 Execution  
**Date:** October 5, 2026  
**Lead Engineer & Autonomous Engineering Team:** MedProcure Engineering Team (@engineer, @architect, @pm, @qa, @security, @devops)

---

## 1. Executive Summary & Strategy

Following explicit human guidance, this implementation plan establishes the exact, verified roadmap for upgrading the existing MedProcure application in place without destructive operations, duplicate applications, or unverified changes.

### Core Invariants & Safety Guarantees
1. **In-Place Modification:** All modifications will be executed directly inside the existing repository (`backend/` and `frontend/`). No duplicate application (e.g. `app_build/`) will be generated.
2. **Database Migration Baseline Safety:**
   - The migration runner will inspect the existing database before deciding which migrations are pending.
   - Migrations `001` through `009` will NEVER be blindly re-executed on an existing database.
   - An explicit baseline will be established for already-applied migrations.
   - Fresh databases and existing databases are handled with distinct, deterministic initialization workflows.
3. **Targeted Audit Logging:** The `audit_logs` table is strictly scoped to four mission-critical administrative and inventory integrity events (`DISTRIBUTOR_APPROVED`, `DISTRIBUTOR_REJECTED`, `DISTRIBUTOR_TERMINATED`, `ORDER_INSUFFICIENT_STOCK_INCIDENT`).
4. **Hard Test Database Isolation:** Automated tests (Jest + Supertest) are prohibited from running against development or production databases. A mandatory environment safety guard verifies that the target database is an isolated test database (e.g. `medprocure_test`) before executing tests.
5. **Preservation of Existing Working Security Controls:**
   - AES-256-GCM encryption for National Identification Numbers (`nin_encrypted`).
   - SHA-256 one-way hashing with unique partial index (`idx_users_nin_hash`) for Sybil/duplicate account prevention.
   - Password complexity enforcement ($\ge 8$ chars, letters + numbers).
   - 5-attempt brute-force lockout engine (15-minute lock in `users.locked_until`).
   - Admin-only authenticated document streaming with path traversal protection.
   - Helmet HTTP headers, CORS origin restrictions, and client-side `escapeHtml()` sanitation.
6. **No Implementation During Planning:** No code or database changes will occur until this plan receives explicit approval.

---

## 2. Database Schema, Index Audit & Baseline Strategy

### 2.1 Existing Database vs. Fresh Database Baseline Strategy

Historically, `backend/src/config/runMigrations.js` scanned `backend/src/migrations/*.sql` and unconditionally executed every file on every startup because there was no migration tracking table. Migrations `005` and `006` contain mutating `UPDATE` statements (`UPDATE users SET role = 'distributor' WHERE role = 'vendor';` and `UPDATE users SET verification_status = 'approved' WHERE role = 'distributor' AND verification_status = 'not_applicable';`). Re-running these queries against a live, populated database risks altering data states.

To prevent blind re-execution, the migration runner will implement an **Inspection-Based Baseline Detection Strategy**:

```mermaid
flowchart TD
    Start[Run npm run migrate] --> CreateTracking[Create schema_migrations IF NOT EXISTS]
    CreateTracking --> CheckCount{Does schema_migrations have rows?}
    
    CheckCount -->|Yes| ReadRecorded[Read recorded versions from schema_migrations]
    CheckCount -->|No| InspectDB{Inspect DB: Does table 'users' exist?}
    
    InspectDB -->|No: Fresh DB| FreshWorkflow[Fresh Database Workflow:\nExecute 001..010 sequentially in transactions,\nrecording each in schema_migrations]
    
    InspectDB -->|Yes: Existing DB| InspectColumns{Inspect Schema Features:\nDo tables products, cart_items, orders, quote_requests,\nand columns nin_encrypted, account_status exist?}
    
    InspectColumns -->|All Exist: Phase 7 State| BaselineWorkflow[Baseline Existing Migrations:\nRecord 001..009 as applied in schema_migrations\nWITHOUT executing their SQL bodies]
    
    InspectColumns -->|Partial| PartialBaseline[Record only verified applied milestones in schema_migrations]
    
    BaselineWorkflow --> RunPending[Execute only genuinely pending migrations\ne.g. 010 within BEGIN...COMMIT]
    ReadRecorded --> RunPending
    RunPending --> Finish[Migrations Complete & Verified]
```

#### Detailed Workflow Comparison

| Dimension | Fresh Database (Empty Instance) | Existing Database (Pre-existing Phase 7) |
|---|---|---|
| **Initial State** | `schema_migrations` does not exist; table `users` does not exist. | `schema_migrations` does not exist; tables `users`, `products`, `orders`, `quote_requests`, etc. exist with Phase 7 columns (`nin_encrypted`, `account_status`). |
| **Detection Logic** | Query `information_schema.tables WHERE table_name = 'users'` returns 0 rows. | Query `information_schema.tables WHERE table_name = 'users'` returns 1 row. |
| **Baseline Action** | None. Database is clean. | Runner queries `information_schema.columns` to verify that Phase 6/7 columns exist (`nin_encrypted`, `account_status`, `terms_accepted_at`). Upon confirmation, runner inserts baseline records into `schema_migrations` for `001_create_users_table.sql` through `009_add_terms_address_and_termination.sql` with timestamps set to `NOW()`, **without running their SQL commands**. |
| **Execution Phase** | Executes `001` through `010` in individual transactional blocks (`BEGIN ... COMMIT`), recording each in `schema_migrations`. | Only executes genuinely pending migrations (starting at `010_add_migration_tracking_and_indexes.sql`) inside an atomic transaction. |
| **Safety Invariant** | Creates full schema from scratch safely. | Guarantees that mutating `UPDATE` statements in `005` and `006` are NEVER re-executed against existing data. |

---

### 2.2 Justified Migration `010_add_migration_tracking_and_indexes.sql`

Based on the audit of existing migrations `001` through `009`:
- `idx_products_vendor` *already exists* on `products(vendor_id)` (from migration `002`). No redundant vendor index is created.
- Migration `010` contains only verified, non-redundant additions:

```sql
-- Migration 010: Add migration tracking indexes, role default fix, and audit logging

-- 1. Correct role column default for new accounts
ALTER TABLE users ALTER COLUMN role SET DEFAULT 'healthcare_consumer';

-- 2. Add email verification expiry column for token lifespan enforcement
ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verification_expires_at TIMESTAMP WITH TIME ZONE;

-- 3. Justified Query-Pattern Indexes:
-- Index for filtering approved and active distributors in marketplace catalog queries
CREATE INDEX IF NOT EXISTS idx_users_active_distributor 
    ON users(verification_status, account_status) 
    WHERE role = 'distributor';

-- Foreign key indexes on order_items for vendor sales analytics & product queries
CREATE INDEX IF NOT EXISTS idx_order_items_product ON order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_order_items_vendor ON order_items(vendor_id);

-- Composite index for distributor quote dashboard queries
CREATE INDEX IF NOT EXISTS idx_quote_requests_distributor_status 
    ON quote_requests(distributor_id, status);

-- 4. Administrative Audit Logging Table
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    actor_id INT REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT NOT NULL,
    details JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
```

---

### 2.3 Explicit Operational Scope for `audit_logs`

To prevent schema bloat and ensure every table is actively utilized, the `audit_logs` table is strictly scoped to the following **four concrete application events**:

| Event Name (`action`) | Triggering Handler | Actor (`actor_id`) | Entity (`entity_type` / `entity_id`) | Stored `details` Payload | Operational Purpose |
|---|---|---|---|---|---|
| `DISTRIBUTOR_APPROVED` | `adminController.approveDistributor` | Admin User ID | `user` / Distributor ID | `{"previous_status": "pending", "new_status": "approved", "admin_email": "admin@..."}` | Compliance audit trail verifying which administrator approved a distributor and when. |
| `DISTRIBUTOR_REJECTED` | `adminController.rejectDistributor` | Admin User ID | `user` / Distributor ID | `{"previous_status": "pending", "new_status": "rejected", "rejection_reason": "..."}` | Retains official record of rejected applications and documented compliance deficiencies. |
| `DISTRIBUTOR_TERMINATED` | `adminController.terminateDistributor` | Admin User ID | `user` / Distributor ID | `{"previous_status": "active", "new_status": "terminated", "termination_reason": "..."}` | Irrevocable log of platform policy enforcement and contract termination. |
| `ORDER_INSUFFICIENT_STOCK_INCIDENT` | `orderController.handleStripeWebhook` | `NULL` (System Event) | `order` / Order ID | `{"productId": 4, "productName": "...", "requestedQty": 2, "availableStock": 0}` | Real-time logging of overselling attempts or concurrency shortfalls during Stripe payment settlement for refund processing. |

No other tables or events are introduced. If an event is outside these four domains, it is not written to `audit_logs`.

---

## 3. Implementation Phases & Ordered Task Breakdown

The implementation follows **11 strictly sequenced phases**:

```mermaid
flowchart TD
    P1[Phase 1: Security & Secrets Sanitization] --> P2[Phase 2: Database Migration Engine & Schema Hardening]
    P2 --> P3[Phase 3: Core Service Abstractions & Email Infrastructure]
    P3 --> P4[Phase 4: Contract Harmonization & Authentication Engine]
    P4 --> P5[Phase 5: Distributor Onboarding & KYC Lifecycle]
    P5 --> P6[Phase 6: Marketplace Catalog & Seller Standing Filtering]
    P6 --> P7[Phase 7: Cart, Stock Integrity & Buy-Now Checkout]
    P7 --> P8[Phase 8: RFQ Flow, Contact Shielding & Unlock Fees]
    P8 --> P9[Phase 9: Idempotent & Concurrency-Safe Webhook Processing]
    P9 --> P10[Phase 10: Frontend Polish, Navigation & UI State Hardening]
    P10 --> P11[Phase 11: Automated Test Suite & Verification]
```

---

### Phase 1: Security & Secrets Sanitization
*Objective: Eliminate active credential exposures in repository templates and establish clean configuration baselines.*

- **Task 1.1: Sanitize `backend/.env.example`**
  - Purge real Gmail username and Google App Password from lines 42–43.
  - Substitute safe placeholders (`your_smtp_username`, `your_smtp_password`, `your_encryption_key`, `your_jwt_secret`).
  - Add explicit commentary instructing administrators to rotate any previously exposed credentials immediately.
- **Task 1.2: Verify Local `.env` Protection**
  - Verify `.env` is listed in `.gitignore` and never committed.
  - Ensure existing user `.env` files are untouched during deployment or testing.

---

### Phase 2: Database Migration Engine & Schema Hardening
*Objective: Transition from unversioned migration execution to deterministic, tracked migrations with `schema_migrations`.*

- **Task 2.1: Implement Baseline-Aware `runMigrations.js`**
  - Create tracking table:
    ```sql
    CREATE TABLE IF NOT EXISTS schema_migrations (
        id SERIAL PRIMARY KEY,
        version VARCHAR(255) UNIQUE NOT NULL,
        applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
    ```
  - Query `COUNT(*) FROM schema_migrations`.
  - If count is 0:
    - Inspect `information_schema.tables WHERE table_name = 'users'`.
    - If `users` does NOT exist $\rightarrow$ **Fresh DB**: execute `001` through `010` sequentially, recording each in `schema_migrations`.
    - If `users` DOES exist $\rightarrow$ **Existing DB**: verify existence of columns `nin_encrypted` and `account_status`. Insert baseline rows into `schema_migrations` for `001_create_users_table.sql` through `009_add_terms_address_and_termination.sql` **without executing their SQL bodies**.
  - Query unapplied migrations from `backend/src/migrations/*.sql` where filename is not in `schema_migrations`.
  - Execute each genuinely pending migration (starting with `010`) within an atomic transaction (`BEGIN ... COMMIT`) and record in `schema_migrations`.
- **Task 2.2: Add Migration `010_add_migration_tracking_and_indexes.sql`**
  - Add verified indexes, role default fix, `email_verification_expires_at`, and `audit_logs` table.
- **Task 2.3: Verify Migration Execution**
  - Validate that re-running `npm run migrate` on the existing database executes zero duplicate queries and maintains schema integrity.

---

### Phase 3: Core Service Abstractions & Email Infrastructure
*Objective: Introduce pluggable storage and robust email delivery services.*

- **Task 3.1: Create Storage Abstraction (`src/config/storageService.js`)**
  - Define `IStorageProvider` interface with `saveFile(file, prefix)`, `getFileStream(filePath)`, and `deleteFile(filePath)`.
  - Implement `LocalStorageProvider` encapsulating `backend/uploads/verification-docs/`.
  - Enforce strict path traversal validation (`path.resolve` boundary verification against `UPLOAD_ROOT`).
  - Return standardized metadata objects (`{ stream, size, mimeType }`).
- **Task 3.2: Enhance Email Delivery Service (`src/config/emailService.js`)**
  - Add connection timeouts (`connectionTimeout: 10000`, `greetingTimeout: 5000`) to prevent hung workers.
  - Create HTML template for distributor email verification (`sendDistributorVerificationEmail`).
  - Update consumer email verification template to ensure consistent MedProcure branding.
  - Maintain robust console logging fallback when SMTP is unconfigured.

---

### Phase 4: Contract Harmonization & Authentication Engine
*Objective: Standardize data contracts to camelCase and harden auth endpoints.*

- **Task 4.1: Standardize Backend User Payloads in `authController.js`**
  - Create helper function `formatUserResponse(userRow)` returning uniform camelCase properties:
    `{ id, fullName, email, role, phone, isVerified, verificationStatus, accountStatus, businessName, createdAt }`.
  - Update `register`, `login`, and `getMe` handlers to utilize `formatUserResponse`.
- **Task 4.2: Purge Token Leaks in Registration Response**
  - Remove `response.simulatedVerificationLink` from `authController.register`.
  - Ensure verification tokens are transmitted exclusively via email.
- **Task 4.3: Extend `getMe` Profile Fields**
  - Query all relevant profile fields: `phone, is_verified, verification_status, account_status, business_name`.
- **Task 4.4: Enforce `blockIfTerminated` on All Distributor Routes**
  - Attach `blockIfTerminated` middleware to `distributorRoutes.js` (`/verification-status`, `/verification`).

---

### Phase 5: Distributor Onboarding & KYC Lifecycle
*Objective: Resolve post-registration UI crashes, implement distributor email verification, and streamline admin review.*

- **Task 5.1: Wire Distributor Email Verification in `authController.register`**
  - Generate cryptographically secure 32-byte hex token for distributors (`email_verification_token`).
  - Set expiration: `email_verification_expires_at = NOW() + INTERVAL '24 hours'`.
  - Dispatch activation email using `emailService.sendDistributorVerificationEmail`.
- **Task 5.2: Enforce Token Expiry in `authController.verifyEmail`**
  - Check that `users.email_verification_expires_at > NOW()`.
  - If expired, return HTTP 400: `"Verification link has expired. Please request a new verification email."`.
  - If valid, set `is_verified = TRUE`, clear `email_verification_token` and `email_verification_expires_at`.
- **Task 5.3: Refactor `frontend/register.html` DOM Structure**
  - Move the static `<h1>Create your account</h1>` and subtitle inside `#register-form-card`.
  - Ensure hiding `#register-form-card` cleanly removes all registration titles when showing `#success-panel`.
- **Task 5.4: Upgrade Post-Registration Timeline in `frontend/js/register.js`**
  - Render the polished 3-step visual timeline:
    1. *Application & Documents Received* (Completed)
    2. *Verify Your Email Address* (Active - Prompts inbox check)
    3. *Administrative Review & Activation* (Pending - 24-48h SLA)
- **Task 5.5: Fix Client User Model Normalization (`frontend/js/auth.js` & `api.js`)**
  - Implement `normalizeUser(raw)` adapter guaranteeing `user.fullName` is always populated.
  - Fix `frontend/js/dashboard.js:33` to safely read `user.fullName` with fallback initials to prevent `split` of undefined.
- **Task 5.6: Gate Admin Approval on Email Verification (`adminController.js`)**
  - In `approveDistributor`, verify `users.is_verified === TRUE`.
  - If false, return HTTP 400: `"Distributor must verify email address before administrative approval."`.
  - Log approval event to `audit_logs` (`DISTRIBUTOR_APPROVED`).
  - Log rejection and termination events to `audit_logs` (`DISTRIBUTOR_REJECTED`, `DISTRIBUTOR_TERMINATED`).
  - Refactor document streaming to utilize `storageService.getFileStream()`.

---

### Phase 6: Marketplace Catalog & Seller Standing Filtering
*Objective: Guarantee that only verified, active equipment distributors have publicly visible and purchasable items.*

- **Task 6.1: Enforce Standing Filter in `productController.js`**
  - Update `getAllProducts`:
    ```sql
    SELECT products.*, users.full_name AS vendor_name, users.business_name
    FROM products
    INNER JOIN users ON products.vendor_id = users.id
    WHERE users.verification_status = 'approved' AND users.account_status = 'active'
    ```
  - Update `getProductById` to return HTTP 404 if the vendor is not approved and active (unless queried by the vendor themselves or an admin).
  - Update `getCategoryInsights` in `statsController.js` to aggregate products only from active, approved distributors.
- **Task 6.2: Add Input Validation to `productController.updateProduct`**
  - Enforce `price >= 0` and `stock >= 0` on PUT operations, preventing negative inventory updates.

---

### Phase 7: Cart, Stock Integrity & Buy-Now Checkout
*Objective: Isolate e-commerce cart operations to buy-now items and enforce inventory constraints.*

- **Task 7.1: Enforce `listing_type` and Stock Limits in `cartController.js`**
  - In `addToCart`, query product details:
    - If `product.listing_type !== 'buy_now'`, reject with HTTP 400: `"This product requires a quote inquiry and cannot be purchased directly through the cart."`.
    - If `cart_quantity + requested_quantity > product.stock`, reject with HTTP 400: `"Requested quantity exceeds available stock."`.
  - Restrict cart modifications strictly to `healthcare_consumer` role.
- **Task 7.2: Enhance Cart UI Validation (`frontend/js/cart.js`)**
  - Display informative badges on cart items.
  - Disable "Proceed to Checkout" if any item exceeds current stock.

---

### Phase 8: RFQ Flow, Contact Shielding & Unlock Fees
*Objective: Shield consumer contact details on quote requests until the $25 unlock fee is confirmed.*

- **Task 8.1: Mask Buyer Contacts in `quoteController.js`**
  - In `getReceivedQuoteRequests` and `getQuoteRequestById`, evaluate `quote_request.status`:
    - If `status !== 'unlocked'`, redact buyer fields:
      `buyer_name: "[Locked - Requires Payment]"`, `buyer_email: "[Locked]"`, `buyer_phone: "[Locked]"`.
    - If `status === 'unlocked'`, return plaintext buyer contact info.
- **Task 8.2: Upgrade Received Quotes UI (`frontend/js/received-quotes.js`)**
  - Render a locked contact card with a lock icon and explanatory badge when contact info is masked.
  - Render an unlocked contact card with direct email/phone action links once unlocked.

---

### Phase 9: Idempotent & Concurrency-Safe Webhook Processing
*Objective: Eliminate double-decrement race conditions, verify stock sufficiency during row locks, and guarantee inventory never drops below zero.*

- **Task 9.1: Implement Concurrency-Safe Transactional Webhook Handler in `orderController.js`**
  - Acquire database client from pool: `const client = await pool.connect()`.
  - Execute within `BEGIN`:
    ```sql
    -- Step 1: Lock the order row to prevent concurrent webhook processing
    SELECT id, customer_id, status FROM orders WHERE id = $1 FOR UPDATE;
    ```
  - **Idempotency Guard:** If `status === 'paid'`, execute `ROLLBACK` and return HTTP 200 `{ received: true, already_processed: true }`.
  - **Fetch Line Items:**
    ```sql
    SELECT product_id, quantity FROM order_items WHERE order_id = $1;
    ```
  - **Pessimistic Product Locking (Deadlock-Free):** Lock all relevant products in deterministic ascending order:
    ```sql
    SELECT id, name, stock FROM products WHERE id = ANY($1) ORDER BY id ASC FOR UPDATE;
    ```
  - **Comprehensive Stock Sufficiency Check:**
    - Iterate through all line items and check against locked stock:
      ```javascript
      let insufficientItem = null;
      for (const item of orderItems.rows) {
        const prod = lockedProducts.find(p => p.id === item.product_id);
        if (!prod || prod.stock < item.quantity) {
          insufficientItem = { item, prod };
          break;
        }
      }
      ```
    - **If Insufficient Stock Detected:**
      - Do NOT decrement stock for any item.
      - Update order status: `UPDATE orders SET status = 'failed_insufficient_stock', updated_at = NOW() WHERE id = $1`.
      - Record an incident in `audit_logs` with action `ORDER_INSUFFICIENT_STOCK_INCIDENT`.
      - `COMMIT` the order status update.
      - Stock remains non-negative; administrators are notified for refund or fulfillment resolution.
    - **If All Stock Sufficient:**
      - Decrement stock for each item:
        ```sql
        UPDATE products SET stock = stock - $1, updated_at = NOW() WHERE id = $2;
        ```
      - Update order: `UPDATE orders SET status = 'paid', updated_at = NOW() WHERE id = $1;`
      - Clear consumer cart: `DELETE FROM cart_items WHERE user_id = $1;`
      - `COMMIT` transaction.
  - Release client and return HTTP 200.
- **Task 9.2: Handle Quote Unlock Webhook Transaction**
  - Lock quote request: `SELECT status FROM quote_requests WHERE id = $1 FOR UPDATE;`.
  - If status is `pending_payment`:
    - `UPDATE quote_requests SET status = 'unlocked', fee_paid_at = NOW() WHERE id = $1;`.
    - Dispatch confirmation emails to consumer and distributor.
    - `COMMIT` transaction.

---

### Phase 10: Frontend Polish, Navigation & UI State Hardening
*Objective: Remove dead links, harmonize loading/empty states, and resolve hardcoded API origins.*

- **Task 10.1: Fix Dead Navigation Links in `frontend/js/components/footer.js`**
  - Link "Terms of Operation" directly to `terms.html`.
  - Add functional dialog/route for "Contact Support" and "Privacy Policy".
- **Task 10.2: Eliminate Hardcoded Origin in `frontend/index.html`**
  - Replace line 95 `fetch("http://localhost:5000/api/stats/public")` with `getPublicStats()` from `api.js`.
- **Task 10.3: Polish Product Detail CTAs (`frontend/js/product-details.js`)**
  - For unauthenticated users, show clear "Sign in to Buy" or "Sign in to Request Quote" CTAs redirecting to `login.html?redirect=...`.
  - For `quote_request` items, guide the user directly to the unlock payment flow upon RFQ submission.

---

### Phase 11: Automated Test Suite & Verification
*Objective: Institute an automated test harness (Jest + Supertest) and execute mandatory acceptance tests covering all critical business rules under strict test database isolation.*

#### 11.1 Test Database Isolation & Protection Rules
Automated tests MUST NEVER execute destructive operations against the development database or any production-like data.

1. **Test Environment Selection (`backend/src/config/db.js`):**
   ```javascript
   const isTest = process.env.NODE_ENV === "test";
   const targetDbName = isTest
     ? (process.env.TEST_DB_NAME || "medprocure_test")
     : (process.env.DB_NAME || "medprocure");
   ```
2. **Hard Safety Guard Check (`backend/tests/setup.js`):**
   Prior to running any test suites, `tests/setup.js` verifies:
   ```javascript
   const pool = require("../src/config/db");
   const dbConfig = pool.options;
   if (!dbConfig.database.includes("test")) {
     throw new Error(
       `CRITICAL TEST SAFETY GUARD: Attempted to run tests against non-test database: '${dbConfig.database}'. ` +
       `Tests must strictly run against a dedicated database containing 'test' in its name (e.g. 'medprocure_test').`
     );
   }
   ```
3. **Synthetic Data Policy:**
   - All test fixtures use synthetic email domains (`@test.medprocure.internal`).
   - Mocked external services: Stripe API calls and Nodemailer SMTP are fully mocked in test setup to prevent external network side-effects.
   - Test suites clean up their created synthetic records after completion.

#### 11.2 Mandatory Acceptance Tests
Each test is a required gating assertion that must pass:

| Test ID | Mandatory Acceptance Test | Scope / Location | Required Assertion |
|---|---|---|---|
| **MAT-01** | **Distributor Email Verification Before Admin Approval** | `tests/integration/kyc.test.js` | Attempting `POST /api/admin/distributors/:id/approve` when `is_verified === false` returns HTTP 400. Approval succeeds only after `is_verified === true`. |
| **MAT-02** | **Verification Token Expiry** | `tests/integration/auth.test.js` | Visiting `GET /api/auth/verify-email?token=...` with a token past `email_verification_expires_at` returns HTTP 400 with an expiration message. |
| **MAT-03** | **Verification Token Not Returned in Registration API** | `tests/integration/auth.test.js` | `POST /api/auth/register` returns HTTP 201 with `{ token, user }`. The response JSON body strictly does NOT contain `email_verification_token`, `simulatedVerificationLink`, or verification URLs. |
| **MAT-04** | **Terminated Distributor Route Blocking** | `tests/integration/auth.test.js` | Once an account has `account_status = 'terminated'`, requests to `/api/products` (POST/PUT/DELETE), `/api/quotes/received`, and `/api/distributors/verification-status` using a valid JWT return HTTP 403 Forbidden with the termination reason. |
| **MAT-05** | **Approved & Active Vendor Catalog Filtering** | `tests/integration/catalog.test.js` | Products belonging to vendors with `verification_status = 'pending'`, `'rejected'`, or `account_status = 'terminated'` are strictly absent from `GET /api/products` results. |
| **MAT-06** | **Quote-Only Cart Rejection** | `tests/integration/cart.test.js` | Attempting `POST /api/cart` with a product configured as `listing_type = 'quote_request'` returns HTTP 400 with a descriptive error blocking cart insertion. |
| **MAT-07** | **Buyer Contact Masking Before Unlock Payment** | `tests/integration/quote.test.js` | In `GET /api/quotes/received`, quote requests in `pending_payment` status return buyer details as `[Locked - Requires Payment]`. Full contact details appear only when status is `'unlocked'`. |
| **MAT-08** | **Stripe Webhook Idempotency** | `tests/integration/webhook.test.js` | Sending the exact same `checkout.session.completed` webhook event twice results in the second event returning HTTP 200 with `already_processed: true` without performing duplicate operations. |
| **MAT-09** | **Single Stock Decrement** | `tests/integration/webhook.test.js` | For an order with 2 units of Product X (initial stock 10), processing the webhook decrements stock to 8. Repeated webhook dispatches leave stock at exactly 8. |
| **MAT-10** | **Protection Against Overselling Under Concurrent Purchases** | `tests/integration/webhook.test.js` | When two checkout sessions attempt to fulfill against a product with stock = 1 simultaneously, exactly one succeeds (reducing stock to 0) and the second transitions to `failed_insufficient_stock`. Stock NEVER drops below 0. |

- **Task 11.3: Execute Full Test Suite & Record Results**
  - Run `npm test` from `backend/` in the isolated test environment.
  - Verify 100% pass rate across all 10 Mandatory Acceptance Tests.

---

## 4. Comprehensive List of Affected Files

### Backend Files
| File Path | Change Type | Purpose |
|---|---|---|
| `backend/.env.example` | Modification | Remove leaked credentials; add safe placeholders and rotation notes. |
| `backend/package.json` | Modification | Add `jest` and `supertest` devDependencies; add `test` script. |
| `backend/src/config/db.js` | Modification | Add test database selection (`TEST_DB_NAME` / `medprocure_test`). |
| `backend/src/config/runMigrations.js` | Modification | Implement baseline detection strategy and `schema_migrations` tracking. |
| `backend/src/migrations/010_add_migration_tracking_and_indexes.sql` | **New File** | Add verified query indexes, role default fix, and `audit_logs` table. |
| `backend/src/config/storageService.js` | **New File** | Implement pluggable local filesystem storage abstraction with traversal guard. |
| `backend/src/config/emailService.js` | Modification | Add distributor verification email template and connection timeouts. |
| `backend/src/controllers/authController.js` | Modification | Harmonize camelCase contracts, add distributor verification & expiry, remove token leak. |
| `backend/src/controllers/adminController.js` | Modification | Gate approvals on `is_verified === true`, stream documents via `storageService`, log audit events. |
| `backend/src/controllers/distributorController.js` | Modification | Attach `blockIfTerminated`, support full document re-upload. |
| `backend/src/controllers/productController.js` | Modification | Filter catalog by approved/active vendor standing; validate price/stock on PUT. |
| `backend/src/controllers/cartController.js` | Modification | Reject `quote_request` items; validate requested vs available stock. |
| `backend/src/controllers/orderController.js` | Modification | Implement pessimistic row locks (`FOR UPDATE`), stock verification, and idempotent webhook handling; log insufficient stock to `audit_logs`. |
| `backend/src/controllers/quoteController.js` | Modification | Mask buyer contact details until unlock fee is confirmed paid. |
| `backend/src/controllers/statsController.js` | Modification | Filter category analytics by active approved vendors. |
| `backend/src/routes/distributorRoutes.js` | Modification | Apply `blockIfTerminated` middleware to all routes. |
| `backend/tests/setup.js` | **New File** | Test runner environment setup, database isolation guard, mock Stripe/SMTP, and teardown. |
| `backend/tests/integration/*.test.js` | **New Files** | 10 Mandatory Acceptance Tests covering auth, KYC, catalog, cart, and webhooks. |

### Frontend Files
| File Path | Change Type | Purpose |
|---|---|---|
| `frontend/register.html` | Modification | Move static title inside card; clean toggle for `#success-panel`. |
| `frontend/js/register.js` | Modification | Render 3-step timeline; guide distributor to verify email. |
| `frontend/dashboard.html` | Modification | Clean banner layout for pending distributor state. |
| `frontend/js/dashboard.js` | Modification | Fix `u.fullName` property crash; add robust null checks. |
| `frontend/js/auth.js` | Modification | Add `normalizeUser()` session adapter; handle camelCase. |
| `frontend/js/api.js` | Modification | Standardize error handling and response normalization. |
| `frontend/index.html` | Modification | Remove hardcoded localhost API origin; use `api.js`. |
| `frontend/products.html` | Modification | Add status indicators and filter controls. |
| `frontend/js/products.js` | Modification | Render approved equipment cards with buy-now vs quote badges. |
| `frontend/product-details.html` | Modification | Polish buy-now vs quote request actions. |
| `frontend/js/product-details.js` | Modification | Guide RFQ submissions to payment unlock. |
| `frontend/cart.html` | Modification | Display stock alerts and clean empty state. |
| `frontend/js/cart.js` | Modification | Validate stock bounds and block quote checkout. |
| `frontend/received-quotes.html` | Modification | Render masked vs unlocked contact cards. |
| `frontend/js/received-quotes.js` | Modification | Show lock badge when contact info is protected. |
| `frontend/admin-dashboard.html` | Modification | Add structured termination modal. |
| `frontend/js/admin.js` | Modification | Replace browser `prompt()` with modal termination. |
| `frontend/js/components/footer.js` | Modification | Replace dead `#` links with real routes and modals. |

---

## 5. Human Approval Checkpoint

In compliance with `.agents/workflows/medprocure-pipeline.md`:
- This revised implementation plan is submitted to the human supervisor for explicit review and approval.
- **No implementation will begin until approval is granted.**
