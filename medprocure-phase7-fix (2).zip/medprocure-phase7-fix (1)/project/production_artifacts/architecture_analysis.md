# MedProcure Comprehensive Architecture Analysis Report

**Document Version:** 2.0 (End-to-End Marketplace System Architecture Analysis)  
**Phase:** Phase 3 – Comprehensive Architecture Analysis  
**Auditor / Lead Architect:** MedProcure Autonomous Engineering Team (@architect)  
**Date:** October 5, 2026  
**Status:** Read-Only Architectural Analysis  

---

## 1. Executive Summary

MedProcure is a multi-vendor medical equipment procurement marketplace connecting **Healthcare Consumers** with document-reviewed, identity-verified **Distributors**, administered by authorized **Platform Administrators**. The core value proposition is verified trust in healthcare procurement—countering scams, counterfeit equipment, and unverified vendors through mandatory distributor identity verification (Nigerian National Identification Number [NIN] encryption and duplicate detection), document authentication (photo ID, business registration license, proof of address), administrative approval workflows, and terms termination policies.

This comprehensive architecture analysis evaluates MedProcure as a complete, working marketplace web application. The analysis traces all primary user journeys (Consumer, Distributor, Admin, and Marketplace) from the browser interface through network requests, routing, middleware, controllers, database persistence, and external integrations (Stripe, Nodemailer, local filesystem).

### Primary System Findings
1. **Core Architectural Merit:** The platform features a clean separation of concerns across a Node.js/Express REST backend, a modular Vanilla HTML5/CSS3/ES-module frontend, and a relational PostgreSQL database. Its cryptographic foundations (AES-256-GCM field-level encryption for NINs, SHA-256 duplicate detection indexing, and XSS sanitization via `escapeHtml`) are technically sound and must be preserved.
2. **Root Cause of Distributor Post-Registration Failure:** The reported defect where the post-registration success/thank-you interface fails to display and guide the user is caused by a compound failure:
   - **Frontend State Collision & Unhandled Exceptions:** Upon receiving the registration response, `register.js` caches the user in `localStorage`. The backend returns `user.full_name` (snake_case from PostgreSQL), whereas downstream client code expects `user.fullName` (camelCase). In addition, `register.html` features dual `<h1>` structures where the initial page title is left outside the toggled panel, causing visual stacking.
   - **Email Verification Disconnect:** While the project requirements and consumer flows expect email verification, `authController.js` explicitly skips generating an `email_verification_token` and sending a verification email for distributors (`emailVerificationToken` remains `NULL`). Concurrently, `is_verified` remains permanently `FALSE` in the database, even after administrative approval (`approveDistributor` sets `verification_status = 'approved'` but never touches `is_verified`).
   - **Missing Guarded Redirect:** The distributor is not guided into an email verification pending state, and the success panel lacks contextual instructions on email confirmation, leaving the user stranded with a generic "Go to Dashboard" button that immediately encounters a client-side exception.
3. **Pervasive Marketplace Workflow Deficiencies:**
   - **Catalog Seller Status Coupling Defect:** `productController.getAllProducts` joins `products` to `users` without filtering on seller verification or standing (`verification_status = 'approved' AND account_status = 'active'`). Consequently, unapproved or terminated sellers remain visible and purchasable.
   - **Monetization & Cart Boundary Leak:** `cartController.addToCart` does not validate `listing_type === 'buy_now'`, allowing quote-only listings to be placed in standard shopping carts, bypassing the $25 unlock fee.
   - **Quote Contact Data Leak:** `received-quotes.html` displays the buyer's full name and email address to distributors even when the quote request status is `pending_payment`, completely undermining the paid contact-unlock model.
   - **Stripe Webhook Idempotency Flaw:** `orderController.handleStripeWebhook` lacks state checks (`order.status !== 'paid'`) and database transactions. Duplicate Stripe webhook deliveries double-decrement stock and trigger negative inventory errors.
   - **Unversioned Database Migrations:** `runMigrations.js` lacks a schema tracking table (`schema_migrations`), executing all 9 SQL migration files unconditionally on every run, re-running mutating SQL updates on production data.
   - **Credential Exposure:** Active SMTP credentials and default development secrets remain present in `backend/.env.example`.
   - **Zero Automated Test Coverage:** No automated testing framework or test suite exists across the entire project.

---

## 2. Current System Architecture

```
+--------------------------------------------------------------------------------------------------+
|                                    CLIENT TIER (Browser)                                         |
|  - 15 Static Multi-Page HTML Views (index, products, product-details, cart, register, etc.)     |
|  - Vanilla CSS Design System (variables.css, main.css, landing.css, admin.css, dashboard.css)   |
|  - Browser-Native ES6 Modules (js/api.js, js/auth.js, js/utils.js, js/components/*.js)           |
|  - Client State: localStorage ("medprocure_token", "medprocure_user")                            |
+-------------------------------------------------+------------------------------------------------+
                                                  |
                                                  | HTTPS / JSON & Multipart/form-data
                                                  v
+--------------------------------------------------------------------------------------------------+
|                                    API GATEWAY & MIDDLEWARE                                      |
|  - Security Headers: Helmet 7.1.0                                                                |
|  - Cross-Origin Resource Sharing: Dynamic RegExp CORS (localhost, 127.0.0.1, CLIENT_URL)         |
|  - Rate Limiting: authLimiter (10 req/15m on /api/auth), generalLimiter (300 req/15m)            |
|  - Body Parsers: express.raw({ type: "application/json" }) for Stripe Webhooks, express.json(1MB)|
|  - Auth Middleware: requireAuth (JWT verify), requireRole (RBAC), blockIfTerminated (DB check)  |
|  - File Upload Middleware: Multer diskStorage (MIME & extension filtering: PDF, JPG, PNG)        |
+-------------------------------------------------+------------------------------------------------+
                                                  |
                     +----------------------------+----------------------------+
                     |                                                         |
                     v                                                         v
+------------------------------------------+             +-----------------------------------------+
|             BACKEND CONTROLLERS          |             |        CRYPTOGRAPHY & UTILITIES         |
|  - authController (register, login, me)  |             |  - AES-256-GCM (NIN field encryption)   |
|  - productController (catalog, CRUD)     |             |  - SHA-256 (NIN uniqueness hashing)     |
|  - cartController (cart session items)   |             |  - bcryptjs (Password hashing, salt 10) |
|  - orderController (checkout & webhook)  |             |  - jsonwebtoken (HS256 tokens, 7d exp)  |
|  - quoteController (RFQ & contact unlock)|             +-----------------------------------------+
|  - adminController (verification review) |
|  - distributorController (KYC status)    |
|  - statsController (dashboard analytics) |
+--------------------+---------------------+
                     |
                     v
+--------------------------------------------------------------------------------------------------+
|                                       DATA & STORAGE TIER                                        |
|  - PostgreSQL 16 Relational Database (Dockerized container medprocure_postgres on port 5432)     |
|    Tables: users, products, cart_items, orders, order_items, quote_requests                     |
|  - Localhost Filesystem Storage (uploads/verification-docs/) for KYC documents                  |
|  - External Services: Stripe API (Checkout Sessions & Webhook Events), Nodemailer (SMTP/Console) |
+--------------------------------------------------------------------------------------------------+
```

---

## 3. Frontend Architecture

### 3.1 Structure & Technologies
The frontend is constructed as a classic Multi-Page Application (MPA) using vanilla HTML5, CSS3, and ES6 JavaScript modules. It contains no build pipeline, transpiler, bundler (e.g., Vite/Webpack), or external JavaScript frameworks (e.g., React/Vue).

```
frontend/
├── *.html (15 views: index, login, register, dashboard, admin-dashboard, products, product-details,
│           cart, checkout-success, my-quotes, received-quotes, quote-success, vendor-products,
│           terms, verify-email)
├── css/ (10 modular stylesheets: variables.css, main.css, landing.css, forms.css, cards.css,
│         badges.css, dashboard.css, admin.css, quotes.css, footer.css)
└── js/
    ├── config.js (API_BASE_URL export)
    ├── api.js (Centralized fetch wrapper)
    ├── auth.js (Session helpers & login handler)
    ├── utils.js (escapeHtml utility)
    ├── components/ (footer.js, quantityStepper.js)
    └── [page-specific modules].js (admin.js, dashboard.js, products.js, register.js, etc.)
```

### 3.2 Evaluation of Frontend Architecture
- **Strengths:** 
  - Extremely lightweight with zero compilation overhead.
  - Native ES module imports (`import { ... } from "./api.js"`) promote clean modularity.
  - Consistent XSS protection via `escapeHtml()` applied to dynamic innerHTML injections.
- **Weaknesses:**
  - **Client-Side Auth Gating Flaw:** Authentication gating on protected pages relies on inline `<script>` tags checking `localStorage.getItem("medprocure_token")`. This can be bypassed by manipulating the DOM or storage, briefly flashing unprotected UI before API calls fail.
  - **Inconsistent Data Contracts (CamelCase vs. Snake_case):** The backend outputs raw SQL column names (`full_name`, `created_at`, `verification_status`) in some endpoints (like `register` and `getMe`), but camelCase in `login` (`fullName`, `isVerified`). This inconsistency causes critical runtime `TypeError` crashes in scripts like `dashboard.js`.
  - **Hardcoded API URLs:** `index.html:95` directly calls `fetch("http://localhost:5000/api/stats/public")`, bypassing `config.js`.
  - **Dead Navigation Links:** Footer navigation links for "About Us", "Contact Support", "Privacy Policy", and "Terms of Service" point to `#` instead of real routes.

---

## 4. Backend Architecture

### 4.1 Structure & Technologies
The backend is a Node.js CommonJS application running Express 4.19.2. It organizes functionality into controllers, routes, middleware, and configuration singletons.

```
backend/
├── server.js (Entry point & middleware orchestration)
├── package.json (CommonJS configuration & scripts)
└── src/
    ├── config/ (db.js, encryption.js, emailService.js, stripe.js, runMigrations.js, seedAdmin.js)
    ├── controllers/ (admin, auth, cart, distributor, order, product, quote, stats)
    ├── middleware/ (authMiddleware, rateLimiter, registrationUploadMiddleware, uploadMiddleware)
    ├── migrations/ (001 through 009 SQL migration scripts)
    └── routes/ (admin, auth, cart, distributor, order, product, quote, stats)
```

### 4.2 Evaluation of Backend Architecture
- **Strengths:**
  - Standardized MVC-style separation.
  - Parameterized SQL prevents direct SQL injection.
  - Centralized error-handling middleware catches errors and suppresses internal stack traces in client responses.
  - Dedicated crypto configuration abstracts AES-256-GCM encryption and SHA-256 hashing.
- **Weaknesses:**
  - **Monolithic Controller Queries:** Controllers embed large, raw SQL strings directly within handler functions rather than utilizing a data mapper, repository pattern, or query builder.
  - **Incomplete Validation Layer:** Endpoint input validation is scattered across controllers with inconsistent checks. For example, `createProduct` enforces non-negative price and stock, but `updateProduct` does not.
  - **Lack of Transactional Safety:** Multi-statement updates (such as order checkout and Stripe webhook processing) execute sequential database queries outside of database transactions (`BEGIN ... COMMIT`), leaving the database susceptible to partial updates during failures.

---

## 5. Database Architecture

### 5.1 Relational Schema & Entity Relationships
The database schema consists of 6 core tables managed across 9 sequential migration files:

```mermaid
erDiagram
    users ||--o{ products : "sells / distributes"
    users ||--o{ cart_items : "owns"
    users ||--o{ orders : "places"
    users ||--o{ quote_requests : "requests (consumer)"
    users ||--o{ quote_requests : "receives (distributor)"
    products ||--o{ cart_items : "contained in"
    products ||--o{ order_items : "purchased in"
    products ||--o{ quote_requests : "subject of"
    orders ||--|{ order_items : "contains"

    users {
        int id PK
        varchar full_name
        varchar email UK
        text password_hash
        varchar role
        boolean is_verified
        varchar verification_status
        text nin_encrypted
        text nin_hash UK
        text id_photo_path
        text license_document_path
        text proof_of_address_path
        varchar account_status
        timestamp terms_accepted_at
    }

    products {
        int id PK
        int vendor_id FK
        varchar name
        numeric price
        int stock
        varchar category
        varchar listing_type
    }

    cart_items {
        int id PK
        int user_id FK
        int product_id FK
        int quantity
    }

    orders {
        int id PK
        int customer_id FK
        numeric total_amount
        varchar status
        text stripe_session_id UK
    }

    order_items {
        int id PK
        int order_id FK
        int product_id FK
        int vendor_id FK
        int quantity
        numeric price_at_purchase
    }

    quote_requests {
        int id PK
        int product_id FK
        int healthcare_consumer_id FK
        int distributor_id FK
        varchar status
        numeric fee_amount
        text stripe_session_id UK
    }
```

### 5.2 Database Structural & Integrity Deficiencies
1. **Unversioned, Non-Idempotent Migration Runner (`runMigrations.js`):**
   - The runner scans `backend/src/migrations/*.sql` and executes every file sequentially using `pool.query(sql)`.
   - It lacks a `schema_migrations` tracking table.
   - When run against an existing database, data manipulation migrations (such as `005_rename_roles.sql` and `006_add_verification_and_contact_fields.sql`) execute again, risking data overwrites.
2. **Obsolete Table Constraints & Default Values:**
   - In `001_create_users_table.sql`, the `role` column default is `'customer'`. Although migration `005` updated existing rows from `'customer'` to `'healthcare_consumer'`, it failed to alter the column default (`ALTER TABLE users ALTER COLUMN role SET DEFAULT 'healthcare_consumer'`). Any user inserted without a role defaults to the obsolete `'customer'` value.
3. **Missing Foreign Key Indexes:**
   - `order_items.product_id` and `order_items.vendor_id` lack indexes, impacting analytical join performance.
4. **Absence of Audit Trail Table:**
   - Approvals, rejections, and terminations overwrite status columns on the `users` table directly. No historical log exists recording administrative reviewer identity, prior statuses, or review timestamps.

---

## 6. Authentication Architecture

### 6.1 Authentication Mechanism
- **Token Model:** Stateless JSON Web Tokens (JWT) signed with `HS256` using `process.env.JWT_SECRET`.
- **Payload:** `{ id, role, email }`.
- **Expiration:** Default `7d` (`JWT_EXPIRES_IN`).
- **Transport:** HTTP `Authorization: Bearer <token>` header.

### 6.2 Password Security & Lockout Engine
- Passwords hashed using `bcryptjs` with 10 salt rounds.
- Password complexity enforced at registration (`authController.js:34-39`): `>= 8` characters, requiring both alphabetic and numeric characters.
- **Account Lockout Protection (`authController.js:192-215`):**
  - Tracking columns: `users.failed_login_attempts` (integer), `users.locked_until` (timestamp).
  - Threshold: 5 consecutive failures triggers a 15-minute lock (`locked_until = Date.now() + 15 * 60000`).
  - Account locked response: HTTP 423 Locked with remaining minutes calculation.
  - Successful authentication resets `failed_login_attempts` to 0 and clears `locked_until`.
  - Generic error messages (`"Invalid email or password."`) prevent account enumeration.

### 6.3 Authentication Gaps & Weaknesses
- **Token Expiry & Invalidation Mismatch:** Because JWTs are stateless, an unexpired token remains cryptographically valid for 7 days even if the user's password changes or account is terminated. While `blockIfTerminated` performs a real-time database query for specific seller actions, no global token revocation list (or token versioning column) exists.
- **Client Storage Insecurity:** Tokens and user metadata are stored in browser `localStorage`, rendering them accessible to any script executing within the domain context.

---

## 7. Authorization and Role Model

### 7.1 Role Taxonomy
The system recognizes three roles:
1. `healthcare_consumer`: Standard buyer account. Can browse catalog, manage shopping cart, submit orders, submit RFQ quote requests, pay contact unlock fees, and view order history.
2. `distributor`: Vendor account. Requires KYC verification. Can list products, edit inventory, view received quotes, and view sales performance.
3. `admin`: Platform operator. Can view pending KYC applications, decrypt full NINs for document cross-referencing, stream verification files, approve/reject distributors, and terminate active accounts.

### 7.2 Authorization Middleware
- **`requireAuth`:** Validates JWT signature and assigns `req.user = decoded`.
- **`requireRole(allowedRoles)`:** Checks if `allowedRoles.includes(req.user.role)`.
- **`blockIfTerminated`:** Real-time database check (`SELECT account_status FROM users WHERE id = $1`) that rejects terminated distributors with HTTP 403.

### 7.3 Authorization Deficiencies
- **Inconsistent Route Protection:** `blockIfTerminated` is applied to product and quote routes, but is missing from `distributorRoutes.js` (`/verification-status`, `/verification`).
- **Cart/Checkout Role Gating:** Neither `cartRoutes.js` nor `orderRoutes.js` enforces `requireRole(['healthcare_consumer'])`. Admins and distributors can add products to carts and execute checkouts, which violates role segregation.

---

## 8. Distributor Onboarding/KYC Architecture

### 8.1 Onboarding Workflow & Anti-Scam Model
Distributor registration enforces a mandatory anti-scam onboarding sequence designed to eliminate anonymous vendors and multi-account fraud:
1. **Identity & Business Data Capture:** Full legal name, business name, registration/license number, residential address, date of birth, and 11-digit Nigerian National Identification Number (NIN).
2. **Three-Document Upload Requirement:**
   - Identity Photo (`idPhoto`): Selfie or government-issued ID card photo.
   - Business Registration (`licenseDocument`): Corporate Affairs Commission (CAC) certificate or operating license.
   - Proof of Address (`proofOfAddress`): Utility bill or bank statement.
3. **Terms & Policy Acceptance:** Mandatory acceptance of `Distributor Terms & Policy of Operation` (`terms.html`), recording `terms_accepted_at` and `terms_version='v1.0'`.
4. **NIN Dual-Cryptographic Processing:**
   - **One-Way Hash (`nin_hash`):** Computed via `crypto.createHash("sha256").update(nin).digest("hex")`. Checked against a unique partial index on `users(nin_hash)` to detect duplicate registrations across accounts.
   - **Reversible Symmetric Encryption (`nin_encrypted`):** Encrypted using `aes-256-gcm` with a 12-byte initialization vector (IV) and authentication tag. Stored as `iv:authTag:ciphertext`. Decrypted only by authorized administrators during verification.

### 8.2 Deep Root-Cause Analysis: The Distributor Post-Registration Defect
The user confirmed that after a distributor registers, the expected post-registration success/thank-you interface does not appear, leaving the user confused and unguided regarding email verification and next steps.

Tracing the registration lifecycle reveals multiple cascading points of failure:

```
[Distributor Submits Form]
         │
         ▼
[Frontend: register.js]
  • Submits FormData to POST /api/auth/register
         │
         ▼
[Backend: authController.register]
  • Successfully creates user row in `users` table
  • BUG 1: Generates NO `email_verification_token` for distributor (token is NULL)
  • BUG 2: Sends NO verification email (sendConsumerVerificationEmail is only called for consumer)
  • Sets `verification_status = 'pending'`, but leaves `is_verified = FALSE`
  • Returns HTTP 201 with `{ token, user: { id, full_name, email, role, ... } }`
         │
         ▼
[Frontend: register.js receives response]
  • Executes `saveSession(data.token, data.user)` -> writes snake_case `full_name` to localStorage
  • Hides `registerPanel`, shows `successPanel`
  • Calls `renderDistributorPendingPanel()`
  • BUG 3: `register.html` static `<h1>Create your account</h1>` sits outside `registerPanel`
           and remains visible, visually corrupting the success screen.
  • BUG 4: `renderDistributorPendingPanel()` describes a 3-step timeline (Received -> Review -> Decision)
           and mentions email notification upon decision, but COMPLETELY OMITS any mention that
           the distributor must verify their own email address.
  • BUG 5: The only action provided is a button `<a id="continue-link" href="dashboard.html">Go to Dashboard</a>`.
         │
         ▼
[User Clicks "Go to Dashboard"]
  • Browser navigates to `dashboard.html`
  • `dashboard.js` initializes and reads cached user from localStorage
  • BUG 6: CRITICAL CRASH: `dashboard.js:33` executes:
           `initials(u.fullName);`
           `u.fullName.split(" ")[0];`
           Because the registration response returned `full_name` (not `fullName`),
           `u.fullName` is `undefined`.
           The browser throws: `TypeError: Cannot read properties of undefined (reading 'split')`
  • The dashboard script crashes immediately. Stats, hero banner, and verification notice fail to render.
  • The distributor is left on a broken, frozen screen with no indication of status.
```

---

## 9. Consumer Journey Analysis

```
[index.html] ──> [register.html] ──> [verify-email.html] ──> [login.html] ──> [products.html]
                                                                                     │
[dashboard.html] <── [checkout-success.html] <── [Stripe Gateway] <── [cart.html] <──+
```

### Trace: End-to-End Consumer Journey
1. **Landing Page (`index.html`):**
   - *Logic:* Fetches public platform counters from `/api/stats/public`.
   - *Defect:* Hardcodes `fetch("http://localhost:5000/api/stats/public")` (line 95), bypassing `config.js`.
2. **Registration (`register.html` -> `authController.register`):**
   - *Logic:* Submits `fullName`, `email`, `password`, `phone`. Creates consumer record with `is_verified=FALSE`.
   - *Defect:* Response body leaks `simulatedVerificationLink` with active token, allowing verification bypass.
3. **Email Verification (`verify-email.html` -> `authController.verifyEmail`):**
   - *Logic:* Reads `?token=...`, calls `GET /api/auth/verify-email?token=...`. Updates `is_verified=TRUE`.
   - *Status:* Working as intended when invoked via link.
4. **Login (`login.html` -> `authController.login`):**
   - *Logic:* Authenticates credentials, checks lockout, returns JWT and user profile.
   - *Status:* Working. Stores session in `localStorage` and redirects to `dashboard.html`.
5. **Product Discovery (`products.html` -> `productController.getAllProducts`):**
   - *Logic:* Displays product cards with search and category filters.
   - *Defect:* Catalog displays products from unverified or terminated distributors.
6. **Product Details (`product-details.html` -> `productController.getProductById`):**
   - *Logic:* Renders specifications and conditionally displays Buy Now quantity stepper or Request Quote button.
   - *Status:* Working, but lacks action buttons for unauthenticated visitors.
7. **Cart Management (`cart.html` -> `cartController.*`):**
   - *Logic:* Persistent cart stored in `cart_items` table.
   - *Defect:* Allows adding `quote_request` items, bypassing quote fees.
8. **Checkout & Order Creation (`cart.html` -> `orderController.createCheckoutSession`):**
   - *Logic:* Inserts pending order in `orders` and line items in `order_items`, creates Stripe Checkout Session.
   - *Status:* Working.
9. **Payment Confirmation (`checkout-success.html` -> `orderController.getOrderById`):**
   - *Logic:* Polls order status until Stripe webhook marks order `'paid'`.
   - *Status:* Working, but lacks link to dashboard or order history.
10. **Dashboard & History (`dashboard.html` -> `statsController.getDashboardSummary` & `orderController.getMyOrders`):**
    - *Logic:* Displays consumer metrics (cart count, quotes, completed orders, total spent).
    - *Defect:* Order rows in Recent Activity are not clickable and provide no route to view detailed invoices.

---

## 10. Distributor Journey Analysis

```
[register.html] ──> [successPanel] ──> [Pending Admin Review] ──> [adminController.approve]
        │                                                                  │
        ▼                                                                  ▼
[Broken Redirect]                                                 [vendor-products.html]
```

### Trace: End-to-End Distributor Journey
1. **Registration & KYC Upload (`register.html` -> `authController.register`):**
   - *Logic:* Submits legal credentials and 3 identity files via multipart request.
   - *Defect:* Backend does not generate an email verification token or send a verification email. Success screen visually breaks due to DOM nesting and property naming collisions (`fullName` vs `full_name`).
2. **Pending Review State (`dashboard.html` -> `distributorController.getVerificationStatus`):**
   - *Logic:* Dashboard shows pending banner.
   - *Defect:* If accessed immediately after registration, `dashboard.js` crashes due to `u.fullName` undefined error.
3. **Listing Management (`vendor-products.html` -> `productController.*`):**
   - *Logic:* Gated by `checkVerification()`. Only allows product creation if `verification_status === 'approved'`.
   - *Status:* Working.
4. **Product Editing (`vendor-products.html` -> `productController.updateProduct`):**
   - *Defect:* Update handler fails to validate against negative price or stock values.
5. **Incoming Quote Requests (`received-quotes.html` -> `quoteController.getReceivedQuoteRequests`):**
   - *Defect:* Displays buyer contact info even if quote fee has not been paid.
6. **Account Termination (`adminController.terminateDistributor`):**
   - *Logic:* Admin terminates account; `blockIfTerminated` blocks future seller actions.
   - *Defect:* Terminated distributor listings remain visible in the marketplace catalog.

---

## 11. Admin Journey Analysis

```
[login.html] ──> [admin-dashboard.html] ──> [Document Stream] ──> [Approve / Reject / Terminate]
```

### Trace: End-to-End Admin Journey
1. **Admin Authentication & Authorization:**
   - *Logic:* Admin logs in via `/api/auth/login`. Token contains `role: 'admin'`. Guarded by `requireRole(['admin'])`.
   - *Defect:* `login.js` always redirects to `dashboard.html` instead of `admin-dashboard.html`.
2. **Distributor Review (`admin-dashboard.html` -> `adminController.getPendingDistributors`):**
   - *Logic:* Lists pending distributors. Decrypts `nin_encrypted` using `encryption.decryptField()`.
   - *Status:* Working.
3. **Document Verification (`admin-dashboard.html` -> `adminController.getDistributorDocument`):**
   - *Logic:* Streams files from `backend/uploads/verification-docs/` as binary blobs.
   - *Status:* Working. Uses path traversal defense (`path.basename` and `startsWith(UPLOAD_ROOT)`).
4. **Approval & Rejection:**
   - *Logic:* Sets `verification_status` to `'approved'` or `'rejected'`. Triggers email notification.
   - *Defect:* Approval sets `verification_status='approved'`, but leaves `is_verified=FALSE`.
5. **Account Termination:**
   - *Logic:* Sets `account_status='terminated'`, sends termination email.
   - *Defect:* Uses browser `prompt()` rather than modern modal UI; terminated vendors remain listed in catalog.

---

## 12. Marketplace/Product Architecture

### 12.1 Listing Types & Business Model
The platform defines two distinct product listing paradigms:
1. `buy_now`: Standard e-commerce items. Real-time inventory tracking, added to cart, and purchased via direct Stripe checkout.
2. `quote_request`: High-value, custom, or restricted medical equipment. Direct purchase is disallowed; buyer must submit an RFQ and pay a $25 platform fee to unlock distributor contact details.

### 12.2 Architectural Breakdown of Product Catalog
- **Catalog Filtering:** Handled via dynamic SQL parameterization in `productController.js:12-28`. Supports substring text matching on product name/description (`ILIKE`) and exact category filtering.
- **Stock Decrementing:** Stock is decremented upon Stripe webhook confirmation (`UPDATE products SET stock = stock - $1`).
- **Defects:**
  - No filter on seller account status (`verification_status='approved' AND account_status='active'`).
  - No automated archival or hiding of out-of-stock items.

---

## 13. Cart/Quote Architecture

### 13.1 Cart Mechanism
- Backed by relational table `cart_items` with a unique constraint on `(user_id, product_id)`.
- Re-adding an existing item increments quantity via `ON CONFLICT (user_id, product_id) DO UPDATE SET quantity = cart_items.quantity + $3`.
- **Defect:** `addToCart` fails to verify that the cumulative quantity (`cart_items.quantity + new_quantity`) does not exceed available stock.

### 13.2 Quote Request Mechanism
- Backed by relational table `quote_requests`.
- Enforces single active request per product/consumer pair.
- Fee fixed at $25.00 (`QUOTE_FEE`).
- **Critical Flaw:** Quote and cart boundaries are not isolated; quote items can be purchased through the cart, and buyer contact data leaks to distributors prior to fee payment.

---

## 14. Order/Checkout/Stripe Architecture

### 14.1 Stripe Integration Flow
1. Consumer initiates checkout -> `createCheckoutSession` creates pending order in PostgreSQL -> initializes Stripe Checkout Session (`mode: "payment"`, `currency: "usd"`).
2. Metadata passed: `{ type: "order", order_id: String(orderId) }` or `{ type: "quote_fee", quote_request_id: String(quoteRequestId) }`.
3. Consumer completes payment on Stripe -> Stripe dispatches HTTP POST event to `/api/orders/webhook`.
4. Webhook handler verifies event signature with `stripe.webhooks.constructEvent()` using raw request body.

### 14.2 Webhook Processing Flaws
```javascript
// orderController.js:84-95
const orderId = session.metadata.order_id;
await pool.query("UPDATE orders SET status='paid', updated_at=NOW() WHERE id=$1", [orderId]);
const orderItems = await pool.query("SELECT product_id, quantity FROM order_items WHERE order_id=$1", [orderId]);
for (const item of orderItems.rows) {
  await pool.query("UPDATE products SET stock = stock - $1 WHERE id = $2", [item.quantity, item.product_id]);
}
```
- **Lack of Idempotency:** If Stripe resends `checkout.session.completed`, the loop re-executes, deducting stock a second time.
- **Non-Atomic Operations:** If one product update fails (e.g. stock goes below zero, triggering PostgreSQL `CHECK (stock >= 0)`), the order remains marked `paid`, but inventory decrements abort mid-loop without rollback.

---

## 15. Email and Verification Architecture

### 15.1 Nodemailer Implementation
- Managed in `backend/src/config/emailService.js`.
- If SMTP environment variables are present, creates a Nodemailer transport (`nodemailer.createTransport`).
- If unconfigured, falls back to logging simulated emails to `console.log`.
- Pre-built HTML email templates for:
  - Consumer email verification
  - Distributor application approved
  - Distributor application rejected (with reason)
  - Distributor account terminated (with reason)

### 15.2 Deficiencies
- **Missing Distributor Verification Email:** No verification email template or trigger exists for new distributors.
- **No SMTP Connection Timeouts:** `createTransport` does not configure `connectionTimeout` or `greetingTimeout`, risking blocked worker threads if external SMTP servers become unresponsive.
- **Hardcoded Company Copyright:** Templates hardcode current year via `new Date().getFullYear()`, but brand headers and URLs are hardcoded to `process.env.CLIENT_URL`.

---

## 16. File Upload/Identity Document Architecture

### 16.1 Storage & Validation Model
- Uploads handled via Multer disk storage in `backend/src/middleware/registrationUploadMiddleware.js`.
- Stored in `backend/uploads/verification-docs/`.
- File naming: `${prefix}_${crypto.randomBytes(10).toString("hex")}${ext}`.
- Allowed extensions: `.pdf`, `.jpg`, `.jpeg`, `.png`.
- Allowed MIME types: `application/pdf`, `image/jpeg`, `image/png`, `image/jpg`.
- Max file size: 5 MB per file.

### 16.2 Security Evaluation
- **Access Control:** Excellent. The upload folder is not served statically via Express. Documents are streamed exclusively through `adminController.getDistributorDocument`, requiring admin authentication.
- **Path Traversal Defense:** Sanitized with `path.basename()` and path boundary verification (`absolutePath.startsWith(UPLOAD_ROOT)`).
- **Architectural Debt:** Local disk storage prevents horizontal scaling in container clusters (e.g. Kubernetes, AWS ECS) without shared network volumes. Files on disk are unencrypted.

---

## 17. API Integration Analysis

### 17.1 Frontend API Client (`frontend/js/api.js`)
- Encapsulates all network communication using native browser `fetch()`.
- Standard JSON requests pass through `request(path, options)`.
- File uploads (`registerDistributor`, `submitVerificationDocument`) use `FormData` directly, allowing the browser to set multipart boundaries.
- **Defects:**
  - No automatic token renewal or refresh handling.
  - Lacks standardized request timeout mechanisms (`AbortController`).
  - Error messages returned from the backend are extracted from `data.error`, but fall back to a generic string if JSON parsing fails.

---

## 18. UX and User-Flow Analysis

| Journey | Screen | Current UX Behavior | Intended UX Behavior | Identified Gap |
|---|---|---|---|---|
| **Distributor** | `register.html` | Submits KYC; page visually breaks or redirects directly to broken dashboard | Displays 3-step timeline ("Thank you"), explains email verification, guides next steps | Success screen broken; no email verification explanation |
| **Distributor** | `dashboard.html` | Page crashes with JavaScript error if accessed post-registration | Displays pending status banner and disables listing actions | Fatal `TypeError` on `u.fullName` |
| **Consumer** | `product-details.html` | Clicking "Request Quote" changes button text but provides no link to pay fee | Immediately redirects to fee checkout or directs user to `my-quotes.html` | User stranded without payment link |
| **Consumer** | `cart.html` | Displays cart items; allows checkout of quote-only items | Blocks quote items from entering cart | Business rule violation |
| **Admin** | `admin-dashboard.html` | Terminating an account prompts browser dialog (`prompt()`) | Inline modal or card with structured reason input | Outdated browser prompt |
| **Public** | `index.html` | Footer links for Company ("About", "Contact", "Terms") link to `#` | Directs to real informational pages or policies | Dead placeholder links |

---

## 19. Error, Loading, Empty, and Success-State Analysis

| Screen / Flow | Loading State | Empty State | Error State | Success State |
|---|---|---|---|---|
| **`products.html`** | Skeleton cards (8 placeholders) | Clean empty state with search advice | Generic error banner | Grid of rendered products |
| **`cart.html`** | "Loading your cart..." | Empty state with marketplace link | Alert box banner | Cart table with total summary |
| **`my-quotes.html`** | "Loading your quote requests..." | Empty state with marketplace link | Alert box banner | Cards with unlock status |
| **`received-quotes.html`** | "Loading..." | "No quote requests yet." | Alert box banner | Cards with buyer info |
| **`admin-dashboard.html`** | "Loading..." | "All caught up. ✅" | Inline error banner | Rich review cards |
| **`register.html`** | Button disabled ("Creating account...") | N/A | Alert box banner | **BROKEN:** Double-header collision; missing guidance |
| **`dashboard.html`** | "Loading your dashboard..." | N/A | **BROKEN:** Uncaught exception crashes rendering | Rendered dashboard metrics |

---

## 20. Security Architecture

### 20.1 Vulnerability Review
1. **Critical Secret Leakage (`SEC-01`):** Active Gmail credentials (`SMTP_USER`, `SMTP_PASS`) committed to `backend/.env.example`.
2. **Email Verification Bypass (`SEC-04`):** Consumer verification token exposed directly in HTTP 201 response.
3. **Data Protection at Rest (`SEC-02`):** Physical KYC files on disk are unencrypted.
4. **Catalog Access Control Defect (`SEC-03`):** Terminated sellers' listings remain exposed.
5. **Financial Race Condition (`SEC-05`):** Non-idempotent webhook allows inventory depletion attacks.

---

## 21. Deployment & Runtime Architecture

- **PostgreSQL Database:** Docker container running `postgres:16-alpine`. Configured via `docker-compose.yml`. (Docker daemon currently inactive on host).
- **Backend Application:** Node.js 20 Alpine container defined in `backend/Dockerfile`. Exposed on port 5000.
- **Frontend Delivery:** Unpackaged static files. No web server configuration (e.g. Nginx) is provided for production delivery.
- **Local Development Environment:** Verified host runtimes: Node.js `v24.14.1`, npm `11.11.0`.

---

## 22. Testing Architecture

- **Automated Test Coverage:** 0%.
- **Test Infrastructure:** Completely absent. No test runner, assertions library, or test scripts configured in `package.json`.
- **Impact:** High regression risk for any structural or behavioral modifications.

---

## 23. Confirmed Functional Gaps

### GAP-01: Distributor Registration UI & Flow Breakdown
- **Location:** `frontend/register.html:28-106`, `frontend/js/register.js:129-142`, `frontend/js/dashboard.js:33`.
- **Current Behavior:** Upon distributor submission, the registration card displays colliding headers, fails to communicate email verification requirements, and provides a "Go to Dashboard" button that triggers an uncaught JavaScript `TypeError` in `dashboard.js`.
- **Intended Behavior:** Registration hides the registration panel and title, reveals a polished "Thank you" panel detailing document receipt and email verification requirements, and guides the user into the appropriate verified state.
- **Impact:** Critical. Completely breaks the distributor onboarding experience.
- **Likely Cause:** Structural HTML nesting, missing email verification logic for distributors, and camelCase/snake_case contract mismatch (`fullName` vs `full_name`).
- **Dependencies:** `authController.js`, `register.html`, `register.js`, `dashboard.js`.

### GAP-02: Missing Distributor Email Verification
- **Location:** `backend/src/controllers/authController.js:101-105`.
- **Current Behavior:** Backend sets `emailVerificationToken = null` and skips email dispatch for distributors. `users.is_verified` remains `FALSE` forever.
- **Intended Behavior:** Distributors must verify their email address in addition to submitting KYC documentation before becoming fully active.
- **Impact:** High. Leaves unverified email addresses attached to merchant accounts.
- **Likely Cause:** Omission during Phase 6/7 refactoring.

### GAP-03: Catalog Displays Terminated & Unverified Vendors' Products
- **Location:** `backend/src/controllers/productController.js:12-28`.
- **Current Behavior:** Products are fetched without verifying that `users.verification_status = 'approved'` and `users.account_status = 'active'`.
- **Intended Behavior:** Only listings from approved, active distributors should be visible to consumers.
- **Impact:** High. Consumers can view and order equipment from banned or fake sellers.

### GAP-04: Quote Request / Cart Boundary Violation
- **Location:** `backend/src/controllers/cartController.js:22-45`.
- **Current Behavior:** `addToCart` accepts products regardless of `listing_type`.
- **Intended Behavior:** Quote-only items must be rejected from standard cart checkout.
- **Impact:** High. Bypasses the $25 unlock fee business model.

### GAP-05: Premature Buyer Contact Leakage in Received Quotes
- **Location:** `frontend/js/received-quotes.js:18-27`, `backend/src/controllers/quoteController.js:107-114`.
- **Current Behavior:** Distributor receives buyer's full name and email even when status is `'pending_payment'`.
- **Intended Behavior:** Buyer contact details must remain hidden until the unlock fee is confirmed.
- **Impact:** High. Eliminates buyer incentive to pay the platform unlock fee.

### GAP-06: Stripe Webhook Stock Deduction Non-Idempotent
- **Location:** `backend/src/controllers/orderController.js:84-95`.
- **Current Behavior:** Webhook handler decrements stock without checking if order status is already `'paid'`.
- **Intended Behavior:** Webhook execution must be idempotent and atomic.
- **Impact:** High. Risk of negative inventory counts and failed customer orders.

### GAP-07: Unversioned Database Migrations
- **Location:** `backend/src/config/runMigrations.js`.
- **Current Behavior:** Executes all SQL files on every run without checking a migration history table.
- **Intended Behavior:** Each migration must execute exactly once and be recorded in `schema_migrations`.
- **Impact:** Medium. Threatens database integrity during updates.

---

## 24. Architectural Risks

1. **Compliance & Legal Risk:** Storing unencrypted government ID documents and utility bills on local server disk risks privacy violations.
2. **Platform Trust Erosion:** Unverified or terminated sellers listing healthcare goods damages buyer trust.
3. **Financial Discrepancies:** Non-idempotent webhook processing introduces stock discrepancies.
4. **Maintenance Overhead:** Lack of automated tests guarantees regressions during code modifications.

---

## 25. Recommended Architecture Improvements

1. **Harmonize Data Contracts:** Standardize all backend responses to output consistent camelCase JSON objects matching frontend expectations.
2. **Fix Distributor Onboarding Lifecycle:**
   - Generate `email_verification_token` and send verification email for distributors.
   - Update `register.html` DOM to cleanly toggle titles and render the 3-step confirmation timeline.
   - Add clear guidance regarding email verification and administrative review steps.
3. **Establish Catalog Vendor Filtering:** Enforce seller standing checks (`approved` and `active`) across all public product queries.
4. **Enforce Cart / Quote Segregation:** Reject `quote_request` items in `addToCart`; mask buyer contact details in `received-quotes` until paid.
5. **Transactional & Idempotent Webhook Handler:** Implement `SELECT status FROM orders WHERE id = $1 FOR UPDATE` and conditional execution within database transactions.
6. **Tracked Schema Migrations:** Introduce a `schema_migrations` table to ensure safe, one-time migration execution.
7. **Introduce Automated Test Suite:** Configure Jest and Supertest for unit and integration testing.

---

## 26. Dependencies Between Improvements

```mermaid
graph TD
    A[Harmonize Data Contracts & Fix Secrets] --> B[Fix Distributor Onboarding & Email Verification]
    A --> C[Establish Tracked Migrations schema_migrations]
    C --> D[Catalog Vendor Standing Filter]
    C --> E[Cart / Quote Segregation & Contact Masking]
    C --> F[Transactional & Idempotent Webhook Handler]
    B --> G[Automated Test Harness Jest + Supertest]
    D --> G
    E --> G
    F --> G
```

---

## 27. Changes Requiring Human Approval

1. **Distributor Email Verification Requirement:** Confirm that distributors must verify their email address before their account can be approved by an admin or access seller features.
2. **Document Storage Strategy:** Confirm retention of local disk storage with hardened access control vs. introducing a cloud object storage driver (e.g. AWS S3).
3. **Database Migration Tooling:** Confirm implementation of a custom `schema_migrations` tracking table in `runMigrations.js` vs. introducing a third-party package (`node-pg-migrate`).
4. **Scrubbing Leaked Secrets:** Confirm immediate removal and rotation of SMTP credentials in `backend/.env.example`.

---

## 28. Proposed Implementation Priorities

1. **Priority 1 (Security & Onboarding Fixes):**
   - Scrub `.env.example` secrets.
   - Fix distributor registration flow, email verification dispatch, and `register.html`/`dashboard.js` contract crash.
2. **Priority 2 (Marketplace Integrity & Business Logic):**
   - Enforce vendor verification/standing filters on product catalog.
   - Prevent `quote_request` items from entering standard cart.
   - Mask buyer contact details in received quotes until paid.
3. **Priority 3 (Financial & Data Reliability):**
   - Make Stripe webhook handler idempotent and transactional.
   - Implement `schema_migrations` tracking in `runMigrations.js`.
4. **Priority 4 (Quality Assurance & Hardening):**
   - Build automated test suite (Jest + Supertest) covering auth, KYC, cart, orders, and quotes.
   - Fix dead footer links and add responsive polish.

---

## 29. Conclusion & Pipeline Next Steps

This Architecture Analysis concludes **Phase 3**. The team has identified all architectural defects, functional breakdowns, and integration gaps. 

In strict compliance with pipeline rules:
- No application code, frontend code, or database structures were modified.
- We will **STOP** here and await your explicit approval and guidance on the decisions in Section 27 before advancing to **Phase 4: Technical Specification** (`production_artifacts/Technical_Specification.md`).
