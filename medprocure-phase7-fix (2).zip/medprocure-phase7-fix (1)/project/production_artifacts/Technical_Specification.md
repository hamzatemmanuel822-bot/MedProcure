# MedProcure Technical Specification & Target Architecture

**Document Version:** 1.0  
**Phase:** Phase 4 – Technical Specification  
**Status:** Awaiting Human Approval  
**Date:** October 5, 2026  
**Lead Architect & Autonomous Engineering Team:** MedProcure Engineering Team (@architect, @pm, @engineer, @qa, @security, @devops)

---

## 1. Executive Summary

MedProcure is a multi-vendor medical equipment procurement marketplace engineered to connect **Healthcare Consumers** (clinics, hospitals, procurement officers, practitioners) with vetted, identity-verified **Distributors** (medical device manufacturers, authorized regional suppliers), governed by authorized **Platform Administrators**.

The primary value proposition of MedProcure is **verified trust in healthcare equipment supply**. The platform prevents counterfeit medical supply fraud, ghost vendors, and unauthorized brokers through:
1. **Mandatory Multi-Factor Distributor Identity Verification (KYC):** Government National Identification Number (NIN) validation with AES-256-GCM encryption at rest and SHA-256 one-way hashing for Sybil/duplicate account prevention.
2. **Three-Document Compliance Pipeline:** Compulsory submission of identity photo/government ID, Corporate Affairs Commission (CAC) business registration/license, and proof of physical address (utility bill/bank statement) at signup.
3. **Dual Verification Gates:** Mandatory email verification coupled with human administrative verification prior to catalog access or merchant activation.
4. **Bimodal Marketplace Transactions:** Support for standard direct e-commerce (`buy_now`) through Stripe Checkout alongside gated Request-For-Quote (`quote_request`) workflows for high-value or restricted medical apparatus, where buyer contact details remain cryptographically and logically shielded until a $25 contact unlock fee is paid.
5. **Enforced Platform Standing:** Instant, system-wide suppression of listings belonging to unapproved, rejected, or terminated distributors, backed by real-time database-driven session revocation (`blockIfTerminated`).

This technical specification establishes the blueprint for upgrading, restructuring, and hardening the existing MedProcure codebase into a production-grade system without creating a duplicate application.

---

## 2. Project Context & Objectives

### 2.1 Background
The MedProcure codebase has evolved through seven iterative development phases, culminating in Phase 6 (Seller KYC Verification + Security Hardening) and Phase 7 (Approval Flow Setup, Proof of Address, Terms & Termination). While core features—including field-level NIN encryption, Multer document uploads, and Stripe webhooks—were introduced, the project accumulated critical integration defects:
- The distributor post-registration experience fails visually and logically, leaving users stranded without email verification guidance and triggering fatal client-side JavaScript crashes on subsequent dashboard visits.
- Unapproved and terminated vendors remain visible in public marketplace catalogs.
- Quote-only items bypass quote unlock fees by being added directly to shopping carts.
- Stripe webhook execution is non-idempotent and lacks atomic database transactions.
- Migrations are unversioned and re-execute destructive updates on every application launch.
- Real SMTP credentials were inappropriately exposed in `.env.example`.

### 2.2 Core Engineering Objectives
1. **Preserve Valid Foundations:** Retain the existing Node.js/Express CommonJS backend, vanilla ES6 modular frontend, and PostgreSQL 16 relational database. Do NOT rewrite the stack or create duplicate applications (e.g. `app_build/`).
2. **Eliminate Critical Security Flaws:** Scrub `.env.example` of compromised credentials, treat previously exposed credentials as revoked, sanitize API responses to eliminate verification token leakage, and maintain local filesystem KYC storage behind a hardened storage abstraction.
3. **Unify Distributor & Consumer Onboarding:** Harmonize the user contract (`camelCase` vs. `snake_case`), implement email verification for distributors as a prerequisite for admin review, and deliver a polished 3-step "Thank You" pending timeline.
4. **Enforce Marketplace Business Rules:** Restrict catalog queries to approved and active distributors, prevent `quote_request` products from entering the cart, and protect consumer contact information until quote fees are settled.
5. **Ensure Financial & Data Integrity:** Introduce `schema_migrations` tracking for raw SQL migrations, and wrap Stripe webhook handling in idempotent, row-locked database transactions.
6. **Deliver Quality Assurance & Deployability:** Establish an automated test suite (Jest + Supertest), configure Docker and local runtimes, and eliminate broken UI navigation links.

---

## 3. Existing-System Findings & Approved Decisions

Based on the verified results from `production_artifacts/project_audit.md` and `production_artifacts/architecture_analysis.md`, the ten approved architectural decisions are incorporated as non-negotiable architectural mandates:

| # | Approved Architectural Mandate | Technical Impact & Remediation |
|---|---|---|
| **1** | **Distributors must verify email before administrative KYC approval/account activation.** | Add `email_verification_token` generation and verification email dispatch to distributor signup in `authController.js`. `is_verified` must be `TRUE` before an admin can approve the account. |
| **2** | **Keep local KYC document filesystem storage for now, but introduce a storage abstraction.** | Retain `backend/uploads/verification-docs/` with non-public streaming, but encapsulate all disk operations within a `StorageService` interface (`IStorageProvider`) to enable future zero-friction S3 migration. |
| **3** | **Keep raw SQL migrations and add `schema_migrations` tracking.** | Maintain raw `.sql` files in `backend/src/migrations/`, but update `runMigrations.js` to create and check a `schema_migrations` table, executing each migration exactly once in a transaction. |
| **4** | **Sanitize `backend/.env.example` and treat previously exposed real SMTP credentials as compromised and requiring rotation/revocation.** | Scrub real credentials from `.env.example`, substitute safe placeholders, and alert administrators to rotate the compromised Google App Password immediately. |
| **5** | **Fix the frontend/backend user object contract mismatch properly.** | Standardize all auth and user endpoints (`register`, `login`, `getMe`) to return uniform `camelCase` properties (`id`, `fullName`, `email`, `role`, `isVerified`, `verificationStatus`, `accountStatus`, `businessName`, `createdAt`). |
| **6** | **Only approved and active distributors should have publicly visible/purchasable products.** | Update `productController.getAllProducts`, `getCategoryInsights`, and `getProductById` to enforce `INNER JOIN users ON products.vendor_id = users.id WHERE users.verification_status = 'approved' AND users.account_status = 'active'`. |
| **7** | **Quote-only listings must not bypass the quote/unlock/payment workflow.** | Enforce validation in `cartController.addToCart` requiring `product.listing_type === 'buy_now'`. Return HTTP 400 if a consumer attempts to cart a `quote_request` product. |
| **8** | **Protect buyer contact information until the appropriate payment/unlock condition.** | Redact buyer `full_name`, `email`, and `phone` in `quoteController.getReceivedQuoteRequests` and `getQuoteRequestById` whenever `quote_requests.status !== 'unlocked'`. |
| **9** | **Make Stripe webhook processing idempotent and inventory changes transactional.** | In `orderController.handleStripeWebhook`, execute within `BEGIN ... COMMIT` with `SELECT status FROM orders WHERE id = $1 FOR UPDATE`. Bail out early if already `'paid'`. Decrement stock atomically. |
| **10** | **Address dead footer links and missing marketplace calls-to-action as part of the overall UX.** | Replace dead `#` links in `footer.js` and landing templates with functional modals or routes (`terms.html`, support contacts), and add clear action CTAs across product discovery views. |

---

## 4. Functional Requirements

### 4.1 Epic 1: Authentication, Registration & Verification
- **FR-1.1 Consumer Registration:** Consumers register with `fullName`, `email`, `password`, and optional `phone`. Password must be $\ge 8$ characters and contain letters and numbers. A cryptographically random 32-byte hex token is generated and stored in `users.email_verification_token` with a 24-hour expiration (`email_verification_expires_at`). An activation email is dispatched via Nodemailer.
- **FR-1.2 Distributor Registration:** Distributors register with business name, registration/license number, contact phone, residential address, date of birth, 11-digit NIN, and mandatory agreement to Terms of Operation (`terms_accepted_at = NOW()`).
- **FR-1.3 Distributor KYC Upload:** Registration requires three distinct file uploads (`idPhoto`, `licenseDocument`, `proofOfAddress`) totaling $\le 5$ MB per file in PDF, JPG, or PNG formats.
- **FR-1.4 Distributor Post-Registration Panel:** Upon registration, the browser reveals a polished "Thank you" panel displaying a 3-step visual timeline:
  1. *Documents & Application Received* (Completed)
  2. *Verify Your Email Address* (Action Required: Prompting user to check their inbox)
  3. *Administrative Review & Activation* (Pending: Decisions communicated within 24-48 hours)
- **FR-1.5 Email Verification Processing:** When a user visits `/verify-email.html?token=...`, the backend validates token presence and expiration, marks `users.is_verified = TRUE`, clears the token, and returns a verified status response. Tokens are NEVER emitted in registration API responses.
- **FR-1.6 User Authentication (Login):** Validates email and password, returning a 7-day signed JWT and sanitized user profile. Implements brute-force lockout: 5 consecutive failures locks the account for 15 minutes (`users.locked_until`). Generic error messages (`"Invalid email or password."`) are returned regardless of whether the email exists.
- **FR-1.7 Terminated User Invalidation:** Terminated accounts are rejected immediately at login (HTTP 403 Forbidden with termination reason). Authenticated requests check database status via `blockIfTerminated` middleware and revoke access in real time.

### 4.2 Epic 2: Administrative Review & KYC Governance
- **FR-2.1 Admin Review Console:** Admins view all pending distributor applications with decrypted NINs, business details, registration dates, and direct links to view uploaded verification documents.
- **FR-2.2 Secure Document Streaming:** Verification files are streamed directly to authorized admins via `GET /api/admin/distributors/:id/document?type=idPhoto|licenseDocument|proofOfAddress`. Files are never exposed via static public directories.
- **FR-2.3 Approval Gating:** An admin can approve a distributor ONLY IF `users.is_verified === TRUE`. Attempting to approve an unverified email returns HTTP 400 (`"Distributor must verify email address before administrative approval."`). Approval transitions `verification_status = 'approved'`, `account_status = 'active'`, and dispatches an approval notification email.
- **FR-2.4 Application Rejection:** Admins can reject an application with an inline rejection reason. Transitions `verification_status = 'rejected'` and sends an explanatory email.
- **FR-2.5 Re-submission Workflow:** Rejected distributors can re-upload their documents through the dashboard (`POST /api/distributors/verification`), resetting status to `'pending'`.
- **FR-2.6 Account Termination:** Admins can terminate an active distributor for policy violations via a structured modal with a required reason. Transitions `account_status = 'terminated'`, records `terminated_at` and `terminated_reason`, dispatches a termination notice, blocks future logins, and suppresses listings.

### 4.3 Epic 3: Marketplace Product Catalog & Inventory
- **FR-3.1 Public Catalog Browsing:** Any visitor can view active products with category filtering, search terms (`ILIKE`), and sorting. Catalog queries strictly exclude products whose distributors are not `verification_status = 'approved'` and `account_status = 'active'`.
- **FR-3.2 Product Details & Specifications:** Displays product images, price, stock, category, distributor business name, verification badge, and technical specifications.
- **FR-3.3 Listing Classification:** Products are flagged as either `buy_now` (e-commerce purchase) or `quote_request` (custom RFQ inquiry).
- **FR-3.4 Vendor Catalog Management:** Approved, active distributors can create, read, update, and delete their own listings. Product creation and updates validate that `price >= 0` and `stock >= 0`. Image URLs must start with `http://` or `https://`.

### 4.4 Epic 4: Shopping Cart & Direct Checkout (`buy_now`)
- **FR-4.1 Cart Isolation:** Only `buy_now` products can be added to user carts. `cartController.addToCart` verifies `product.listing_type === 'buy_now'` and rejects quote-only items with HTTP 400.
- **FR-4.2 Persistent Carts:** Cart items are tied to authenticated consumers in PostgreSQL (`cart_items`), supporting quantity updates and deletions.
- **FR-4.3 Stock Limits in Cart:** The backend validates that requested quantities do not exceed available product inventory (`quantity <= stock`).
- **FR-4.4 Stripe Checkout Session Creation:** Initiates a Stripe Checkout session in `payment` mode with line items matching the cart. An initial order record is created with status `'pending'`.
- **FR-4.5 Post-Payment Fulfillment:** Upon receiving `checkout.session.completed` from Stripe:
  1. Checks if `orders.status === 'paid'` (idempotency bail-out).
  2. Acquires row locks (`FOR UPDATE`) on affected product records.
  3. Validates sufficient stock remains.
  4. Decrements product stock and transitions order status to `'paid'`.
  5. Clears purchased items from the consumer's cart.

### 4.5 Epic 5: Request-for-Quote (RFQ) & Contact Unlock Workflow
- **FR-5.1 Quote Request Submission:** Healthcare consumers submit an RFQ for `quote_request` items, providing intended quantity, procurement timeframe, delivery facility address, and technical notes.
- **FR-5.2 Contact Privacy Protection:** Incoming quote requests on the distributor dashboard (`received-quotes.html`) display equipment requirements and delivery address, but buyer `full_name`, `email`, and `phone` are masked as `[Locked - Requires Payment]` while status is `'pending_payment'`.
- **FR-5.3 Unlock Fee Settlement:** Consumers pay a fixed $25 platform fee (`QUOTE_FEE`) via Stripe Checkout.
- **FR-5.4 Contact Details Unlocking:** Upon Stripe webhook confirmation for `type: "quote_fee"`:
  1. Updates `quote_requests.status = 'unlocked'` and `fee_paid_at = NOW()`.
  2. Distributor views full consumer contact details to initiate direct negotiation.
  3. Dispatches email notifications to both consumer and distributor confirming quote unlock.

---

## 5. Non-Functional Requirements

### 5.1 Security & Data Protection
- **NFR-1.1 Field-Level Cryptography:** National Identification Numbers (NIN) must be encrypted using AES-256-GCM with unique 12-byte initialization vectors and authentication tags. SHA-256 hashes must be indexed to enforce global uniqueness without exposing plaintext.
- **NFR-1.2 Zero Credential Exposure:** Environment configuration files (`.env.example`) must never contain real passwords, API tokens, or secrets. API responses must never leak tokens or encryption keys.
- **NFR-1.3 Content Security & Sanitization:** All dynamic DOM insertions must pass through HTML escaping (`escapeHtml()`). Express routes must employ Helmet security headers, locked-down CORS origins, and request body size limits ($\le 1$ MB JSON, $\le 5$ MB multipart files).
- **NFR-1.4 Identity File Protection:** KYC files must reside outside web server static roots, with access strictly restricted to authorized admin streaming endpoints containing path-traversal guards.

### 5.2 Reliability & Transactional Integrity
- **NFR-2.1 Idempotent Operations:** Financial webhooks must handle duplicate Stripe transmissions gracefully without duplicate inventory deductions or double billing.
- **NFR-2.2 Concurrency & Acid Safety:** Multi-table order fulfillment operations must execute within transactional boundaries (`BEGIN ... COMMIT`) utilizing pessimistic locking (`FOR UPDATE`) on product rows.
- **NFR-2.3 Migration Repeatability:** Database schema migrations must execute deterministically, recording completion in a `schema_migrations` ledger to prevent re-execution anomalies.

### 5.3 Performance & Scalability
- **NFR-3.1 Response Latencies:** Public catalog endpoints (`GET /api/products`) must respond in $< 100$ ms under nominal loads.
- **NFR-3.2 Database Connection Optimization:** PostgreSQL connection pooling (`pg.Pool`) capped at 20 active connections with idle timeouts of 30 seconds.
- **NFR-3.3 Rate Limiting:** 10 requests per 15-minute window for auth routes (`/api/auth/*`), 300 requests per 15-minute window for standard API operations.

---

## 6. User Roles and Permissions Matrix

The platform implements strict Role-Based Access Control (RBAC) across three distinct actors:

```mermaid
graph TD
    User([Authenticated User]) -->|Role Check| Role{Role Assignment}
    Role -->|healthcare_consumer| Consumer[Consumer Capabilities]
    Role -->|distributor| DistCheck{Active & Approved?}
    DistCheck -->|Yes| Dist[Distributor Capabilities]
    DistCheck -->|No| PendingDist[Restricted Pending Capabilities]
    Role -->|admin| Admin[Platform Admin Capabilities]

    Consumer --> C1[Browse Catalog]
    Consumer --> C2[Manage Cart]
    Consumer --> C3[Checkout Buy Now]
    Consumer --> C4[Submit Quote Request]
    Consumer --> C5[Pay Unlock Fee]
    Consumer --> C6[View Own Orders/Quotes]

    Dist --> D1[Create/Edit Products]
    Dist --> D2[View Received Quotes & Unlocked Contacts]
    Dist --> D3[Track Vendor Sales]

    PendingDist --> PD1[View KYC Status Banner]
    PendingDist --> PD2[Re-upload Rejected Documents]

    Admin --> A1[View Pending KYC Applications]
    Admin --> A2[Decrypt Full NIN for Review]
    Admin --> A3[Stream Identity Documents]
    Admin --> A4[Approve Verified Distributors]
    Admin --> A5[Reject Incomplete Applications]
    Admin --> A6[Terminate Accounts & Revoke Access]
```

### Detailed Permissions Matrix

| Functional Resource / Operation | Guest / Public | Healthcare Consumer | Distributor (Pending) | Distributor (Approved) | Platform Admin |
|---|:---:|:---:|:---:|:---:|:---:|
| Browse Approved Products & Search | ✅ | ✅ | ✅ | ✅ | ✅ |
| View Product Details & Specs | ✅ | ✅ | ✅ | ✅ | ✅ |
| User Registration & Email Verification | ✅ | ✅ | ✅ | ✅ | ✅ |
| Add `buy_now` Item to Cart | ❌ | ✅ | ❌ | ❌ | ❌ |
| Checkout Cart via Stripe | ❌ | ✅ | ❌ | ❌ | ❌ |
| Submit `quote_request` (RFQ) | ❌ | ✅ | ❌ | ❌ | ❌ |
| Pay $25 Contact Unlock Fee | ❌ | ✅ | ❌ | ❌ | ❌ |
| View Unlocked Distributor Contact | ❌ | ✅ (If Unlocked) | ❌ | ❌ | ✅ |
| Create / Edit / Delete Products | ❌ | ❌ | ❌ | ✅ | ❌ |
| View Incoming Quote Requests | ❌ | ❌ | ❌ | ✅ | ❌ |
| View Buyer Contact Details on Quote | ❌ | ❌ | ❌ | ✅ (If Unlocked) | ✅ |
| View Distributor Pending Status | ❌ | ❌ | ✅ | ✅ | ✅ |
| Re-Upload Rejected Documents | ❌ | ❌ | ✅ (If Rejected) | ❌ | ❌ |
| View Decrypted Full NIN | ❌ | ❌ | ❌ | ❌ | ✅ |
| Stream Identity Documents | ❌ | ❌ | ❌ | ❌ | ✅ |
| Approve / Reject KYC Applications | ❌ | ❌ | ❌ | ❌ | ✅ |
| Terminate Distributor Account | ❌ | ❌ | ❌ | ❌ | ✅ |

---

## 7. Application Architecture

MedProcure is structured as a 3-tier monolithic application emphasizing simplicity, security, and low operational friction.

```mermaid
flowchart TD
    subgraph ClientTier ["Client Tier (Browser MPA)"]
        UI_Public["Public Views (index, products, details)"]
        UI_Auth["Auth Views (login, register, verify-email)"]
        UI_Consumer["Consumer Views (cart, checkout-success, my-quotes)"]
        UI_Distributor["Distributor Views (vendor-products, received-quotes)"]
        UI_Admin["Admin Views (admin-dashboard)"]
        Client_State["Client State & Modules (localStorage, api.js, auth.js, utils.js)"]
    end

    subgraph APITier ["Backend API & Middleware Tier (Node.js/Express)"]
        MW_Sec["Security Middleware (Helmet, CORS, RateLimiter)"]
        MW_Auth["Auth Middleware (requireAuth, requireRole, blockIfTerminated)"]
        MW_Upload["Upload Middleware (Multer with MIME/Ext validation)"]
        
        subgraph Controllers ["Application Controllers"]
            C_Auth["authController"]
            C_Prod["productController"]
            C_Cart["cartController"]
            C_Order["orderController"]
            C_Quote["quoteController"]
            C_Dist["distributorController"]
            C_Admin["adminController"]
            C_Stats["statsController"]
        end
        
        subgraph CoreServices ["Core Services & Abstractions"]
            S_Crypt["EncryptionService (AES-256-GCM / SHA-256)"]
            S_Store["StorageService (IStorageProvider / LocalDisk)"]
            S_Mail["EmailService (Nodemailer SMTP / Console)"]
            S_Stripe["StripeSDK (Checkout / Webhooks)"]
        end
    end

    subgraph DataTier ["Persistence & Infrastructure Tier"]
        DB_PG[("PostgreSQL 16 Database\n(Dockerized: medprocure_postgres)")]
        FS_Docs[("Protected Document Filesystem\n(backend/uploads/verification-docs/)")]
        Ext_Stripe[["External Stripe API"]]
        Ext_SMTP[["External SMTP Gateway"]]
    end

    ClientTier <-->|HTTPS REST JSON & Multipart| APITier
    APITier <-->|pg Connection Pool| DB_PG
    APITier <-->|Stream File Streams| FS_Docs
    APITier <-->|API Calls & Webhook Events| Ext_Stripe
    APITier <-->|SMTP Mail Dispatch| Ext_SMTP
```

---

## 8. Frontend Architecture

### 8.1 Structure & Component Design
The frontend operates as a Multi-Page Application (MPA) requiring zero build steps or bundlers.
```
frontend/
├── index.html                   # Public marketplace landing page & statistics
├── products.html                # Searchable, filterable catalog of verified equipment
├── product-details.html         # Equipment specs, buy-now action, or quote request trigger
├── login.html                   # Unified authentication view with brute-force error display
├── register.html                # Bimodal registration (Consumer vs Distributor KYC upload)
├── verify-email.html            # Email token verification landing view
├── dashboard.html               # Role-adaptive unified dashboard (Consumer vs Distributor)
├── cart.html                    # Persistent consumer shopping cart & Stripe checkout link
├── checkout-success.html        # Post-purchase order confirmation & status poller
├── my-quotes.html               # Consumer RFQ tracker with unlock fee payment triggers
├── quote-success.html           # Post-fee payment poller & contact unlock confirmation
├── vendor-products.html         # Distributor catalog management & CRUD portal
├── received-quotes.html         # Distributor inbound RFQ manager with masked contact view
├── admin-dashboard.html         # Admin verification center (Pending reviews & Active terminations)
├── terms.html                   # Distributor Terms of Operation & Compliance Policy
├── css/                         # 10 Modular CSS stylesheets (variables, main, cards, admin, etc.)
└── js/
    ├── config.js                # Centralized environment constants (API_BASE_URL)
    ├── api.js                   # Unified fetch API client with error normalization
    ├── auth.js                  # Session storage, role inspection & token management
    ├── utils.js                 # XSS sanitation (escapeHtml) & formatting utilities
    ├── components/              # Shared UI components (footer.js, quantityStepper.js)
    └── [page-modules].js        # Discrete page controllers (admin.js, dashboard.js, etc.)
```

### 8.2 Frontend State Management & Auth Lifecycle
1. **Client Storage Contract:** Browser `localStorage` holds two keys:
   - `medprocure_token`: Raw JWT string.
   - `medprocure_user`: Serialized JSON user object normalized strictly into `camelCase`:
     ```json
     {
       "id": 12,
       "fullName": "Dr. Sarah Alabi",
       "email": "sarah@cityclinic.ng",
       "role": "healthcare_consumer",
       "isVerified": true,
       "verificationStatus": "not_applicable",
       "accountStatus": "active",
       "businessName": null,
       "createdAt": "2026-10-05T01:00:00Z"
     }
     ```
2. **Session Persistence & Recovery:** `auth.js` provides helper methods `getUser()`, `getToken()`, `isAuthenticated()`, and `logout()`. Page bootstrap routines inspect session validity and redirect unauthorized users before rendering sensitive components.

### 8.3 Remediation of Contract & Rendering Defects
- **Resolution of `u.fullName` Crash in `dashboard.js`:** In `auth.js` and `api.js`, all received user objects are normalized through a transformation adapter:
  ```javascript
  export function normalizeUser(raw) {
    if (!raw) return null;
    return {
      id: raw.id,
      fullName: raw.fullName || raw.full_name || "",
      email: raw.email || "",
      role: raw.role || "",
      isVerified: raw.isVerified !== undefined ? raw.isVerified : raw.is_verified,
      verificationStatus: raw.verificationStatus || raw.verification_status || "not_applicable",
      accountStatus: raw.accountStatus || raw.account_status || "active",
      businessName: raw.businessName || raw.business_name || null,
      createdAt: raw.createdAt || raw.created_at
    };
  }
  ```
- **Correction of `register.html` DOM Nesting:** Move the static `<h1>Create your account</h1>` inside the `#register-form-card` container so that hiding `#register-form-card` and displaying `#success-panel` cleanly removes all registration titles and prevents visual collision.
- **Dynamic 3-Step Timeline Rendering:** `#success-panel` dynamically renders:
  ```html
  <div class="timeline-step step-complete">
    <div class="step-num">✓</div>
    <div><strong>Step 1: Application & Documents Received</strong><p>Your business credentials have been uploaded securely.</p></div>
  </div>
  <div class="timeline-step step-active">
    <div class="step-num">2</div>
    <div><strong>Step 2: Verify Your Email Address</strong><p>We've sent a verification link to your email. Click it to confirm your identity.</p></div>
  </div>
  <div class="timeline-step step-pending">
    <div class="step-num">3</div>
    <div><strong>Step 3: Administrative KYC Review</strong><p>Our compliance team verifies licenses within 24-48 hours after email confirmation.</p></div>
  </div>
  ```

---

## 9. Backend Architecture

### 9.1 Module Layout & Responsibilities
The Node.js Express application follows a standard modular organization:
- `server.js`: Orchestrates middleware, mounts domain routes under `/api`, serves raw Stripe webhook body, and handles unhandled exceptions.
- `src/config/`:
  - `db.js`: Configures PostgreSQL connection pool with connection error event handling.
  - `encryption.js`: Encapsulates AES-256-GCM symmetric encryption/decryption and SHA-256 hashing.
  - `storageService.js` *(New Abstraction)*: Exposes `saveFile`, `getFileStream`, and `deleteFile`. Implements local disk operations with path traversal sanitization, structured for pluggable S3/cloud drivers.
  - `emailService.js`: Nodemailer wrapper with HTML email templates and console fallback.
  - `stripe.js`: Stripe SDK initialization with API version pinning.
  - `runMigrations.js`: Versioned sequential SQL migration runner.
- `src/controllers/`: Encapsulates database queries, business rule enforcement, and HTTP responses.
- `src/middleware/`:
  - `authMiddleware.js`: JWT verification (`requireAuth`), role enforcement (`requireRole`), and real-time account standing validation (`blockIfTerminated`).
  - `rateLimiter.js`: IP-based request throttlers.
  - `registrationUploadMiddleware.js`: Multer multipart processor for 3 KYC documents.
  - `uploadMiddleware.js`: Multer processor for post-registration single file re-submission.

### 9.2 Pluggable Storage Abstraction (`StorageService`)
To satisfy architectural decision #2 (retaining local filesystem while establishing a clean boundary for future cloud storage), all file operations are isolated behind `StorageService`:

```javascript
// src/config/storageService.js
const fs = require("fs");
const path = require("path");

class LocalStorageProvider {
  constructor(baseDir) {
    this.baseDir = baseDir;
    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true });
    }
  }

  async getFileStream(filePath) {
    const filename = path.basename(filePath);
    const absolutePath = path.resolve(this.baseDir, filename);
    if (!absolutePath.startsWith(path.resolve(this.baseDir))) {
      throw new Error("Path traversal detected.");
    }
    if (!fs.existsSync(absolutePath)) {
      return null;
    }
    return {
      stream: fs.createReadStream(absolutePath),
      size: fs.statSync(absolutePath).size,
      mimeType: filename.endsWith(".pdf") ? "application/pdf" : "image/jpeg"
    };
  }

  async deleteFile(filePath) {
    const filename = path.basename(filePath);
    const absolutePath = path.resolve(this.baseDir, filename);
    if (fs.existsSync(absolutePath)) {
      fs.unlinkSync(absolutePath);
    }
  }
}

module.exports = new LocalStorageProvider(path.join(__dirname, "../../uploads/verification-docs"));
```

---

## 10. Database Architecture

### 10.1 Entity Relationship Diagram (Target Schema)

```mermaid
erDiagram
    schema_migrations {
        int id PK
        varchar version UK
        timestamp applied_at
    }

    audit_logs {
        int id PK
        int actor_id FK
        varchar action
        varchar entity_type
        int entity_id
        text details
        timestamp created_at
    }

    users ||--o{ products : "supplies"
    users ||--o{ cart_items : "reserves"
    users ||--o{ orders : "places (consumer)"
    users ||--o{ quote_requests : "requests (consumer)"
    users ||--o{ quote_requests : "receives (distributor)"
    users ||--o{ audit_logs : "triggers"
    products ||--o{ cart_items : "selected in"
    products ||--o{ order_items : "fulfilled in"
    products ||--o{ quote_requests : "referenced in"
    orders ||--|{ order_items : "contains"

    users {
        int id PK
        varchar full_name
        varchar email UK
        text password_hash
        varchar role "DEFAULT 'healthcare_consumer'"
        varchar phone
        boolean is_verified "DEFAULT FALSE"
        varchar email_verification_token
        timestamp email_verification_expires_at
        varchar verification_status "DEFAULT 'not_applicable'"
        varchar business_name
        varchar license_number
        text nin_encrypted
        text nin_hash UK
        text id_photo_path
        text license_document_path
        text proof_of_address_path
        date date_of_birth
        text residential_address
        varchar account_status "DEFAULT 'active'"
        text terminated_reason
        timestamp terminated_at
        timestamp terms_accepted_at
        varchar terms_version
        int failed_login_attempts "DEFAULT 0"
        timestamp locked_until
        timestamp created_at
        timestamp updated_at
    }

    products {
        int id PK
        int vendor_id FK
        varchar name
        text description
        numeric price "CHECK >= 0"
        int stock "CHECK >= 0"
        varchar category
        text image_url
        varchar listing_type "DEFAULT 'buy_now'"
        timestamp created_at
        timestamp updated_at
    }

    cart_items {
        int id PK
        int user_id FK
        int product_id FK
        int quantity "CHECK > 0"
        timestamp created_at
    }

    orders {
        int id PK
        int customer_id FK
        numeric total_amount "CHECK >= 0"
        varchar status "DEFAULT 'pending'"
        text stripe_session_id UK
        timestamp created_at
        timestamp updated_at
    }

    order_items {
        int id PK
        int order_id FK
        int product_id FK
        int vendor_id FK
        int quantity "CHECK > 0"
        numeric price_at_purchase "CHECK >= 0"
    }

    quote_requests {
        int id PK
        int product_id FK
        int healthcare_consumer_id FK
        int distributor_id FK
        int requested_quantity
        varchar intended_use
        varchar delivery_timeline
        text facility_address
        text notes
        varchar status "DEFAULT 'pending_payment'"
        numeric fee_amount "DEFAULT 25.00"
        text stripe_session_id UK
        timestamp fee_paid_at
        timestamp created_at
        timestamp updated_at
    }
```

### 10.2 Versioned Migration Strategy (`schema_migrations`)
To guarantee safe, idempotent execution of raw SQL migrations:
1. `backend/src/config/runMigrations.js` first creates the tracking table:
   ```sql
   CREATE TABLE IF NOT EXISTS schema_migrations (
       id SERIAL PRIMARY KEY,
       version VARCHAR(255) UNIQUE NOT NULL,
       applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
   );
   ```
2. The runner queries `SELECT version FROM schema_migrations`.
3. For each file in `backend/src/migrations/*.sql` in alphabetical order, if the file name does not exist in `schema_migrations`, it executes the SQL in a database transaction (`BEGIN ... COMMIT`) and records the file name in `schema_migrations`.
4. Migration `010_add_migration_tracking_and_indexes.sql` will be introduced to:
   - Add missing indexes: `idx_order_items_product (product_id)`, `idx_order_items_vendor (vendor_id)`, `idx_products_vendor_standing (vendor_id)`.
   - Alter `users.role` column default from `'customer'` to `'healthcare_consumer'`.
   - Add `email_verification_expires_at TIMESTAMP WITH TIME ZONE` to `users`.
   - Create `audit_logs` table for tracking administrative approvals, rejections, and terminations.

---

## 11. API Specification & Interface Contracts

All API endpoints are mounted under `/api` and consume/produce `application/json` (except document streaming and multipart uploads).

### 11.1 Authentication & Profile (`/api/auth`)
| Method | Path | Auth / Role | Description | Success Response |
|---|---|---|---|---|
| `POST` | `/api/auth/register` | Public (`authLimiter`) | Register consumer or distributor | `201 Created` `{ message, token, user }` *(No leaked verification tokens!)* |
| `POST` | `/api/auth/login` | Public (`authLimiter`) | Authenticate user | `200 OK` `{ token, user }` |
| `GET` | `/api/auth/verify-email` | Public | Verify email via token | `200 OK` `{ message, email }` |
| `GET` | `/api/auth/me` | `requireAuth` | Fetch refreshed session user profile | `200 OK` `{ user }` *(Complete camelCase user object)* |

### 11.2 Product Catalog (`/api/products`)
| Method | Path | Auth / Role | Description | Success Response |
|---|---|---|---|---|
| `GET` | `/api/products` | Public | Query verified equipment catalog | `200 OK` `[ { id, name, price, stock, category, vendorName, listingType } ]` |
| `GET` | `/api/products/mine` | `distributor`, `blockIfTerminated` | Fetch distributor's own equipment listings | `200 OK` `[ { ... } ]` |
| `GET` | `/api/products/:id` | Public | Fetch product specifications | `200 OK` `{ product }` |
| `POST` | `/api/products` | `distributor`, `blockIfTerminated` | Create new equipment listing | `201 Created` `{ product }` |
| `PUT` | `/api/products/:id` | `distributor`, `blockIfTerminated` | Update equipment listing | `200 OK` `{ product }` |
| `DELETE`| `/api/products/:id` | `distributor`, `blockIfTerminated` | Remove equipment listing | `200 OK` `{ message: "Product deleted." }` |

### 11.3 Shopping Cart (`/api/cart`)
| Method | Path | Auth / Role | Description | Error Conditions |
|---|---|---|---|---|
| `GET` | `/api/cart` | `healthcare_consumer` | Fetch user's cart items | `401 Unauthorized` |
| `POST` | `/api/cart` | `healthcare_consumer` | Add `buy_now` item to cart | `400 Bad Request` if `listing_type !== 'buy_now'` or `stock < qty` |
| `PUT` | `/api/cart/:itemId` | `healthcare_consumer` | Update item quantity | `400 Bad Request` if requested qty exceeds stock |
| `DELETE`| `/api/cart/:itemId` | `healthcare_consumer` | Remove item from cart | `404 Not Found` |

### 11.4 Orders & Checkout (`/api/orders`)
| Method | Path | Auth / Role | Description |
|---|---|---|---|
| `POST` | `/api/orders/checkout` | `healthcare_consumer` | Validate stock, create pending order, return Stripe Checkout URL |
| `GET` | `/api/orders/mine` | `healthcare_consumer` | List consumer order history |
| `GET` | `/api/orders/:id` | `requireAuth` | Fetch order details and line items (gated by ownership) |
| `POST` | `/api/orders/webhook` | Stripe Raw Payload | Verify Stripe signature, deduct stock atomically, mark order `'paid'` |

### 11.5 Quote Requests & Unlock Fees (`/api/quotes`)
| Method | Path | Auth / Role | Description |
|---|---|---|---|
| `POST` | `/api/quotes` | `healthcare_consumer` | Submit RFQ for `quote_request` product |
| `POST` | `/api/quotes/:id/pay` | `healthcare_consumer` | Initialize Stripe Checkout session for $25 unlock fee |
| `GET` | `/api/quotes/mine` | `healthcare_consumer` | View sent quote requests with payment/contact unlock status |
| `GET` | `/api/quotes/received` | `distributor`, `blockIfTerminated` | View received RFQs (Buyer contact masked until fee paid) |
| `GET` | `/api/quotes/:id` | `requireAuth` | Fetch quote details (Contact info protected by payment check) |

### 11.6 Distributor Verification & Administration (`/api/admin`, `/api/distributors`)
| Method | Path | Auth / Role | Description |
|---|---|---|---|
| `GET` | `/api/distributors/verification-status` | `distributor`, `blockIfTerminated` | Fetch distributor's KYC status and rejection notes |
| `POST` | `/api/distributors/verification` | `distributor`, `blockIfTerminated` | Re-submit rejected compliance documents |
| `GET` | `/api/admin/distributors/pending` | `admin` | Fetch pending applications with decrypted NINs |
| `GET` | `/api/admin/distributors` | `admin` | Fetch all active and reviewed distributors |
| `GET` | `/api/admin/distributors/:id/document` | `admin` | Stream binary KYC document via `StorageService` |
| `POST` | `/api/admin/distributors/:id/approve` | `admin` | Approve distributor (Requires `is_verified === TRUE`) |
| `POST` | `/api/admin/distributors/:id/reject` | `admin` | Reject application with required inline reason |
| `POST` | `/api/admin/distributors/:id/terminate`| `admin` | Terminate active account with reason; revoke privileges |

---

## 12. Authentication and Authorization Specification

### 12.1 Token Standard & Expiration
- Tokens generated with `jsonwebtoken.sign(payload, JWT_SECRET, { expiresIn: '7d' })`.
- Payload structure: `{ id: user.id, email: user.email, role: user.role }`.
- Transported via HTTP header: `Authorization: Bearer <token>`.

### 12.2 Real-Time Revocation via `blockIfTerminated`
Because JWTs are stateless, any token issued prior to account termination remains cryptographically valid. To ensure zero-latency revocation of rogue or terminated vendors:
```javascript
// src/middleware/authMiddleware.js
async function blockIfTerminated(req, res, next) {
  try {
    const result = await pool.query("SELECT account_status, terminated_reason FROM users WHERE id = $1", [req.user.id]);
    if (result.rows.length === 0 || result.rows[0].account_status === "terminated") {
      return res.status(403).json({
        error: "Your distributor account has been terminated.",
        reason: result.rows[0]?.terminated_reason || "Violation of MedProcure Operating Terms."
      });
    }
    next();
  } catch (err) {
    next(err);
  }
}
```
This middleware is attached to all distributor-scoped routes, including catalog mutations, received quotes, and verification status checks.

---

## 13. KYC and Identity-Document Handling Specification

### 13.1 NIN Cryptographic Invariant
- **Input Validation:** Enforces 11 decimal digits: `/^\d{11}$/`.
- **One-Way Blind Index:**
  $$\text{nin\_hash} = \text{SHA-256}(\text{nin})$$
  Evaluated against unique index `idx_users_nin_hash`. Prevents duplicate identity creation across separate accounts.
- **Reversible Symmetric Encryption:**
  $$\text{nin\_encrypted} = \text{AES-256-GCM}(\text{key}=\text{ENCRYPTION\_KEY}, \text{iv}=\text{crypto.randomBytes}(12), \text{plaintext}=\text{nin})$$
  Serialized as `${iv_hex}:${authTag_hex}:${ciphertext_hex}`. Decrypted exclusively by admins in `adminController.getPendingDistributors`.

### 13.2 Three-Document KYC Upload Pipeline
During distributor registration, Multer intercepts three distinct multipart fields:
1. `idPhoto`: Government photo ID (driver's license, international passport, or voter card) or live selfie.
2. `licenseDocument`: CAC certificate or medical device distribution license.
3. `proofOfAddress`: Utility bill or certified bank statement ($\le 3$ months old).

**Validation Enforcements:**
- File size $\le 5$ MB per document.
- Extension check: `.pdf`, `.jpg`, `.jpeg`, `.png`.
- MIME type check: `application/pdf`, `image/jpeg`, `image/png`.
- Stored on disk with unguessable random names: `dist_${prefix}_${crypto.randomBytes(10).toString("hex")}.${ext}`.

---

## 14. Security Requirements & Threat Modeling

### 14.1 Threat Modeling & Countermeasures

| Threat Actor / Vector | Target Component | Identified Risk | Engineered Countermeasure |
|---|---|---|---|
| **Malicious Vendor** | Product Catalog | Inject malicious `<script>` tags into product names or descriptions (Stored XSS) | Mandatory client-side `escapeHtml()` on all dynamic DOM injections; backend input sanitization. |
| **Banned Distributor** | Platform APIs | Continue selling after administrative termination using cached JWT | `blockIfTerminated` real-time database lookup on every sensitive operation. |
| **Rogue Buyer** | Cart / Checkout | Add high-value quote-only equipment to cart to bypass $25 fee | `cartController.addToCart` strictly rejects products where `listing_type !== 'buy_now'`. |
| **Rogue Competitor** | Received Quotes | Harvest buyer lead contact info without paying platform unlock fee | Mask consumer `fullName`, `email`, and `phone` on backend until `quote_requests.status === 'unlocked'`. |
| **Financial Replay** | Stripe Webhook | Resend `checkout.session.completed` event to double-decrement inventory | Check `order.status !== 'paid'` inside row-locked transaction (`FOR UPDATE`). |
| **Credential Scraper** | Repository | Access production mail servers via committed credentials | Scrub `.env.example`, enforce `.gitignore` for `.env`, rotate leaked Google App Passwords. |

---

## 15. End-to-End Data Flows

### 15.1 Flow 1: Distributor Registration & Approval Workflow

```mermaid
sequenceDiagram
    autonumber
    actor Dist as Medical Distributor
    participant Browser as Frontend (register.html)
    participant AuthAPI as Backend (authController)
    participant Mail as Email Service (Nodemailer)
    participant DB as PostgreSQL
    actor Admin as Platform Administrator
    participant AdminUI as Admin Dashboard

    Dist->>Browser: Enters business info, NIN, uploads 3 docs, accepts Terms
    Browser->>AuthAPI: POST /api/auth/register (multipart/form-data)
    AuthAPI->>AuthAPI: Validate NIN (11 digits), hash SHA-256, encrypt AES-GCM
    AuthAPI->>DB: INSERT INTO users (role='distributor', verification_status='pending', is_verified=FALSE)
    AuthAPI->>Mail: Send distributor verification email with secure token
    AuthAPI-->>Browser: 201 Created { token, user: { id, fullName, role, ... } }
    Browser->>Browser: Render 3-step timeline (Thank you panel); prompt email verification

    Dist->>Browser: Opens verification email link (/verify-email.html?token=...)
    Browser->>AuthAPI: GET /api/auth/verify-email?token=...
    AuthAPI->>DB: UPDATE users SET is_verified=TRUE WHERE token=...
    AuthAPI-->>Browser: 200 OK (Email Verified)

    Admin->>AdminUI: Opens Admin Verification Center
    AdminUI->>AuthAPI: GET /api/admin/distributors/pending
    AuthAPI->>DB: SELECT * FROM users WHERE verification_status='pending'
    AuthAPI->>AuthAPI: Decrypt NIN using ENCRYPTION_KEY
    AuthAPI-->>AdminUI: 200 OK [ pending distributors with decrypted NIN ]
    Admin->>AdminUI: Clicks "View Document"
    AdminUI->>AuthAPI: GET /api/admin/distributors/:id/document?type=licenseDocument
    AuthAPI-->>AdminUI: Binary file stream
    Admin->>AdminUI: Clicks "Approve Distributor"
    AdminUI->>AuthAPI: POST /api/admin/distributors/:id/approve
    AuthAPI->>DB: UPDATE users SET verification_status='approved', account_status='active'
    AuthAPI->>Mail: Send approval confirmation email
    AuthAPI-->>AdminUI: 200 OK
```

### 15.2 Flow 2: Buy Now Checkout & Webhook Handling

```mermaid
sequenceDiagram
    autonumber
    actor Consumer as Healthcare Consumer
    participant CartUI as Cart (cart.html)
    participant OrderAPI as Backend (orderController)
    participant Stripe as Stripe Gateway
    participant DB as PostgreSQL

    Consumer->>CartUI: Clicks "Proceed to Checkout"
    CartUI->>OrderAPI: POST /api/orders/checkout
    OrderAPI->>DB: Validate stock for all cart items
    OrderAPI->>DB: INSERT INTO orders (status='pending'), INSERT INTO order_items
    OrderAPI->>Stripe: stripe.checkout.sessions.create({ line_items, metadata: { order_id } })
    Stripe-->>OrderAPI: { url: checkout_url, id: session_id }
    OrderAPI-->>CartUI: 200 OK { url: checkout_url }
    CartUI->>Stripe: Redirects consumer to Stripe Checkout

    Consumer->>Stripe: Completes credit card payment
    Stripe->>Consumer: Redirects to /checkout-success.html?session_id=...
    Stripe->>OrderAPI: POST /api/orders/webhook (checkout.session.completed)
    OrderAPI->>OrderAPI: stripe.webhooks.constructEvent(rawBody, signature)
    OrderAPI->>DB: BEGIN TRANSACTION
    OrderAPI->>DB: SELECT status FROM orders WHERE id=$1 FOR UPDATE
    alt Order already marked 'paid'
        OrderAPI->>DB: ROLLBACK (Bail out idempotently)
    else Order is pending
        OrderAPI->>DB: UPDATE orders SET status='paid'
        OrderAPI->>DB: UPDATE products SET stock = stock - qty WHERE id=$1
        OrderAPI->>DB: DELETE FROM cart_items WHERE user_id=$1
        OrderAPI->>DB: COMMIT TRANSACTION
    end
    OrderAPI-->>Stripe: 200 OK { received: true }
```

### 15.3 Flow 3: Request for Quote & Contact Unlock

```mermaid
sequenceDiagram
    autonumber
    actor Consumer as Healthcare Consumer
    participant DetailsUI as Product Details
    participant QuoteAPI as Backend (quoteController)
    participant DistUI as Distributor Dashboard
    participant Stripe as Stripe Gateway
    participant DB as PostgreSQL

    Consumer->>DetailsUI: Submits RFQ (quantity, timeframe, facility address)
    DetailsUI->>QuoteAPI: POST /api/quotes
    QuoteAPI->>DB: INSERT INTO quote_requests (status='pending_payment')
    QuoteAPI-->>DetailsUI: 201 Created { quoteRequestId }
    DetailsUI->>Consumer: Prompts $25 unlock fee payment

    DistUI->>QuoteAPI: GET /api/quotes/received
    QuoteAPI->>DB: SELECT * FROM quote_requests WHERE distributor_id=$1
    QuoteAPI->>QuoteAPI: Redact buyer name, email, phone (status is pending_payment)
    QuoteAPI-->>DistUI: 200 OK [ quotes with buyer contact [LOCKED] ]

    Consumer->>QuoteAPI: POST /api/quotes/:id/pay
    QuoteAPI->>Stripe: stripe.checkout.sessions.create(mode='payment', fee=$25.00)
    Stripe-->>QuoteAPI: { url: session_url }
    QuoteAPI-->>Consumer: Redirect to Stripe

    Consumer->>Stripe: Pays $25 unlock fee
    Stripe->>QuoteAPI: POST /api/orders/webhook (type: 'quote_fee')
    QuoteAPI->>DB: UPDATE quote_requests SET status='unlocked', fee_paid_at=NOW()
    QuoteAPI-->>Stripe: 200 OK

    DistUI->>QuoteAPI: GET /api/quotes/received
    QuoteAPI-->>DistUI: 200 OK [ quotes with full consumer contact details UNLOCKED ]
```

---

## 16. Error, Loading, Empty, and Success UI States

Every user interface in the MedProcure client must implement explicit handling for the four canonical UI states:

| Screen / Flow | Loading State | Empty State | Error State | Success State |
|---|---|---|---|---|
| **Product Catalog (`products.html`)** | 8 animated skeleton cards with pulse shimmer. | "No medical equipment matches your search." Includes button to reset filters. | Persistent error banner with "Retry Catalog Load" button. | Responsive grid of verified equipment cards with badges and actions. |
| **Cart (`cart.html`)** | Spinner overlay with "Retrieving cart items...". | "Your cart is currently empty." Includes "Explore Medical Equipment" CTA. | Inline error banner displaying stock collision or API failure. | Itemized table, order subtotal, and active "Proceed to Checkout" button. |
| **Distributor Onboarding (`register.html`)** | Submit button disabled with spinning indicator: `"Uploading Documents & Registering..."`. | N/A (Form input mode). | Top-aligned alert box with specific validation errors (e.g. `"NIN must be 11 digits"`). | Clean switch to `#success-panel` rendering 3-step timeline and email verification prompt. |
| **Unified Dashboard (`dashboard.html`)** | Centered loader with `"Loading your MedProcure dashboard..."`. | "No recent activity recorded." Shows quick action cards. | Alert banner with sign-out and retry options. | Role-customized statistics, pending review notices, and recent order/quote tables. |
| **Admin Console (`admin-dashboard.html`)** | Table shimmer placeholders. | "All distributor applications reviewed. ✅ No pending items." | Sticky top banner with API error description. | Review cards with full NIN, 3 secure document viewer buttons, and approve/reject actions. |
| **Received Quotes (`received-quotes.html`)** | Skeleton cards loading inbound inquiries. | "No quote inquiries received yet." Tips for optimizing listings. | Alert box with reload action. | Inbound RFQ cards displaying equipment specs and masked or unlocked contact cards. |

---

## 17. Testing Requirements & Strategy

To remediate the current 0% test coverage, an automated test harness utilizing **Jest** and **Supertest** will be instituted under `backend/tests/`:

```
backend/
├── tests/
│   ├── setup.js                      # Test environment configuration & DB mock/cleanup
│   ├── unit/
│   │   ├── encryption.test.js        # AES-256-GCM and SHA-256 cryptographic tests
│   │   ├── storageService.test.js    # Local storage abstraction & traversal defense tests
│   │   └── validation.test.js        # Email, password, NIN, and stock constraint tests
│   └── integration/
│       ├── auth.test.js              # Consumer & distributor registration, token, lockout
│       ├── kyc.test.js               # Admin approval, document streaming, NIN decryption
│       ├── catalog.test.js           # Active vendor visibility filter tests
│       ├── cart.test.js              # Buy-now restriction & quantity limits
│       └── webhook.test.js           # Stripe webhook idempotency & stock deduction
```

### 17.1 Test Automation Invariants
1. **Zero Production Data in Tests:** All tests run against a dedicated test database or mocked connection pool.
2. **Deterministic Cryptographic Verification:** Unit tests verify that encrypted NINs can be decrypted with the valid key, fail decryption with invalid tags/keys, and produce consistent SHA-256 hashes.
3. **Idempotency Verification:** Integration tests simulate repeated Stripe webhook calls for the same session ID, confirming that product stock decrements exactly once.
4. **Execution Requirement:** In strict adherence to pipeline rules, no test will be reported as PASSED until actually executed in the environment.

---

## 18. Deployment & DevOps Requirements

### 18.1 Infrastructure Specifications
- **Database Engine:** PostgreSQL 16 Alpine running in a Docker container (`medprocure_postgres`), exposing port `5432` with volume persistence.
- **Backend Application:** Node.js 20 Alpine container exposing port `5000`. Configured via environment variables with health check endpoint at `GET /api/health`.
- **Frontend Delivery:** Static assets served through local static web runners (e.g. VS Code Live Server, Python `http.server`, or an optional Express static fallback) pointing to `frontend/`.

### 18.2 Sanitized Configuration Template (`backend/.env.example`)
All compromised credentials will be purged and replaced with standard placeholders:
```bash
# Server Configuration
PORT=5000
NODE_ENV=development
CLIENT_URL=http://127.0.0.1:5500

# PostgreSQL Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=medprocure
DB_USER=postgres
DB_PASSWORD=your_secure_db_password

# Authentication & Cryptography
JWT_SECRET=generate_with_node_crypto_randomBytes_64_hex
JWT_EXPIRES_IN=7d
ENCRYPTION_KEY=generate_with_node_crypto_randomBytes_32_hex

# Stripe Payment Gateway
STRIPE_SECRET_KEY=sk_test_placeholder
STRIPE_WEBHOOK_SECRET=whsec_placeholder

# Nodemailer SMTP Gateway (Mailtrap / Custom SMTP)
# NOTE: Do NOT commit real credentials to version control
SMTP_HOST=sandbox.smtp.mailtrap.io
SMTP_PORT=2525
SMTP_USER=your_smtp_username
SMTP_PASS=your_smtp_password
SMTP_FROM="MedProcure Platform <no-reply@medprocure.com>"

# Default Seed Administrator
ADMIN_EMAIL=admin@medprocure.com
ADMIN_PASSWORD=your_initial_admin_password
```

---

## 19. Dependencies & Tech Stack

### 19.1 Backend Dependencies
- **Core Runtime:** Node.js $\ge 20.x$, Express `4.19.2`
- **Database Driver:** `pg` `8.11.5`
- **Security & Crypto:** `bcryptjs` `2.4.3`, `jsonwebtoken` `9.0.2`, `helmet` `7.1.0`, `express-rate-limit` `7.4.0`, Node native `crypto`
- **Payment & Communication:** `stripe` `16.0.0`, `nodemailer` `6.9.14`
- **File Ingestion:** `multer` `1.4.5-lts.1`
- **New Test Harness Dependencies (Dev):** `jest` `^29.7.0`, `supertest` `^7.0.0`

### 19.2 Frontend Runtime
- Zero-dependency Vanilla HTML5, CSS3, and ES6 modules running natively in modern web browsers (Chrome, Edge, Firefox, Safari).

---

## 20. Risk Assessment & Mitigation Strategies

| Risk | Likelihood | Impact | Mitigation Strategy |
|---|:---:|:---:|---|
| **Compromised Credentials Abuse** | High | Critical | Immediately scrub `.env.example`, instruct user to revoke the leaked Google App Password, and audit mail server activity. |
| **Unverified Vendor Fraud** | High | Critical | Enforce SQL inner joins filtering for `verification_status = 'approved'` and `account_status = 'active'` across all product search and retrieval queries. |
| **Inventory Over-Allocation** | Medium | High | Wrap webhook processing in `BEGIN ... COMMIT` with `SELECT ... FOR UPDATE` row locks; reject checkouts exceeding current stock. |
| **KYC File Loss / Corruption** | Medium | Medium | Implement `StorageService` abstraction isolating disk access; prepare automated path and permission validation. |
| **Breaking Existing Migrations** | Low | High | Introduce `schema_migrations` tracking table so previous migrations are recognized as applied and never re-executed destructively. |

---

## 21. Implementation Boundaries

### What Will Be Done
- Implementation will modify the existing MedProcure project **in place**.
- Add email verification token generation and email dispatch for distributors.
- Fix user contract discrepancies between backend responses and frontend models.
- Implement `StorageService` abstraction for verification document handling.
- Enforce active vendor status across catalog and details queries.
- Block quote-only items from entering the shopping cart.
- Mask buyer contact details on received quotes until unlock fees are confirmed paid.
- Ensure Stripe webhook idempotency and transactional stock updates.
- Introduce `schema_migrations` version tracking in `runMigrations.js`.
- Sanitize `backend/.env.example` and remove all sensitive credentials.
- Add an automated test suite (Jest + Supertest) covering critical user journeys.
- Fix dead navigation links in footers and add responsive polish.

### What Will NOT Be Done
- No duplicate application will be created in `app_build/`.
- No replacement of the existing Express, Vanilla JS, or PostgreSQL technology stack.
- No direct connection to the live Nigerian NIMC database (remains simulated with valid format and encryption).
- No destruction of existing database records or unapproved schema drops.

---

## 22. Detailed Acceptance Criteria

### AC-1: Distributor Onboarding & Verification
- [ ] Distributor registration accepts legal business details, 11-digit NIN, 3 valid files (`idPhoto`, `licenseDocument`, `proofOfAddress`), and compulsory Terms checkbox.
- [ ] NIN is encrypted with AES-256-GCM and indexed with SHA-256; duplicate NIN registration is blocked with a 409 conflict error.
- [ ] Registration response does NOT contain the email verification token in JSON.
- [ ] Post-registration panel displays the 3-step visual timeline and explains email verification clearly.
- [ ] Visiting `/verify-email.html?token=...` marks `is_verified = TRUE`.
- [ ] Admin approval is blocked with HTTP 400 if `is_verified` is false.
- [ ] When approved, distributor receives an email, their dashboard unlocks product creation, and their listings become visible in the public catalog.

### AC-2: Catalog & Cart Integrity
- [ ] Products from unapproved, rejected, or terminated distributors NEVER appear in `GET /api/products` or category statistics.
- [ ] Attempting to add a product with `listing_type = 'quote_request'` to the cart returns HTTP 400 with a descriptive error.
- [ ] Cart prevents adding quantities exceeding available stock.

### AC-3: Quote Request & Contact Shielding
- [ ] RFQs for `quote_request` equipment are created in `pending_payment` status.
- [ ] In `received-quotes.html`, buyer full name, email, and phone are masked as `[Locked - Requires Payment]` while status is `pending_payment`.
- [ ] Paying the $25 fee via Stripe unlocks the contact details on both consumer and distributor views.

### AC-4: Payment & Concurrency Safety
- [ ] Duplicate Stripe webhook events do not double-decrement inventory.
- [ ] Order fulfillment operations execute within a database transaction; partial failures roll back cleanly.

### AC-5: Security & Platform Health
- [ ] `backend/.env.example` contains only sanitized placeholder values.
- [ ] 5 consecutive invalid login attempts locks the target account for 15 minutes.
- [ ] Verification documents cannot be accessed via public static URLs; streaming requires valid admin authentication.
- [ ] `npm run migrate` runs each migration script exactly once, tracked in `schema_migrations`.
- [ ] Automated tests run via `npm test` and execute without errors.
- [ ] All footer navigation links point to valid resources or dialogs.

---

## 23. Conclusion & Human Approval Gate

This technical specification completely defines the target architecture, security model, and engineering requirements for the MedProcure marketplace.

In accordance with the MedProcure Autonomous Pipeline rules:
**Implementation will not begin until this specification is explicitly approved by the human supervisor.**
