# Phase 7: Premium Approval Flow, Proof of Address, Terms & Termination

## What's new

1. **"Thank you" pending-review screen** — after a Distributor submits registration, they now see
   a proper confirmation screen ("Thank you for choosing MedProcure! We will review and verify
   your credentials for authenticity...") with a 3-step visual timeline (Documents received →
   Under review → Decision & email notification), not just a plain success message.

2. **Proof of address is now required** at signup, alongside the ID photo and business license —
   three documents total.

3. **Distributor Terms & Policy of Operation** (`terms.html`) — a real policy page covering
   accuracy of information, listing standards, prohibited conduct, and — critically — a clear
   termination clause. Distributors must check a box confirming they've read and agree before
   they can submit registration.

4. **Premium admin review interface** (`admin-dashboard.html`) — completely redesigned:
   - **Pending Review tab**: each distributor is a rich card showing their full name, business
     name, email, phone, **full unmasked NIN** (admins need the real number to actually verify it
     against the ID photo — it's still encrypted in the database, only decrypted for this view),
     license number, date of birth, and address — plus three separate "View" buttons for the ID
     photo, business license, and proof of address, each opening securely.
   - Declining now uses an inline reason box (not a browser `prompt()`), and that reason is
     emailed to the distributor.
   - **Active Distributors tab**: every approved distributor, with a **Terminate Account** button
     for policy violations — requires a reason, which is emailed to them, and immediately blocks
     their login and all seller actions (even if their login session was still technically valid).

5. **Email notifications** — approval, rejection, and termination all trigger an email to the
   distributor. Since no real email inbox is configured yet, **emails are logged to your backend
   console** by default so you can see exactly what would be sent. To send real emails, add SMTP
   credentials to `.env` (instructions below).

## Setup

### 1. Run the new migration
```
cd backend
npm install
npm run migrate
```

### 2. (Optional but recommended) Set up real email sending
Without this, emails just print to your console — functionally fine for testing, but you won't
get a real inbox notification.

**Easiest free option for testing: Mailtrap.io** (a sandbox inbox, no real emails sent to real
people while you develop):
1. Sign up at mailtrap.io, create an inbox, copy its SMTP credentials
2. In `backend/.env`:
   ```
   SMTP_HOST=sandbox.smtp.mailtrap.io
   SMTP_PORT=2525
   SMTP_USER=<your mailtrap username>
   SMTP_PASS=<your mailtrap password>
   ```

**For real Gmail sending:**
1. Turn on 2-Step Verification on your Google account
2. Create an "App Password" at https://myaccount.google.com/apppasswords
3. In `.env`:
   ```
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USER=youremail@gmail.com
   SMTP_PASS=<the 16-character app password>
   ```

### 3. Restart your backend
```
npm run dev
```

## Testing it end to end

1. Register a new Distributor — fill everything including the new proof-of-address upload, and
   check the Terms agreement box (try leaving it unchecked first — you'll get a clear error)
2. You'll land on the new "Thank you for choosing MedProcure!" screen with the review timeline
3. Log in as admin → **Distributor Verification Center** → **Pending Review** tab — you'll see the
   full NIN, all three document buttons, and the new inline decline flow
4. Approve or decline — check your backend console (or your real inbox if you set up SMTP) for
   the notification email
5. Go to the **Active Distributors** tab, find your approved distributor, click **Terminate
   Account**, give a reason — the distributor will now be blocked from logging in, and receives
   a termination email
