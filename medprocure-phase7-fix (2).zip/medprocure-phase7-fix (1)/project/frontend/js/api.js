// api.js — the only file that talks directly to the backend.
import { API_BASE_URL } from "./config.js";

async function request(path, options = {}) {
  const { headers: customHeaders, ...restOptions } = options;
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...restOptions,
    headers: { "Content-Type": "application/json", ...(customHeaders || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data;
}

// --- Auth ---
export function registerUser({ fullName, email, password, phone }) {
  return request("/auth/register", {
    method: "POST",
    body: JSON.stringify({ fullName, email, password, phone, role: "healthcare_consumer" }),
  });
}

// Distributor registration is multipart/form-data (two files: license doc + ID photo),
// so it bypasses the JSON request() helper — the browser sets its own Content-Type boundary.
export async function registerDistributor(formData) {
  const response = await fetch(`${API_BASE_URL}/auth/register`, { method: "POST", body: formData });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data;
}

export function verifyEmail(token) {
  return request(`/auth/verify-email?token=${encodeURIComponent(token)}`, { method: "GET" });
}

export function loginUser({ email, password }) {
  return request("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
}

export function getCurrentUser(token) {
  return request("/auth/me", { method: "GET", headers: { Authorization: `Bearer ${token}` } });
}

// --- Products ---
export function getProducts({ search, category } = {}) {
  const params = new URLSearchParams();
  if (search) params.set("search", search);
  if (category) params.set("category", category);
  const query = params.toString() ? `?${params.toString()}` : "";
  return request(`/products${query}`, { method: "GET" });
}
export function getProductById(id) { return request(`/products/${id}`, { method: "GET" }); }
export function getMyProducts(token) { return request("/products/mine", { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }
export function createProduct(token, product) {
  return request("/products", { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: JSON.stringify(product) });
}
export function updateProduct(token, id, product) {
  return request(`/products/${id}`, { method: "PUT", headers: { Authorization: `Bearer ${token}` }, body: JSON.stringify(product) });
}
export function deleteProduct(token, id) {
  return request(`/products/${id}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
}

// --- Cart ---
export function getCart(token) { return request("/cart", { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }
export function addToCart(token, productId, quantity = 1) {
  return request("/cart", { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: JSON.stringify({ productId, quantity }) });
}
export function updateCartItem(token, itemId, quantity) {
  return request(`/cart/${itemId}`, { method: "PUT", headers: { Authorization: `Bearer ${token}` }, body: JSON.stringify({ quantity }) });
}
export function removeCartItem(token, itemId) {
  return request(`/cart/${itemId}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
}

// --- Orders ---
export function startCheckout(token) { return request("/orders/checkout", { method: "POST", headers: { Authorization: `Bearer ${token}` } }); }
export function getOrderById(token, orderId) { return request(`/orders/${orderId}`, { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }
export function getMyOrders(token) { return request("/orders/mine", { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }

// --- Distributor verification ---
export function getVerificationStatus(token) {
  return request("/distributors/verification-status", { method: "GET", headers: { Authorization: `Bearer ${token}` } });
}
export async function submitVerificationDocument(token, file) {
  const formData = new FormData();
  formData.append("licenseDocument", file);
  const response = await fetch(`${API_BASE_URL}/distributors/verification`, {
    method: "POST", headers: { Authorization: `Bearer ${token}` }, body: formData,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Could not submit document.");
  return data;
}

// --- Admin ---
export function getPendingDistributors(token) { return request("/admin/distributors/pending", { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }
export function getAllDistributors(token) { return request("/admin/distributors", { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }
export function approveDistributor(token, id) { return request(`/admin/distributors/${id}/approve`, { method: "POST", headers: { Authorization: `Bearer ${token}` } }); }
export function rejectDistributor(token, id, reason) {
  return request(`/admin/distributors/${id}/reject`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: JSON.stringify({ reason }) });
}
export function terminateDistributor(token, id, reason) {
  return request(`/admin/distributors/${id}/terminate`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: JSON.stringify({ reason }) });
}
// Fetches a sensitive verification document as a protected blob (never a public URL) and
// opens it in a new tab — only works for a logged-in admin, enforced by the backend.
export async function viewDistributorDocument(token, distributorId, type) {
  const response = await fetch(`${API_BASE_URL}/admin/distributors/${distributorId}/document?type=${type}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || "Could not load document.");
  }
  const blob = await response.blob();
  const blobUrl = URL.createObjectURL(blob);
  window.open(blobUrl, "_blank", "noopener");
}

// --- Public stats ---
export function getPublicStats() { return request("/stats/public", { method: "GET" }); }
export function getCategoryInsights() { return request("/stats/categories", { method: "GET" }); }
export function getDashboardSummary(token) { return request("/stats/dashboard-summary", { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }

// --- Quote requests ---
export function createQuoteRequest(token, productId) {
  return request("/quotes", { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: JSON.stringify({ productId }) });
}
export function payQuoteFee(token, quoteId) { return request(`/quotes/${quoteId}/pay`, { method: "POST", headers: { Authorization: `Bearer ${token}` } }); }
export function getMyQuoteRequests(token) { return request("/quotes/mine", { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }
export function getQuoteRequestById(token, id) { return request(`/quotes/${id}`, { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }
export function getReceivedQuoteRequests(token) { return request("/quotes/received", { method: "GET", headers: { Authorization: `Bearer ${token}` } }); }
