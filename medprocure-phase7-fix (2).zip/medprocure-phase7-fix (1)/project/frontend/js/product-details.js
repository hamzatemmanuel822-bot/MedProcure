// product-details.js
import { getProductById, addToCart, createQuoteRequest } from "./api.js";
import { getToken, getUser } from "./auth.js";
import { quantityStepperHTML, wireQuantityStepper } from "./components/quantityStepper.js";
import { renderFooter } from "./components/footer.js";
import { escapeHtml } from "./utils.js";

const container = document.getElementById("detail-grid");
const params = new URLSearchParams(window.location.search);
const id = params.get("id");
const token = getToken();
const user = getUser();
const canBuy = token && user && user.role === "healthcare_consumer";

async function loadProduct() {
  if (!id) {
    container.innerHTML = `<div class="empty-state">No product specified.</div>`;
    return;
  }
  try {
    const { product } = await getProductById(id);
    const isLow = product.stock > 0 && product.stock <= 5;
    const outOfStock = product.stock === 0;
    const isQuote = product.listing_type === "quote_request";
    const safeName = escapeHtml(product.name);
    const safeDesc = escapeHtml(product.description || "No description provided.");
    const safeVendor = escapeHtml(product.vendor_name);
    const safeCategory = escapeHtml(product.category);
    const safeImg = escapeHtml(product.image_url);

    container.innerHTML = `
      <div class="detail-image-box">
        ${product.image_url ? `<img src="${safeImg}" alt="${safeName}" />` : "No image available"}
      </div>
      <div class="detail-info">
        <span class="category-tag">${safeCategory}</span>
        ${isQuote ? ` &nbsp;<span class="badge badge-pending">Request Quote Listing</span>` : ""}
        <h1>${safeName}</h1>
        <div class="detail-vendor-line">Distributed by <strong>${safeVendor}</strong></div>
        <div class="detail-price-row">
          <span class="price">$${Number(product.price).toFixed(2)}</span>
          <span class="stock ${isLow || outOfStock ? "low" : ""}">
            ${outOfStock ? "Out of stock" : isLow ? `Only ${product.stock} left in stock` : `${product.stock} in stock`}
          </span>
        </div>
        <hr class="detail-divider" />
        <div class="detail-description"><h4>Description</h4><p>${safeDesc}</p></div>
        <div class="detail-meta">
          <dl class="detail-meta-list">
            <dt>Category</dt><dd>${safeCategory}</dd>
            <dt>Listing type</dt><dd>${isQuote ? "Request Quote" : "Buy Now"}</dd>
          </dl>
        </div>
        <div id="buy-box"></div>
      </div>
    `;
    renderBuyBox(product, { isQuote, outOfStock });
  } catch (err) {
    container.innerHTML = `<div class="empty-state">Could not load product: ${escapeHtml(err.message)}</div>`;
  }
}

function renderBuyBox(product, { isQuote, outOfStock }) {
  const buyBox = document.getElementById("buy-box");

  if (outOfStock) {
    buyBox.innerHTML = `<div class="detail-buy-box"><span class="badge badge-rejected">Out of Stock</span></div>`;
    return;
  }
  if (!canBuy) {
    buyBox.innerHTML = `<div class="detail-buy-box"><a href="login.html" class="btn-add-cart" style="text-decoration:none; display:flex;">Log in as a Healthcare Consumer to buy</a></div>`;
    return;
  }
  if (isQuote) {
    buyBox.innerHTML = `<div class="detail-buy-box"><button id="quote-btn" class="btn-add-cart"><span class="cart-icon">📩</span> Request Quote — $25 unlock fee to view contact</button></div>`;
    document.getElementById("quote-btn").addEventListener("click", async (e) => {
      const btn = e.currentTarget;
      const originalHTML = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = `<span class="cart-icon">⏳</span> Submitting request...`;
      try {
        await createQuoteRequest(token, product.id);
        btn.innerHTML = `<span class="cart-icon">✓</span> Requested — view it in My Quote Requests`;
        btn.classList.add("added");
      } catch (err) {
        alert(err.message);
        btn.innerHTML = originalHTML;
        btn.disabled = false;
      }
    });
    return;
  }

  const qtyId = "detail-qty";
  buyBox.innerHTML = `<div class="detail-buy-box"><div class="detail-buy-row">${quantityStepperHTML(qtyId, product.stock)}<button id="add-to-cart-btn" class="btn-add-cart"><span class="cart-icon">🛒</span> Add to Cart</button></div></div>`;
  wireQuantityStepper(buyBox);

  document.getElementById("add-to-cart-btn").addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    const quantity = Number(document.getElementById(qtyId).value) || 1;
    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="cart-icon">⏳</span> Adding...`;
    try {
      await addToCart(token, product.id, quantity);
      btn.innerHTML = `<span class="cart-icon">✓</span> Added to Cart`;
      btn.classList.add("added");
      setTimeout(() => { btn.innerHTML = originalHTML; btn.classList.remove("added"); btn.disabled = false; }, 1400);
    } catch (err) {
      alert(err.message);
      btn.innerHTML = originalHTML;
      btn.disabled = false;
    }
  });
}

renderFooter("footer-slot");
loadProduct();
