// quantityStepper.js
export function quantityStepperHTML(inputId, max) {
  const safeMax = max && max > 0 ? max : 1;
  return `
    <div class="qty-stepper" data-max="${safeMax}">
      <button type="button" class="qty-stepper-btn" data-step="-1" aria-label="Decrease quantity">−</button>
      <input type="number" id="${inputId}" class="qty-stepper-input" value="1" min="1" max="${safeMax}" />
      <button type="button" class="qty-stepper-btn" data-step="1" aria-label="Increase quantity">+</button>
    </div>
  `;
}

export function wireQuantityStepper(root) {
  const stepper = root.querySelector(".qty-stepper");
  if (!stepper) return;
  const input = stepper.querySelector(".qty-stepper-input");
  const max = Number(stepper.dataset.max) || 1;
  stepper.querySelectorAll(".qty-stepper-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const step = Number(btn.dataset.step);
      let value = Number(input.value) || 1;
      value = Math.min(max, Math.max(1, value + step));
      input.value = value;
    });
  });
  input.addEventListener("change", () => {
    let value = Number(input.value) || 1;
    value = Math.min(max, Math.max(1, value));
    input.value = value;
  });
}
