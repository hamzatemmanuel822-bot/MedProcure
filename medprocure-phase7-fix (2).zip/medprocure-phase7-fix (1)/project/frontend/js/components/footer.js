// footer.js
export function renderFooter(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const year = new Date().getFullYear();
  el.innerHTML = `
    <footer class="site-footer">
      <div class="footer-top">
        <div class="footer-col footer-brand">
          <div class="footer-logo">🛡️ MedProcure</div>
          <p>A verified marketplace connecting Healthcare Consumers with document-reviewed,
             identity-verified Distributors for medical equipment procurement.</p>
          <div class="footer-trust-row">
            <span class="footer-trust-badge">🔒 Secure Stripe Checkout</span>
            <span class="footer-trust-badge">🛡️ NIN-Verified Distributors</span>
          </div>
        </div>
        <div class="footer-col">
          <h4>Marketplace</h4>
          <a href="index.html">Home</a>
          <a href="products.html">Browse Products</a>
          <a href="cart.html">My Cart</a>
          <a href="register.html">Create an Account</a>
        </div>
        <div class="footer-col">
          <h4>For Distributors</h4>
          <a href="register.html">Become a Distributor</a>
          <a href="vendor-products.html">Manage Listings</a>
          <a href="received-quotes.html">Incoming Quote Requests</a>
        </div>
        <div class="footer-col">
          <h4>For Healthcare Consumers</h4>
          <a href="products.html">Browse Equipment</a>
          <a href="my-quotes.html">My Quote Requests</a>
          <a href="dashboard.html">My Dashboard</a>
        </div>
        <div class="footer-col">
          <h4>Company</h4>
          <a href="#">About Us</a>
          <a href="#">Contact Support</a>
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Service</a>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© ${year} MedProcure. All rights reserved.</span>
        <div class="footer-socials">
          <a href="#" aria-label="Email">✉️</a>
          <a href="#" aria-label="LinkedIn">in</a>
          <a href="#" aria-label="Twitter">𝕏</a>
        </div>
      </div>
    </footer>
  `;
}
