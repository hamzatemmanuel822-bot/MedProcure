// utils.js
// escapeHtml MUST wrap any user-supplied text (product names, business names, emails, etc.)
// before it's inserted into the page via innerHTML. Without this, a distributor could name
// a product "<img src=x onerror=alert(1)>" and it would execute as real code in every
// visitor's browser (a stored XSS attack) — this function turns it into harmless text instead.
export function escapeHtml(value) {
  if (value === null || value === undefined) return "";
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
