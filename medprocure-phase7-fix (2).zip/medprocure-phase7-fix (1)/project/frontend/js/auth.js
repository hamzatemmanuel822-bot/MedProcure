// auth.js
import { loginUser } from "./api.js";

const TOKEN_KEY = "medprocure_token";
const USER_KEY = "medprocure_user";

export function normalizeUser(raw) {
  if (!raw) return null;
  return {
    id: raw.id,
    fullName: raw.fullName || raw.full_name || "",
    email: raw.email || "",
    role: raw.role || "",
    phone: raw.phone || null,
    isVerified: raw.isVerified !== undefined ? raw.isVerified : !!raw.is_verified,
    verificationStatus: raw.verificationStatus || raw.verification_status || "not_applicable",
    accountStatus: raw.accountStatus || raw.account_status || "active",
    businessName: raw.businessName || raw.business_name || null,
    createdAt: raw.createdAt || raw.created_at,
  };
}

export function saveSession(token, user) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(normalizeUser(user)));
}

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function getUser() {
  const raw = localStorage.getItem(USER_KEY);
  return raw ? normalizeUser(JSON.parse(raw)) : null;
}

export function logout() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  window.location.href = "login.html";
}

function showAlert(el, message, type) {
  el.textContent = message;
  el.className = `alert show alert-${type}`;
}

const loginForm = document.getElementById("login-form");
if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const alertBox = document.getElementById("login-alert");
    const submitBtn = document.getElementById("login-submit");
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    submitBtn.disabled = true;
    submitBtn.textContent = "Logging in...";

    try {
      const data = await loginUser({ email, password });
      saveSession(data.token, data.user);
      showAlert(alertBox, "Login successful! Redirecting...", "success");

      // Smart role-based redirect
      const targetPage = data.user.role === "admin" ? "admin-dashboard.html" : "dashboard.html";
      setTimeout(() => (window.location.href = targetPage), 800);
    } catch (err) {
      showAlert(alertBox, err.message, "error");
      submitBtn.disabled = false;
      submitBtn.textContent = "Log In";
    }
  });
}
