// products.js
import { getProducts, addToCart, createQuoteRequest } from "./api.js";
import { getToken, getUser } from "./auth.js";
import { quantityStepperHTML, wireQuantityStepper } from "./components/quantityStepper.js";
import { renderFooter } from "./components/footer.js";
import { escapeHtml } from "./utils.js";

const grid = document.getElementById("product-grid");
const searchInput = document.getElementById("search-input");
const categorySelect = document.getElementById("category-select");

function renderSkeleton(count = 8) {
  grid.innerHTML = Array.from({ length: count }).map(() => `
    <div class="skeleton-card">
      <div class="skeleton-thumb"></div>
      <div class="skeleton-line"></div>
      <div class="skeleton-line short"></div>
      <div class="skeleton-line"></div>
    </div>
  `).join("");
}

function renderProducts(products) {
  const token = getToken();
  const user = getUser();
  const canBuy = token && user && user.role === "healthcare_consumer";

  if (!products.length) {
    grid.innerHTML = `<div class="empty-state">🔍 No products found. Try a different search or category.</div>`;
    return;
  }

  grid.innerHTML = products.map((p, i) => {
    const isLow = p.stock > 0 && p.stock <= 5;
    const outOfStock = p.stock === 0;
    const isQuote = p.listing_type === "quote_request";
    const qtyId = `qty-${p.id}`;
    const safeName = escapeHtml(p.name);
    const safeImg = escapeHtml(p.image_url);
    const safeCategory = escapeHtml(p.category);

    return `
      <div class="product-card" style="animation-delay:${Math.min(i * 40, 400)}ms">
        <a href="product-details.html?id=${encodeURIComponent(p.id)}" style="text-decoration:none; color:inherit;">
          <div class="thumb">${p.image_url ? `<img src="${safeImg}" alt="${safeName}" loading="lazy" />` : "No image"}</div>
          <div class="body">
            <span class="category-tag">${safeCategory}</span>
            <h3>${safeName}</h3>
            <span class="price">$${Number(p.price).toFixed(2)}</span>
            <span class="stock ${isLow || outOfStock ? "low" : ""}">
              ${outOfStock ? "Out of stock" : isLow ? `Only ${p.stock} left` : `${p.stock} in stock`}
            </span>
            ${isQuote ? `<span class="badge badge-pending" style="width:fit-content;">Request Quote</span>` : ""}
          </div>
        </a>
        ${canBuy && !outOfStock
          ? isQuote
            ? `<div class="card-actions" style="padding: 0 var(--space-md) var(--space-md);"><button class="btn-add-cart" data-quote="${p.id}"><span class="cart-icon">📩</span> Request Quote</button></div>`
            : `<div class="buy-row" style="padding: 0 var(--space-md) var(--space-md);">
                 ${quantityStepperHTML(qtyId, p.stock)}
                 <button class="btn-add-cart" data-add="${p.id}" data-qty-input="${qtyId}"><span class="cart-icon">🛒</span> Add</button>
               </div>`
          : ""}
      </div>
    `;
  }).join("");

  if (canBuy) {
    grid.querySelectorAll("[data-add]").forEach((btn) => {
      const card = btn.closest(".product-card");
      wireQuantityStepper(card);
      btn.addEventListener("click", async () => {
        const qtyInput = document.getElementById(btn.dataset.qtyInput);
        const quantity = Number(qtyInput.value) || 1;
        const originalHTML = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = `<span class="cart-icon">⏳</span> Adding...`;
        try {
          await addToCart(token, Number(btn.dataset.add), quantity);
          btn.innerHTML = `<span class="cart-icon">✓</span> Added`;
          btn.classList.add("added");
          setTimeout(() => { btn.innerHTML = originalHTML; btn.classList.remove("added"); btn.disabled = false; }, 1400);
        } catch (err) {
          alert(err.message);
          btn.innerHTML = originalHTML;
          btn.disabled = false;
        }
      });
    });

    grid.querySelectorAll("[data-quote]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const originalHTML = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = `<span class="cart-icon">⏳</span> Requesting...`;
        try {
          await createQuoteRequest(token, Number(btn.dataset.quote));
          btn.innerHTML = `<span class="cart-icon">✓</span> Requested`;
          btn.classList.add("added");
        } catch (err) {
          alert(err.message);
          btn.innerHTML = originalHTML;
          btn.disabled = false;
        }
      });
    });
  }
}

async function loadProducts() {
  renderSkeleton();
  try {
    const { products } = await getProducts({ search: searchInput.value.trim(), category: categorySelect.value });
    renderProducts(products);
  } catch (err) {
    grid.innerHTML = `<div class="empty-state">Could not load products: ${escapeHtml(err.message)}</div>`;
  }
}

let debounceTimer;
searchInput.addEventListener("input", () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(loadProducts, 350);
});
categorySelect.addEventListener("change", loadProducts);

renderFooter("footer-slot");
loadProducts();
