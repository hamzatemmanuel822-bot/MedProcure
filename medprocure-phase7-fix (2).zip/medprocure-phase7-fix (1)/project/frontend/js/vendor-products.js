// vendor-products.js
import { getToken, getUser, logout } from "./auth.js";
import { getMyProducts, createProduct, updateProduct, deleteProduct, getVerificationStatus } from "./api.js";
import { escapeHtml } from "./utils.js";

const token = getToken();
const user = getUser();
if (!token || !user || user.role !== "distributor") window.location.href = "login.html";

const listEl = document.getElementById("my-products-list");
const form = document.getElementById("product-form");
const formAlert = document.getElementById("form-alert");
const formTitle = document.getElementById("form-title");
const submitBtn = document.getElementById("submit-btn");
const cancelEditBtn = document.getElementById("cancel-edit-btn");
const gateBanner = document.getElementById("gate-banner");
const formCard = document.getElementById("form-card");

let editingId = null;

async function checkVerification() {
  try {
    const status = await getVerificationStatus(token);
    if (status.verification_status !== "approved") {
      formCard.style.display = "none";
      gateBanner.style.display = "block";
      gateBanner.innerHTML = status.verification_status === "pending"
        ? `<div class="security-banner pending"><span class="icon">⏳</span><span>Your Distributor account is pending admin review (identity and business documents). You'll be able to list products once approved. <a href="dashboard.html">Check status on your dashboard</a>.</span></div>`
        : `<div class="security-banner rejected"><span class="icon">⚠️</span><span>Your verification was not approved. Visit your dashboard for details.</span></div>`;
      return false;
    }
    return true;
  } catch (err) {
    return false;
  }
}

function showAlert(message, type) {
  formAlert.textContent = message;
  formAlert.className = `alert show alert-${type}`;
}

function resetForm() {
  form.reset();
  editingId = null;
  formTitle.textContent = "Add a new listing";
  submitBtn.textContent = "Add Listing";
  cancelEditBtn.style.display = "none";
}

function renderProducts(products) {
  if (!products.length) {
    listEl.innerHTML = `<div class="empty-state">You haven't listed any products yet.</div>`;
    return;
  }

  listEl.innerHTML = products.map((p) => `
    <div class="product-card">
      <div class="thumb">${p.image_url ? `<img src="${escapeHtml(p.image_url)}" alt="${escapeHtml(p.name)}" />` : "No image"}</div>
      <div class="body">
        <span class="category-tag">${escapeHtml(p.category)}</span>
        <h3>${escapeHtml(p.name)}</h3>
        <span class="price">$${Number(p.price).toFixed(2)}</span>
        <span class="stock">${p.stock} in stock</span>
        <span class="badge ${p.listing_type === "quote_request" ? "badge-pending" : "badge-verified"}" style="width:fit-content;">
          ${p.listing_type === "quote_request" ? "Request Quote" : "Buy Now"}
        </span>
        <div class="card-actions">
          <button class="btn-small" data-edit="${p.id}">Edit</button>
          <button class="btn-small danger" data-delete="${p.id}">Delete</button>
        </div>
      </div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const product = products.find((p) => p.id === Number(btn.dataset.edit));
      startEdit(product);
    });
  });
  listEl.querySelectorAll("[data-delete]").forEach((btn) => {
    btn.addEventListener("click", () => handleDelete(Number(btn.dataset.delete)));
  });
}

function startEdit(product) {
  editingId = product.id;
  document.getElementById("name").value = product.name;
  document.getElementById("description").value = product.description || "";
  document.getElementById("price").value = product.price;
  document.getElementById("stock").value = product.stock;
  document.getElementById("imageUrl").value = product.image_url || "";
  document.getElementById("category").value = product.category;
  document.getElementById("listingType").value = product.listing_type || "buy_now";
  formTitle.textContent = `Editing "${product.name}"`;
  submitBtn.textContent = "Save Changes";
  cancelEditBtn.style.display = "inline-block";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function loadMyProducts() {
  listEl.innerHTML = `<div class="empty-state">Loading your products...</div>`;
  try {
    const { products } = await getMyProducts(token);
    renderProducts(products);
  } catch (err) {
    listEl.innerHTML = `<div class="empty-state">Could not load your products: ${escapeHtml(err.message)}</div>`;
  }
}

async function handleDelete(id) {
  if (!confirm("Delete this product? This cannot be undone.")) return;
  try {
    await deleteProduct(token, id);
    loadMyProducts();
  } catch (err) {
    alert(`Could not delete: ${err.message}`);
  }
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    name: document.getElementById("name").value.trim(),
    description: document.getElementById("description").value.trim(),
    price: parseFloat(document.getElementById("price").value),
    stock: parseInt(document.getElementById("stock").value, 10) || 0,
    imageUrl: document.getElementById("imageUrl").value.trim(),
    category: document.getElementById("category").value,
    listingType: document.getElementById("listingType").value,
  };
  submitBtn.disabled = true;
  try {
    if (editingId) {
      await updateProduct(token, editingId, payload);
      showAlert("Product updated.", "success");
    } else {
      await createProduct(token, payload);
      showAlert("Product added.", "success");
    }
    resetForm();
    loadMyProducts();
  } catch (err) {
    showAlert(err.message, "error");
  } finally {
    submitBtn.disabled = false;
  }
});

cancelEditBtn.addEventListener("click", resetForm);
document.getElementById("logout-link").addEventListener("click", (e) => { e.preventDefault(); logout(); });

(async () => {
  const approved = await checkVerification();
  if (approved) loadMyProducts();
})();
