// cart.js
import { getToken, getUser } from "./auth.js";
import { getCart, updateCartItem, removeCartItem, startCheckout } from "./api.js";
import { escapeHtml } from "./utils.js";

const token = getToken();
const user = getUser();
if (!token || !user) window.location.href = "login.html";

const listEl = document.getElementById("cart-list");
const totalEl = document.getElementById("cart-total");
const checkoutBtn = document.getElementById("checkout-btn");
const checkoutAlert = document.getElementById("checkout-alert");

function renderCart(items, total) {
  totalEl.textContent = `$${total.toFixed(2)}`;
  checkoutBtn.disabled = items.length === 0;

  if (!items.length) {
    listEl.innerHTML = `<div class="empty-state">Your cart is empty. <a href="products.html">Browse products</a>.</div>`;
    return;
  }

  listEl.innerHTML = items.map((item) => `
    <div class="cart-row" data-item-id="${item.id}">
      <div class="thumb">${item.image_url ? `<img src="${escapeHtml(item.image_url)}" alt="${escapeHtml(item.name)}" />` : "No image"}</div>
      <div class="cart-row-body">
        <h3>${escapeHtml(item.name)}</h3>
        <span class="price">$${Number(item.price).toFixed(2)} each</span>
      </div>
      <div class="qty-control">
        <button class="qty-btn" data-action="decrease">−</button>
        <span class="qty-value">${item.quantity}</span>
        <button class="qty-btn" data-action="increase">+</button>
      </div>
      <div class="row-total">$${(Number(item.price) * item.quantity).toFixed(2)}</div>
      <button class="btn-small danger" data-action="remove">Remove</button>
    </div>
  `).join("");

  listEl.querySelectorAll(".cart-row").forEach((row) => {
    const itemId = row.dataset.itemId;
    const qtySpan = row.querySelector(".qty-value");
    row.querySelector('[data-action="increase"]').addEventListener("click", async () => {
      await updateCartItem(token, itemId, Number(qtySpan.textContent) + 1);
      loadCart();
    });
    row.querySelector('[data-action="decrease"]').addEventListener("click", async () => {
      const newQty = Number(qtySpan.textContent) - 1;
      if (newQty < 1) return;
      await updateCartItem(token, itemId, newQty);
      loadCart();
    });
    row.querySelector('[data-action="remove"]').addEventListener("click", async () => {
      await removeCartItem(token, itemId);
      loadCart();
    });
  });
}

async function loadCart() {
  try {
    const { items, total } = await getCart(token);
    renderCart(items, total);
  } catch (err) {
    listEl.innerHTML = `<div class="empty-state">Could not load your cart: ${escapeHtml(err.message)}</div>`;
  }
}

checkoutBtn.addEventListener("click", async () => {
  checkoutBtn.disabled = true;
  checkoutBtn.textContent = "Redirecting to secure checkout...";
  checkoutAlert.className = "alert";
  try {
    const { checkoutUrl } = await startCheckout(token);
    window.location.href = checkoutUrl;
  } catch (err) {
    checkoutAlert.textContent = err.message;
    checkoutAlert.className = "alert show alert-error";
    checkoutBtn.disabled = false;
    checkoutBtn.textContent = "Proceed to Checkout";
  }
});

loadCart();
