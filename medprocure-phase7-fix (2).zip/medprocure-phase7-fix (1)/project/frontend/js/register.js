// register.js
import { registerUser, registerDistributor } from "./api.js";
import { saveSession } from "./auth.js";
import { escapeHtml } from "./utils.js";

const roleInput = document.getElementById("role");
const roleOptions = document.querySelectorAll(".role-option");
const distributorFields = document.getElementById("distributor-fields");
const form = document.getElementById("register-form");
const alertBox = document.getElementById("register-alert");
const submitBtn = document.getElementById("register-submit");
const registerPanel = document.getElementById("register-panel");
const successPanel = document.getElementById("success-panel");
const successContent = document.getElementById("success-content");
const continueLink = document.getElementById("continue-link");

roleOptions.forEach((option) => {
  option.addEventListener("click", () => {
    roleOptions.forEach((o) => o.classList.remove("active"));
    option.classList.add("active");
    roleInput.value = option.dataset.role;
    distributorFields.style.display = option.dataset.role === "distributor" ? "block" : "none";
  });
});

function showAlert(message) {
  alertBox.textContent = message;
  alertBox.className = "alert show alert-error";
}

function renderDistributorPendingPanel(email) {
  successContent.innerHTML = `
    <div class="success-icon-big">🕒</div>
    <h1 style="text-align:center; font-size:1.35rem;">Thank you for choosing MedProcure!</h1>
    <p class="subtitle" style="text-align:center;">
      Your distributor registration and compliance documents have been received. Follow the steps below to complete onboarding:
    </p>
    <div class="review-timeline">
      <div class="review-step">
        <div class="step-icon">✓</div>
        <div class="step-text"><strong>Step 1: Application & Documents Received</strong> — Your NIN, ID photo, business license, and proof of address have been securely submitted.</div>
      </div>
      <div class="review-step pending" style="background:#fef3c7; border:1px solid #fde68a; border-radius:8px; padding:10px;">
        <div class="step-icon" style="background:#f59e0b; color:#fff;">2</div>
        <div class="step-text"><strong>Step 2: Verify Your Email Address (Action Required)</strong> — We have sent an activation link to <strong>${email ? escapeHtml(email) : "your email address"}</strong>. You must click the link to confirm your email before an administrator can review and approve your account.</div>
      </div>
      <div class="review-step pending">
        <div class="step-icon">3</div>
        <div class="step-text"><strong>Step 3: Administrative KYC Review & Activation</strong> — Once your email is verified, our compliance team inspects your business documents and authenticates your NIN within 24–48 hours. You will receive an approval notification by email.</div>
      </div>
    </div>
    <div class="security-banner info">
      <span class="icon">🛡️</span>
      <span>Remember: all listings are governed by our <a href="terms.html" target="_blank" rel="noopener">Terms &amp; Policy of Operation</a>. You can monitor your verification status anytime from your dashboard.</span>
    </div>
  `;
}

function renderConsumerSuccessPanel(email) {
  successContent.innerHTML = `
    <div class="success-icon-big">✅</div>
    <h1 style="text-align:center; font-size:1.35rem;">Account created!</h1>
    <p class="subtitle" style="text-align:center;">
      We've sent an activation link to <strong>${email ? escapeHtml(email) : "your email"}</strong>. Please check your inbox and click the link to verify your Healthcare Consumer account.
    </p>
    <div class="security-banner info">
      <span class="icon">💡</span>
      <span>The verification link is valid for 24 hours. After verifying, you can browse equipment and place orders immediately.</span>
    </div>
  `;
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  alertBox.className = "alert";
  submitBtn.disabled = true;
  submitBtn.textContent = "Creating account...";

  const role = roleInput.value;
  const fullName = document.getElementById("fullName").value.trim();
  const email = document.getElementById("email").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const password = document.getElementById("password").value;

  try {
    let data;

    if (role === "distributor") {
      const businessName = document.getElementById("businessName").value.trim();
      const licenseNumber = document.getElementById("licenseNumber").value.trim();
      const nin = document.getElementById("nin").value.trim();
      const dateOfBirth = document.getElementById("dateOfBirth").value;
      const residentialAddress = document.getElementById("residentialAddress").value.trim();
      const licenseFileInput = document.getElementById("licenseDocument");
      const idPhotoInput = document.getElementById("idPhoto");
      const proofOfAddressInput = document.getElementById("proofOfAddress");
      const termsAccepted = document.getElementById("termsAccepted").checked;

      if (!businessName || !licenseNumber) throw new Error("Business name and license number are required for Distributor accounts.");
      if (!/^\d{11}$/.test(nin)) throw new Error("Please enter a valid 11-digit National Identification Number (NIN).");
      if (!idPhotoInput.files[0]) throw new Error("Please upload a clear photo of yourself or your government ID for identity verification.");
      if (!licenseFileInput.files[0]) throw new Error("Please upload your business license or certificate document.");
      if (!proofOfAddressInput.files[0]) throw new Error("Please upload a proof of address document.");
      if (!termsAccepted) throw new Error("You must agree to the Distributor Terms & Policy of Operation to register.");

      const formData = new FormData();
      formData.append("fullName", fullName);
      formData.append("email", email);
      formData.append("password", password);
      formData.append("phone", phone);
      formData.append("role", "distributor");
      formData.append("businessName", businessName);
      formData.append("licenseNumber", licenseNumber);
      formData.append("nin", nin);
      formData.append("dateOfBirth", dateOfBirth);
      formData.append("residentialAddress", residentialAddress);
      formData.append("licenseDocument", licenseFileInput.files[0]);
      formData.append("idPhoto", idPhotoInput.files[0]);
      formData.append("proofOfAddress", proofOfAddressInput.files[0]);
      formData.append("termsAccepted", "true");

      data = await registerDistributor(formData);
    } else {
      data = await registerUser({ fullName, email, password, phone });
    }

    saveSession(data.token, data.user);
    registerPanel.style.display = "none";
    successPanel.style.display = "block";

    if (role === "distributor") {
      renderDistributorPendingPanel(email);
    } else {
      renderConsumerSuccessPanel(email);
    }
  } catch (err) {
    showAlert(err.message);
    submitBtn.disabled = false;
    submitBtn.textContent = "Create Account";
  }
});
