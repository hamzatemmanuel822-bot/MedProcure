// dashboard.js
import { getToken, getUser, saveSession, logout } from "./auth.js";
import {
  getCurrentUser, getDashboardSummary, getCategoryInsights,
  getVerificationStatus, submitVerificationDocument, getMyOrders, getMyProducts, getPendingDistributors,
} from "./api.js";
import { renderFooter } from "./components/footer.js";
import { escapeHtml } from "./utils.js";

const token = getToken();
const roleLabels = { healthcare_consumer: "Healthcare Consumer", distributor: "Distributor", admin: "Administrator" };

function initials(name) {
  if (!name) return "?";
  return name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
}
function timeAgo(dateStr) {
  const diffMs = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}
function updateClock() {
  const el = document.getElementById("clock");
  if (!el) return;
  const now = new Date();
  el.innerHTML = `${now.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" })}<br>${now.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}`;
}

function renderHero(u) {
  const displayName = u.fullName || u.full_name || "User";
  const avatarEl = document.getElementById("avatar-initials");
  const greetingEl = document.getElementById("greeting");
  const emailLineEl = document.getElementById("email-line");
  const badgesRow = document.getElementById("badges-row");

  if (avatarEl) avatarEl.textContent = initials(displayName);
  if (greetingEl) greetingEl.textContent = `Welcome back, ${displayName.split(" ")[0] || "there"}`;
  if (emailLineEl) emailLineEl.textContent = `${u.email} · ${roleLabels[u.role] || u.role}`;
  if (!badgesRow) return;

  let badges = "";
  if (u.accountStatus === "terminated") {
    badges += `<span class="badge badge-rejected" style="background:#fee2e2; color:#991b1b; border:1px solid #fecaca;">⚠️ Account Terminated</span>`;
  } else if (u.role === "distributor") {
    if (!u.isVerified) {
      badges += `<span class="badge badge-pending" style="background:#fef3c7; color:#b45309; border:1px solid #fde68a;">⚠️ Email Unverified</span> `;
    } else {
      badges += `<span class="badge badge-verified">✔ Email Verified</span> `;
    }

    if (u.verificationStatus === "approved") {
      badges += `<span class="badge badge-verified">✔ Verified Distributor</span>`;
    } else if (u.verificationStatus === "pending") {
      badges += `<span class="badge badge-pending">⏳ KYC Pending Review</span>`;
    } else if (u.verificationStatus === "rejected") {
      badges += `<span class="badge badge-rejected">⚠️ KYC Rejected</span>`;
    }
  } else if (u.role === "healthcare_consumer") {
    badges += u.isVerified
      ? `<span class="badge badge-verified">✔ Email Verified</span>`
      : `<span class="badge badge-pending">Email Not Verified</span>`;
  } else if (u.role === "admin") {
    badges += `<span class="badge badge-role">🛡️ Platform Administrator</span>`;
  }
  badgesRow.innerHTML = badges;
}

function renderStats(summary) {
  const grid = document.getElementById("stats-grid");
  if (!grid) return;
  let cards = [];
  if (summary.role === "healthcare_consumer") {
    cards = [
      { icon: "🛒", cls: "teal", value: summary.cartItemCount, label: "Items in Cart" },
      { icon: "📩", cls: "amber", value: summary.activeQuoteRequests, label: "Quotes Awaiting Payment" },
      { icon: "🔓", cls: "green", value: summary.unlockedQuoteRequests, label: "Contacts Unlocked" },
      { icon: "📦", cls: "navy", value: summary.completedOrders, label: "Orders Completed" },
      { icon: "💳", cls: "teal", value: `$${Number(summary.totalSpent).toFixed(2)}`, label: "Total Spent" },
    ];
  } else if (summary.role === "distributor") {
    cards = [
      { icon: "📋", cls: "teal", value: summary.activeListings, label: "Active Listings" },
      { icon: "📦", cls: "navy", value: summary.totalStockUnits, label: "Total Stock Units" },
      { icon: "📩", cls: "amber", value: summary.pendingQuoteRequests, label: "Quotes Awaiting Buyer Payment" },
      { icon: "🔓", cls: "green", value: summary.unlockedQuoteRequests, label: "Contacts Shared" },
    ];
  } else if (summary.role === "admin") {
    cards = [
      { icon: "⏳", cls: "amber", value: summary.pendingDistributors, label: "Pending Verifications" },
      { icon: "🏭", cls: "teal", value: summary.totalDistributors, label: "Total Distributors" },
      { icon: "🧑‍⚕️", cls: "navy", value: summary.totalConsumers, label: "Healthcare Consumers" },
      { icon: "📋", cls: "green", value: summary.totalProducts, label: "Total Listings" },
      { icon: "📦", cls: "teal", value: summary.completedOrders, label: "Orders Completed" },
    ];
  }
  grid.innerHTML = cards.map((c, i) => `
    <div class="stat-card" style="animation-delay:${i * 60}ms">
      <div class="stat-icon ${c.cls}">${c.icon}</div>
      <div><div class="stat-value">${c.value}</div><div class="stat-label">${c.label}</div></div>
    </div>
  `).join("");
}

function renderQuickActions(user) {
  const el = document.getElementById("quick-actions");
  if (!el || !user) return;

  if (user.accountStatus === "terminated") {
    el.innerHTML = `
      <div class="dash-empty" style="color:var(--color-danger); padding:var(--space-md); background:var(--color-danger-bg); border-radius:var(--radius-sm); border:1px solid #fecaca; width:100%;">
        🚫 Marketplace and seller actions are disabled because your account has been terminated. Please contact support.
      </div>
    `;
    return;
  }

  const role = user.role;
  let actions = [];
  if (role === "healthcare_consumer") {
    actions = [
      { href: "products.html", icon: "🔍", label: "Browse Marketplace" },
      { href: "cart.html", icon: "🛒", label: "My Cart" },
      { href: "my-quotes.html", icon: "📩", label: "Quote Requests" },
    ];
  } else if (role === "distributor") {
    if (user.verificationStatus === "approved") {
      actions = [
        { href: "vendor-products.html", icon: "➕", label: "Add / Manage Listings" },
        { href: "received-quotes.html", icon: "📥", label: "Incoming Quotes" },
        { href: "products.html", icon: "🔍", label: "View Marketplace" },
      ];
    } else {
      actions = [
        { href: "received-quotes.html", icon: "📥", label: "Incoming Quotes" },
        { href: "products.html", icon: "🔍", label: "View Marketplace" },
      ];
    }
  } else if (role === "admin") {
    actions = [{ href: "admin-dashboard.html", icon: "🛡️", label: "Review Distributors" }];
  }
  el.innerHTML = actions.map((a) => `<a href="${a.href}" class="quick-action-tile"><span class="qa-icon">${a.icon}</span><span class="qa-label">${a.label}</span></a>`).join("");
}

async function renderRecentActivity(role) {
  const el = document.getElementById("recent-activity");
  const titleEl = document.getElementById("activity-title");
  if (!el || !titleEl) return;

  try {
    if (role === "healthcare_consumer") {
      titleEl.textContent = "Recent Orders";
      const { orders } = await getMyOrders(token);
      if (!orders.length) { el.innerHTML = `<div class="dash-empty">No orders yet — <a href="products.html">browse the marketplace</a> to get started.</div>`; return; }
      el.innerHTML = orders.slice(0, 5).map((o) => `
        <div class="activity-row">
          <div class="activity-main"><span class="activity-title">Order #${o.id}</span><span class="activity-sub">${timeAgo(o.created_at)}</span></div>
          <div class="activity-right"><div class="activity-amount">$${Number(o.total_amount).toFixed(2)}</div><span class="badge ${o.status === "paid" ? "badge-verified" : "badge-pending"}">${escapeHtml(o.status)}</span></div>
        </div>
      `).join("");
    } else if (role === "distributor") {
      titleEl.textContent = "Recent Listings";
      const { products } = await getMyProducts(token);
      if (!products.length) { el.innerHTML = `<div class="dash-empty">No listings yet — add your first product from the Quick Actions panel once verified.</div>`; return; }
      el.innerHTML = products.slice(0, 5).map((p) => `
        <div class="activity-row">
          <div class="activity-main"><span class="activity-title">${escapeHtml(p.name)}</span><span class="activity-sub">${escapeHtml(p.category)} · ${p.stock} in stock</span></div>
          <div class="activity-right"><div class="activity-amount">$${Number(p.price).toFixed(2)}</div></div>
        </div>
      `).join("");
    } else if (role === "admin") {
      titleEl.textContent = "Pending Distributor Verifications";
      const { distributors } = await getPendingDistributors(token);
      if (!distributors.length) { el.innerHTML = `<div class="dash-empty">No pending verifications. All caught up. ✅</div>`; return; }
      el.innerHTML = distributors.slice(0, 5).map((d) => `
        <div class="activity-row">
          <div class="activity-main"><span class="activity-title">${escapeHtml(d.business_name || d.full_name)}</span><span class="activity-sub">Submitted ${timeAgo(d.created_at)}</span></div>
          <div class="activity-right"><a href="admin-dashboard.html" class="btn-small">Review</a></div>
        </div>
      `).join("");
    }
  } catch (err) {
    el.innerHTML = `<div class="dash-empty">Could not load activity: ${escapeHtml(err.message)}</div>`;
  }
}

async function renderCategoryInsights() {
  const el = document.getElementById("category-insights");
  if (!el) return;
  try {
    const { categories } = await getCategoryInsights();
    if (!categories || !categories.length) { el.innerHTML = `<div class="dash-empty">No listings yet to generate insights from.</div>`; return; }
    const maxCount = Math.max(...categories.map((c) => Number(c.listing_count)));
    el.innerHTML = categories.slice(0, 6).map((c) => {
      const pct = Math.max(6, Math.round((Number(c.listing_count) / maxCount) * 100));
      return `
        <div class="insight-row">
          <div class="insight-label-row"><span class="cat-name">${escapeHtml(c.category)}</span><span class="cat-avg">${c.listing_count} listing${c.listing_count == 1 ? "" : "s"} · avg $${Number(c.avg_price).toFixed(2)}</span></div>
          <div class="insight-bar-track"><div class="insight-bar-fill" style="width:${pct}%"></div></div>
        </div>
      `;
    }).join("");
  } catch (err) {
    el.innerHTML = `<div class="dash-empty">Could not load insights.</div>`;
  }
}

async function renderVerificationBanner(u) {
  const bannerEl = document.getElementById("verification-banner");
  if (!bannerEl || !u) return;

  if (u.accountStatus === "terminated") {
    bannerEl.innerHTML = `
      <div class="security-banner rejected" style="margin-bottom: var(--space-lg); display:flex; align-items:flex-start; gap:var(--space-sm);">
        <span class="icon">🚫</span>
        <div>
          <strong>Account Terminated</strong>
          <div style="margin-top:4px;">Your distributor account has been terminated for violating MedProcure's Terms &amp; Policy of Operation. Listings and seller actions are revoked. Please contact support if you believe this is an error.</div>
        </div>
      </div>
    `;
    return;
  }

  if (u.role !== "distributor") {
    bannerEl.innerHTML = "";
    return;
  }

  try {
    const status = await getVerificationStatus(token);
    const isEmailVerified = status.isVerified !== undefined ? status.isVerified : status.is_verified;
    const vStatus = status.verificationStatus || status.verification_status;
    const notes = status.verificationNotes || status.verification_notes;

    if (!isEmailVerified) {
      bannerEl.innerHTML = `
        <div class="security-banner pending" style="margin-bottom: var(--space-lg); background:#fef3c7; border:1px solid #fde68a; color:#92400e; display:flex; align-items:flex-start; gap:var(--space-sm);">
          <span class="icon">📧</span>
          <div>
            <strong>Step 2: Email Verification Required</strong>
            <div style="margin-top:4px;">We sent an activation link to <strong>${escapeHtml(u.email)}</strong>. Please click the link to confirm your email before our compliance team can review your business documents.</div>
          </div>
        </div>
      `;
      return;
    }

    if (vStatus === "pending") {
      bannerEl.innerHTML = `
        <div class="security-banner pending" style="margin-bottom: var(--space-lg); display:flex; align-items:flex-start; gap:var(--space-sm);">
          <span class="icon">⏳</span>
          <div>
            <strong>Step 3: Administrative KYC Review Pending</strong>
            <div style="margin-top:4px;">Your email is verified! Our compliance team is currently reviewing your NIN, ID photo, and business registration. You cannot list equipment until approved (reviews typically take 24–48 hours).</div>
          </div>
        </div>
      `;
      return;
    }

    if (vStatus === "rejected") {
      bannerEl.innerHTML = `
        <div class="security-banner rejected" style="margin-bottom: var(--space-lg); display:block;">
          <div style="display:flex; align-items:flex-start; gap:var(--space-sm); margin-bottom:12px;">
            <span class="icon">⚠️</span>
            <div>
              <strong>Distributor Verification Not Approved</strong>
              ${notes ? `<div style="margin-top:4px;">Reason provided: <em>${escapeHtml(notes)}</em></div>` : ""}
            </div>
          </div>
          <div style="border-top:1px solid #fecaca; padding-top:12px; margin-top:8px;">
            <p style="font-size:0.86rem; margin-bottom:6px; font-weight:700; color:#991b1b;">Resubmit Corrected Document for Re-review:</p>
            <p style="font-size:0.8rem; color:#7f1d1d; margin-bottom:10px;">Upload your corrected business license, certificate, or regulatory document (PDF, JPG, or PNG up to 5MB) to request administrative re-review.</p>
            <form id="resubmit-doc-form" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
              <input type="file" id="resubmit-file" accept=".pdf,.jpg,.jpeg,.png" required style="font-size:0.82rem; padding:6px; background:#fff; border:1px solid #fca5a5; border-radius:6px; max-width:280px;" />
              <button type="submit" id="resubmit-btn" class="btn-primary" style="padding:7px 16px; font-size:0.82rem; background:#dc2626; border:none; border-radius:6px; color:#fff; cursor:pointer;">Resubmit Document</button>
            </form>
            <div id="resubmit-feedback" style="font-size:0.82rem; margin-top:8px; display:none;"></div>
          </div>
        </div>
      `;

      const resubmitForm = document.getElementById("resubmit-doc-form");
      if (resubmitForm) {
        resubmitForm.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fileInput = document.getElementById("resubmit-file");
          const submitBtn = document.getElementById("resubmit-btn");
          const feedback = document.getElementById("resubmit-feedback");
          if (!fileInput.files || !fileInput.files[0]) return;

          submitBtn.disabled = true;
          submitBtn.textContent = "Uploading...";
          feedback.style.display = "none";

          try {
            const res = await submitVerificationDocument(token, fileInput.files[0]);
            feedback.style.display = "block";
            feedback.style.color = "var(--color-verified)";
            feedback.textContent = res.message || "Document submitted successfully. Status is now pending review.";
            setTimeout(async () => {
              const fresh = await syncUserFromServer();
              if (fresh) {
                renderHero(fresh);
                renderVerificationBanner(fresh);
              }
            }, 1200);
          } catch (err) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Resubmit Document";
            feedback.style.display = "block";
            feedback.style.color = "#991b1b";
            feedback.textContent = err.message || "Could not submit document. Please try again.";
          }
        });
      }
      return;
    }

    bannerEl.innerHTML = "";
  } catch (err) {
    console.error("renderVerificationBanner error:", err);
  }
}

async function syncUserFromServer() {
  try {
    const res = await getCurrentUser(token);
    if (res && res.user) {
      saveSession(token, res.user);
      return getUser();
    }
  } catch (err) {
    console.warn("Could not sync user from server:", err.message);
    if (err.message && (err.message.includes("token") || err.message.includes("log in") || err.message.includes("expired"))) {
      logout();
    }
  }
  return null;
}

async function init() {
  if (!token) { window.location.href = "login.html"; return; }
  updateClock();
  setInterval(updateClock, 30000);

  const cachedUser = getUser();
  if (cachedUser) {
    renderHero(cachedUser);
    renderQuickActions(cachedUser);
    renderVerificationBanner(cachedUser);
    renderRecentActivity(cachedUser.role);
  }
  renderCategoryInsights();

  // Background live session refresh & normalization
  const freshUser = await syncUserFromServer();
  if (freshUser) {
    renderHero(freshUser);
    renderQuickActions(freshUser);
    renderVerificationBanner(freshUser);
    if (!cachedUser || cachedUser.role !== freshUser.role) {
      renderRecentActivity(freshUser.role);
    }
  } else if (!cachedUser) {
    logout();
    return;
  }

  try {
    const summary = await getDashboardSummary(token);
    renderStats(summary);
  } catch (err) {
    const statsGrid = document.getElementById("stats-grid");
    if (statsGrid) statsGrid.innerHTML = `<div class="dash-empty">Could not load stats.</div>`;
  }
}

const logoutLink = document.getElementById("logout-link");
if (logoutLink) {
  logoutLink.addEventListener("click", (e) => { e.preventDefault(); logout(); });
}
renderFooter("footer-slot");
init();
