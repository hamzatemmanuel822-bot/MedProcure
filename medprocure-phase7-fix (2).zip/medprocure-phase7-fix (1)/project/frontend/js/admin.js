// admin.js
import { getToken, getUser, logout } from "./auth.js";
import {
  getPendingDistributors, getAllDistributors, approveDistributor, rejectDistributor,
  terminateDistributor, viewDistributorDocument,
} from "./api.js";
import { escapeHtml } from "./utils.js";

const token = getToken();
const user = getUser();
if (!token || !user || user.role !== "admin") window.location.href = "login.html";

const pendingListEl = document.getElementById("pending-list");
const activeListEl = document.getElementById("active-list");

function initials(name) {
  if (!name) return "?";
  return name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
}

function docButton(distributor, type, label, has) {
  if (!has) return `<span class="doc-link missing">✖ ${label} not uploaded</span>`;
  return `<button class="doc-link" data-doc="${distributor.id}" data-type="${type}">📄 View ${label} ↗</button>`;
}

function renderPending(distributors) {
  if (!distributors.length) {
    pendingListEl.innerHTML = `<div class="empty-state">No pending distributor verifications. All caught up. ✅</div>`;
    return;
  }

  pendingListEl.innerHTML = distributors.map((d) => {
    const isEmailVerified = d.isVerified !== undefined ? d.isVerified : !!d.is_verified;
    return `
    <div class="review-card" data-id="${d.id}">
      <div class="review-header">
        <div class="review-identity">
          <div class="review-avatar">${initials(d.full_name)}</div>
          <div>
            <h3>${escapeHtml(d.business_name || "(No business name provided)")}</h3>
            <div class="review-sub">${escapeHtml(d.full_name)} · ${escapeHtml(d.email)}${d.phone ? ` · ${escapeHtml(d.phone)}` : ""}</div>
          </div>
        </div>
        <div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap;">
          <span class="badge badge-pending">Pending Review</span>
          ${isEmailVerified
            ? `<span class="badge badge-verified">✔ Email Verified</span>`
            : `<span class="badge badge-pending" style="background:#fef3c7; color:#b45309; border:1px solid #fde68a;">⚠️ Email Unverified</span>`
          }
        </div>
      </div>

      <div class="review-grid">
        <div class="review-field"><div class="field-label">National ID Number (NIN)</div><div class="field-value nin-value">${escapeHtml(d.nin || "Not provided")}</div></div>
        <div class="review-field"><div class="field-label">License Number</div><div class="field-value">${escapeHtml(d.license_number || "—")}</div></div>
        <div class="review-field"><div class="field-label">Email Status</div><div class="field-value">${isEmailVerified ? "<span style='color:var(--color-verified); font-weight:700;'>✔ Verified</span>" : "<span style='color:#b45309; font-weight:700;'>⚠️ Unverified (Distributor must verify email before approval)</span>"}</div></div>
        <div class="review-field"><div class="field-label">Date of Birth</div><div class="field-value">${d.date_of_birth ? new Date(d.date_of_birth).toLocaleDateString() : "—"}</div></div>
        <div class="review-field"><div class="field-label">Residential Address</div><div class="field-value">${escapeHtml(d.residential_address || "—")}</div></div>
        <div class="review-field"><div class="field-label">Submitted</div><div class="field-value">${new Date(d.created_at).toLocaleDateString()}</div></div>
      </div>

      <div class="doc-buttons">
        ${docButton(d, "id", "ID Photo", d.has_id_photo)}
        ${docButton(d, "license", "Business License", d.has_license_document)}
        ${docButton(d, "address", "Proof of Address", d.has_proof_of_address)}
      </div>

      <div class="review-actions">
        ${isEmailVerified
          ? `<button class="btn-approve" data-approve="${d.id}">✅ Approve Distributor</button>`
          : `<button class="btn-approve" data-approve="${d.id}" disabled style="opacity:0.45; cursor:not-allowed; filter:grayscale(0.6);" title="Distributor must verify email address before administrative approval">⏳ Awaiting Email Verification</button>`
        }
        <button class="btn-decline" data-toggle-reject="${d.id}">✖ Decline</button>
      </div>

      <div class="reject-inline" id="reject-box-${d.id}">
        <label style="font-size:0.85rem; font-weight:600; display:block; margin-bottom:6px;">Reason for declining (emailed to the distributor):</label>
        <textarea id="reject-reason-${d.id}" placeholder="e.g. Uploaded documents don't match the submitted NIN..."></textarea>
        <div class="reject-actions">
          <button class="btn-decline" data-confirm-reject="${d.id}">Confirm Decline</button>
          <button class="btn-small" data-cancel-reject="${d.id}">Cancel</button>
        </div>
      </div>
    </div>
  `}).join("");

  wireDocButtons(pendingListEl);

  pendingListEl.querySelectorAll("[data-approve]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (btn.disabled) return;
      const distId = btn.dataset.approve;
      const dist = distributors.find((item) => String(item.id) === String(distId));
      const verified = dist ? (dist.isVerified !== undefined ? dist.isVerified : dist.is_verified) : false;
      if (!verified) {
        alert("Cannot approve distributor: The distributor must verify their email address before administrative approval.");
        return;
      }
      btn.disabled = true;
      btn.textContent = "Approving...";
      try {
        await approveDistributor(token, distId);
        loadAll();
      } catch (err) {
        alert(err.message);
        btn.disabled = false;
        btn.textContent = "✅ Approve Distributor";
      }
    });
  });

  pendingListEl.querySelectorAll("[data-toggle-reject]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.getElementById(`reject-box-${btn.dataset.toggleReject}`).style.display = "block";
    });
  });
  pendingListEl.querySelectorAll("[data-cancel-reject]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.getElementById(`reject-box-${btn.dataset.cancelReject}`).style.display = "none";
    });
  });
  pendingListEl.querySelectorAll("[data-confirm-reject]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.confirmReject;
      const reason = document.getElementById(`reject-reason-${id}`).value.trim();
      btn.disabled = true;
      btn.textContent = "Declining...";
      try { await rejectDistributor(token, id, reason); loadAll(); }
      catch (err) { alert(err.message); btn.disabled = false; btn.textContent = "Confirm Decline"; }
    });
  });
}

function renderActive(distributors) {
  const active = distributors.filter((d) => d.verification_status === "approved");
  if (!active.length) {
    activeListEl.innerHTML = `<div class="empty-state">No approved distributors yet.</div>`;
    return;
  }

  activeListEl.innerHTML = active.map((d) => `
    <div class="active-distributor-row" data-id="${d.id}">
      <div>
        <strong>${escapeHtml(d.business_name || d.full_name)}</strong>
        <div class="review-sub">${escapeHtml(d.email)}</div>
      </div>
      <div style="display:flex; align-items:center; gap: var(--space-sm);">
        <span class="badge ${d.account_status === "terminated" ? "badge-rejected" : "badge-verified"}">${d.account_status === "terminated" ? "Terminated" : "Active"}</span>
        ${d.account_status !== "terminated" ? `<button class="btn-terminate" data-terminate="${d.id}">Terminate Account</button>` : ""}
      </div>
    </div>
  `).join("");

  activeListEl.querySelectorAll("[data-terminate]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const reason = prompt("Reason for terminating this distributor's account (required, will be emailed to them):");
      if (!reason || !reason.trim()) return;
      btn.disabled = true;
      btn.textContent = "Terminating...";
      try { await terminateDistributor(token, btn.dataset.terminate, reason); loadAll(); }
      catch (err) { alert(err.message); btn.disabled = false; btn.textContent = "Terminate Account"; }
    });
  });
}

function wireDocButtons(root) {
  root.querySelectorAll("[data-doc]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try { await viewDistributorDocument(token, btn.dataset.doc, btn.dataset.type); }
      catch (err) { alert(err.message); }
    });
  });
}

async function loadAll() {
  pendingListEl.innerHTML = `<div class="empty-state">Loading...</div>`;
  activeListEl.innerHTML = `<div class="empty-state">Loading...</div>`;
  try {
    const [{ distributors: pending }, { distributors: all }] = await Promise.all([
      getPendingDistributors(token),
      getAllDistributors(token),
    ]);
    renderPending(pending);
    renderActive(all);
  } catch (err) {
    pendingListEl.innerHTML = `<div class="empty-state">Could not load: ${escapeHtml(err.message)}</div>`;
  }
}

document.querySelectorAll(".admin-tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".admin-tab").forEach((t) => t.classList.remove("active"));
    document.querySelectorAll(".admin-tab-panel").forEach((p) => p.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(tab.dataset.panel).classList.add("active");
  });
});

document.getElementById("logout-link").addEventListener("click", (e) => { e.preventDefault(); logout(); });
loadAll();
