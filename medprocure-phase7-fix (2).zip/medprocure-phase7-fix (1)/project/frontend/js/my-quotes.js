// my-quotes.js
import { getToken, getUser } from "./auth.js";
import { getMyQuoteRequests, payQuoteFee } from "./api.js";
import { escapeHtml } from "./utils.js";

const token = getToken();
const user = getUser();
if (!token || !user || user.role !== "healthcare_consumer") window.location.href = "login.html";

const listEl = document.getElementById("quotes-list");

function renderQuotes(quotes) {
  if (!quotes.length) {
    listEl.innerHTML = `<div class="empty-state">You haven't requested any quotes yet. <a href="products.html">Browse the marketplace</a>.</div>`;
    return;
  }
  listEl.innerHTML = quotes.map((q) => {
    const unlocked = q.status === "contact_unlocked";
    return `
      <div class="quote-card">
        <div class="quote-card-header">
          <h3>${escapeHtml(q.product_name)}</h3>
          <span class="badge ${unlocked ? "badge-verified" : "badge-pending"}">${unlocked ? "Contact Unlocked" : "Awaiting Payment"}</span>
        </div>
        ${unlocked ? `
          <div class="contact-block">
            <div><strong>${escapeHtml(q.distributor_business || q.distributor_name)}</strong></div>
            <div>📧 ${escapeHtml(q.distributor_email)}</div>
            ${q.distributor_phone ? `<div>📞 ${escapeHtml(q.distributor_phone)}</div>` : ""}
          </div>
        ` : `
          <p style="font-size:0.85rem; color:var(--color-text-muted); margin: var(--space-sm) 0;">
            Pay the $${Number(q.fee_amount).toFixed(2)} demo unlock fee to view this distributor's contact information.
          </p>
          <button class="btn-small" data-pay="${q.id}">Pay Unlock Fee</button>
        `}
      </div>
    `;
  }).join("");

  listEl.querySelectorAll("[data-pay]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      btn.textContent = "Redirecting to payment...";
      try {
        const { checkoutUrl } = await payQuoteFee(token, btn.dataset.pay);
        window.location.href = checkoutUrl;
      } catch (err) {
        alert(err.message);
        btn.disabled = false;
        btn.textContent = "Pay Unlock Fee";
      }
    });
  });
}

async function loadQuotes() {
  listEl.innerHTML = `<div class="empty-state">Loading your quote requests...</div>`;
  try {
    const { quoteRequests } = await getMyQuoteRequests(token);
    renderQuotes(quoteRequests);
  } catch (err) {
    listEl.innerHTML = `<div class="empty-state">Could not load: ${escapeHtml(err.message)}</div>`;
  }
}
loadQuotes();
