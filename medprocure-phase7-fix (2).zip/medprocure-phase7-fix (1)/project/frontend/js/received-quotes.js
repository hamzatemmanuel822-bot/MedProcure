// received-quotes.js
import { getToken, getUser } from "./auth.js";
import { getReceivedQuoteRequests } from "./api.js";
import { escapeHtml } from "./utils.js";

const token = getToken();
const user = getUser();
if (!token || !user || user.role !== "distributor") window.location.href = "login.html";

const listEl = document.getElementById("quotes-list");

function renderQuotes(quotes) {
  if (!quotes.length) { listEl.innerHTML = `<div class="empty-state">No quote requests yet.</div>`; return; }
  listEl.innerHTML = quotes.map((q) => {
    const unlocked = q.status === "contact_unlocked";
    return `
      <div class="quote-card">
        <div class="quote-card-header">
          <h3>${escapeHtml(q.product_name)}</h3>
          <span class="badge ${unlocked ? "badge-verified" : "badge-pending"}">${unlocked ? "Fee Paid — Buyer Has Your Contact" : "Awaiting Buyer Payment"}</span>
        </div>
        <div class="contact-block">
          <div><strong>${escapeHtml(q.consumer_name)}</strong></div>
          <div>📧 ${escapeHtml(q.consumer_email)}</div>
        </div>
      </div>
    `;
  }).join("");
}

async function loadQuotes() {
  listEl.innerHTML = `<div class="empty-state">Loading...</div>`;
  try {
    const { quoteRequests } = await getReceivedQuoteRequests(token);
    renderQuotes(quoteRequests);
  } catch (err) {
    listEl.innerHTML = `<div class="empty-state">Could not load: ${escapeHtml(err.message)}</div>`;
  }
}
loadQuotes();
