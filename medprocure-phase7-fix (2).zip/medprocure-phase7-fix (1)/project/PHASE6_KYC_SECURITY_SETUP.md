# Phase 6: Seller KYC Verification + Security Hardening

A quick but important note first: my workspace reset between our last session and this one, so I
rebuilt the entire project from scratch based on everything we'd built together, then added this
phase on top. I've re-verified every file (syntax-checked all backend code, cross-checked every
frontend file reference) so this zip is a complete, working replacement for your whole project —
not a patch. Just replace your project folder entirely with this one.

## What's new in this phase

### 1. Mandatory seller identity verification (anti-scam)
Every Distributor signup now REQUIRES, before the account is even created:
- Full legal name, business name, license number (as before)
- **National Identification Number (NIN)** — 11 digits, encrypted before it's ever written to the database
- **A verification photo** (selfie or photo of a government ID)
- **Business license/certificate document** (as before, now mandatory at signup instead of optional)
- Date of birth and residential address

A NIN can only ever be used for ONE account — trying to register a second seller account with
the same NIN is blocked automatically, which closes a common multi-accounting scam pattern.

### 2. NIN encryption
Your NIN is never stored as plain text. It's encrypted with AES-256-GCM using a key only your
server has (`ENCRYPTION_KEY` in `.env`). Even if someone got a raw copy of your database, the NIN
column would just look like random noise to them. Admins reviewing a distributor only ever see
the **last 4 digits** — even authorized staff don't see the full number by default.

### 3. Verification documents are no longer publicly accessible
Previously, uploaded documents were served from a public `/uploads/...` URL — technically hard to
guess, but not something sensitive ID photos should ever sit behind. Now there's NO public route
for them at all. They're only viewable through an authenticated, admin-only endpoint that streams
the file directly — enforced by your backend, not just hidden in the UI.

### 4. Login brute-force protection
5 wrong password attempts locks that account for 15 minutes. Login errors are also now generic
("Invalid email or password") whether the email exists or not — this prevents attackers from using
your login form to check which emails have accounts on your platform.

### 5. Other security fixes
- **XSS fix**: every place your app displays user-typed content (product names, descriptions,
  business names, etc.) now escapes it before inserting it into the page. Before this fix, a
  malicious distributor could have named a product something like `<script>...</script>` and had
  it execute in every visitor's browser. This was a real gap — now closed everywhere.
- **CORS locked down**: your API only accepts requests from your actual frontend URL, not any
  website on the internet.
- **Image URL validation**: product image URLs must start with `http://` or `https://` — blocks a
  `javascript:` URL injection trick.
- **Request body size limit** and **stricter rate limiting** on login/register specifically.
- **Password requirements**: now must contain both letters and numbers, not just be 8+ characters.
- **File upload validation**: checks both file extension AND actual file type (mimetype), so
  someone can't rename a malicious file to `.pdf` to sneak past the filter.

## Setup steps

### 1. Generate your encryption key
```
cd backend
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
Copy the output into `backend/.env`:
```
ENCRYPTION_KEY=<paste the generated key here>
```

### 2. Copy the rest of your `.env` values over
Since this is a full replacement, re-copy your Stripe keys, DB settings, JWT secret, and admin
credentials from your previous `.env` into the new `.env.example` → `.env`.

### 3. Install and migrate
```
npm install
npm run migrate
```

### 4. Re-seed your admin (if needed)
```
npm run seed:admin
```

### 5. Restart everything
Same three things as before: `docker-compose up -d` (database), `stripe listen --forward-to
localhost:5000/api/orders/webhook` (Stripe webhook bridge), and `npm run dev` (backend).

## Testing the new signup flow

1. Go to `register.html`, choose Distributor
2. Fill in business name, license number, an 11-digit NIN (any 11 digits work in this demo —
   there's no live NIN verification API connected), date of birth, address
3. Upload any test image/PDF for both the ID photo and license document
4. Submit — you'll land in "pending" status
5. Log in as your admin, go to the Distributor Verification dashboard — you'll now see a masked
   NIN and two separate "View document" links (license + ID photo), both opening securely
6. Approve — the distributor can now list products

## Note on real NIN verification

This demo validates that a NIN is 11 digits and encrypts it — it does **not** call Nigeria's NIMC
database to confirm the NIN is real or belongs to that person. Full real-world verification would
mean integrating NIMC's official verification API (this requires a business agreement with NIMC,
not something available as an open API). Happy to help wire that in later if/when you have API
access — the encrypted storage and admin review flow are already built to support it.
